---
title: mechanism-wheel-leg-hybrid
parent: Cross-cuts
layout: default
---

# Cross-cut: `mechanism-wheel-leg-hybrid`

**12 corpus entries disclose this subsystem.**

Earliest disclosure: 2002-10-01

Listed in chronological order. Each entry's `prior_art_notes` and
`disclosure_citation` constitute the citeable prior art material.

---

## Tachikoma (2002-10-01)

- **id**: `ghost-in-the-shell-tachikoma`
- **corpus**: fictional
- **creator**: Kenji Kamiyama (TV series), Masamune Shirow (precursor design)
- **disclosure**: Kamiyama, Kenji. Ghost in the Shell: Stand Alone Complex. Production I.G, October 1, 2002 (TV series); precursor 'Fuchikoma' design in Shirow, M. Ghost in the Shell, 1989.
- **ip status**: fictional
- **prior art notes**: The most engineering-specific disclosure in the GitS franchise. Anticipates: (1) wheel-leg hybrid locomotion in a quadruped — directly relevant to claims on hybrid-mobility morphologies (BD Spot's hybrid variants, OpenLoco quadrupeds); (2) decentralized swarm AI with periodic policy synchronization — anticipates federated-learning humanoid fleet IP, the specific architecture used by Tesla Optimus's fleet learning; (3) individual experience accumulation followed by aggregation — directly relevant to fleet-policy-update IP. The 2002 broadcast is well-archived; Production I.G's mecha designs are widely cited in robotics venues.

## HUBO (2004)

- **id**: `hubo`
- **corpus**: academic
- **creator**: KAIST, Hubo Lab (Jun-Ho Oh)
- **disclosure**: Park, Ill-Woo et al. 'Mechanical Design of Humanoid Robot Platform KHR-3 (HUBO).' IEEE-RAS Humanoids 2005.
- **ip status**: open-permissive
- **prior art notes**: DRC-Hubo's 2015 win demonstrated transformer-style transitioning between bipedal and wheeled-knee modes for navigating both stairs and flat ground. Anticipates: hybrid locomotion modes in humanoids.

## STAR (Sprawl-Tuned Autonomous Robot) (2013-05)

- **id**: `star-fearing-2013`
- **corpus**: academic
- **creator**: UC Berkeley Biomimetic Millisystems Lab; Ronald Fearing group; Kohut, Karras, et al.
- **disclosure**: Karras, J. T., Fuller, C. L., Carpenter, K. C., Buscicchio, A., McKeeby, D., Norris, C. J., Parcheta, C. E., Royal, M. I., Wilcox, B. H., Fearing, R. S. 'Climbing with sprawl-tuned autonomous robots'. (Original Kohut/Fearing STAR variants 2010-2013.) IEEE/RSJ International Conference on Intelligent Robots and Systems (IROS) 2013. UC Berkeley Biomimetic Millisystems Lab.
- **ip status**: open-permissive
- **prior art notes**: STAR is the original sprawl-tuned reconfigurable miniature robot from the Fearing group at Berkeley. 13-year open-academic publication record. Establishes the 'sprawl-tuned wheel-leg-hybrid + four-bar mechanism' architectural pattern that the entire STAR family (RSTAR, TSTAR, FSTAR, FCSTAR, AmphiSTAR, DSTAR) descends from. Directly shields free-humanoid-centaur's wheel-leg-hybrid commitment and any commercial claim on compact reconfigurable-mechanism wheel-leg robotics.

## DRC-HUBO+ (DARPA Robotics Challenge winner) (2015-06)

- **id**: `kaist-drc-hubo-2015`
- **corpus**: academic
- **creator**: KAIST Humanoid Robot Research Center; Jun-Ho Oh group + Rainbow Robotics
- **disclosure**: KAIST + Rainbow Robotics. 'DRC-HUBO+: A robotic platform for the DARPA Robotics Challenge'. Lim, J., Lee, I., Shim, I., et al. International Journal of Robotics Research / Journal of Field Robotics 2017. Won 1st place at DARPA Robotics Challenge Finals Pomona June 2015 — completing all 8 disaster-response tasks in 44m28s. The follow-on commercial version was Rainbow Robotics' first product (corpus has rainbow-robotics-rb-y1 as the modern commercial successor).
- **ip status**: public-domain
- **prior art notes**: DRC-HUBO+ (KAIST + Rainbow Robotics, DRC 2015) is the canonical Korean academic humanoid milestone — 1st place winner of the DARPA Robotics Challenge Finals June 2015. 10-year-deep public-domain prior art for: wheel-leg hybrid transformable bipedal humanoid (knee-rolling for stability + bipedal for stairs), operator-supervised whole-body autonomy under intermittent comm. Direct shielding for any commercial humanoid claim on transformable lower-body morphology or DRC-class disaster-response capability set. Established Rainbow Robotics' commercial humanoid lineage (corpus entry rainbow-robotics-rb-y1).

## TSTAR (Tail STAR) (2018-05)

- **id**: `tstar-zarrouk-2018`
- **corpus**: academic
- **creator**: Ben-Gurion University; David Zarrouk group
- **disclosure**: Zarrouk, D., et al. 'TSTAR: a reconfigurable robot with active two-link tail and sprawling mechanism, capable of running upright or inverted'. Ben-Gurion University, Bio-inspired and Medical Robotics Lab. ICRA / RA-L 2018-2019.
- **ip status**: open-permissive
- **prior art notes**: TSTAR (Ben-Gurion Zarrouk lab, ~2018) extends the STAR family with an active two-link tail for orientation-flip resilience. ~7-year-deep open-academic prior art for the active-tail-on-wheel-leg-hybrid pattern. Cited in star-fearing-2013's prior_art_notes; round-14 backfill closes the citation chain.

## RSTAR (Rising STAR) (2019-05)

- **id**: `rstar-zarrouk-2019`
- **corpus**: academic
- **creator**: Ben-Gurion University; David Zarrouk group
- **disclosure**: Zarrouk, D., Mann, M., Degani, N., Yehuda, T., Jarbi, N., Hess, A. 'Single Actuator Wave-Like Robot (SAW): Design, Modeling, and Experiments' and follow-up RSTAR papers (IEEE RA-L 2018-2019). Ben-Gurion University of the Negev, Bio-inspired and Medical Robotics Lab. RSTAR = 'Rising STAR'.
- **ip status**: open-permissive
- **prior art notes**: RSTAR is the immediate predecessor of DSTAR and the founding member of the Zarrouk-group Ben-Gurion STAR lineage. 7 years of open-academic publication via IEEE RA-L and IROS. Establishes element-by-element prior art for: wheel-leg-hybrid reconfigurable robots, body-extension step-climbing, turtle-gait crawling without wheels, mode-switching between rolling and walking. Directly shields free-humanoid-centaur commitments on wheel-leg hybrid morphology and mode-switching.

## FSTAR (Flying STAR) (2019-05)

- **id**: `fstar-zarrouk-2019`
- **corpus**: academic
- **creator**: Ben-Gurion University; David Zarrouk group
- **disclosure**: Zarrouk, D., et al. 'Flying STAR (FSTAR): a hybrid flying-and-running quadcopter with sprawl-tuned mechanism'. Ben-Gurion University, ICRA 2019 era.
- **ip status**: open-permissive
- **prior art notes**: FSTAR (Ben-Gurion Zarrouk lab, ~2019) is the first hybrid flying + ground-running STAR-family member. 6-year-deep open-academic prior art for: shared-motor-pool hybrid aerial-ground locomotion, sprawl-tuned wheel-leg + propeller integration. Architectural cousin of Caltech LEONARDO (round-8/round-12 entry caltech-leonardo-2021): FSTAR is quadruped+thrust, LEONARDO is bipedal+thrust. Together they establish the hybrid-locomotion academic substrate.

## FCSTAR (Flying-Climbing STAR) (2021-07)

- **id**: `fcstar-zarrouk-2021`
- **corpus**: academic
- **creator**: Ben-Gurion University; David Zarrouk group
- **disclosure**: Zarrouk, D., et al. 'FCSTAR: Design and Analysis of a Hybrid Flying and Climbing Sprawl-Tuned Robot'. ResearchGate publication 353205537, July 2021. Ben-Gurion University. Builds on FSTAR with thrust-reversal wall-climbing capability.
- **ip status**: open-permissive
- **prior art notes**: FCSTAR (Ben-Gurion Zarrouk lab, ~2021) is the most architecturally ambitious STAR-family member: 4 modes (ground, wall-climb, pipe, flight) on a single actuator pool. 4-year-deep open-academic prior art for: thrust-reversal wall-climbing, multi-mode-on-shared-actuator-pool reconfiguration, narrow-pipe traversal. Closes the STAR family lineage chain that begins at star-fearing-2013 and ends with dstar-zarrouk-2026 (decoupled FBEM, Jan 2026). The full 13-year-deep STAR family chain: STAR (Berkeley 2013) → RSTAR (Zarrouk 2019) → TSTAR → FSTAR → FCSTAR → AmphiSTAR → DSTAR.

## AmphiSTAR (2023-05)

- **id**: `amphistar-zarrouk-2023`
- **corpus**: academic
- **creator**: Ben-Gurion University; Avi Cohen, David Zarrouk
- **disclosure**: Cohen, A., Zarrouk, D. 'AmphiSTAR: A High-Speed Amphibious Reconfigurable Robot'. IEEE Robotics and Automation Letters 2023; ICRA 2023 demo. Ben-Gurion University, Zarrouk lab.
- **ip status**: open-permissive
- **prior art notes**: AmphiSTAR establishes 3-year-deep open-academic prior art for **terrestrial-aquatic transition in a single platform with shared ground-contact mechanism**. Directly relevant to free-humanoid-submersible (and the centaur's wetland mode-transition) — proves that wheel-paddle hybrid contact patches and sealed-enclosure amphibious operation are well-anticipated open art. Any commercial claim on amphibious humanoid robotics faces this lineage plus the deeper aquatic-robotics chain (Slocum/Seaglider, OceanOne, AmphiSTAR).

## Unitree B2 (2024-09)

- **id**: `unitree-b2-2024`
- **corpus**: private
- **creator**: Unitree Robotics (Hangzhou, China)
- **disclosure**: Unitree Robotics. B2 commercial quadruped product reveal September 2024 via unitree.com / IFA Berlin 2024. Successor to the B1 (2023). B2-W variant adds wheel-feet for hybrid wheel-leg operation.
- **ip status**: trade-secret
- **prior art notes**: Unitree B2 is the canonical 2024+ heavy-payload commercial electric quadruped (Unitree). 1.5-year-deep public-disclosure prior art for: 40 kg sustained / 120 kg burst electric quadruped, wheel-leg hybrid B2-W variant. **B2-W is architecturally similar to the STAR family wheel-leg hybrid** (round-10 entries star-fearing-2013 → dstar-zarrouk-2026) — Unitree commercializes the wheel-leg-hybrid pattern at quadruped scale. Direct shielding for any commercial quadruped claim on heavy-payload electric or wheel-leg-hybrid morphology.

## FLORES wheel-legged robot (2025-07)

- **id**: `flores-wheel-legged-2025`
- **corpus**: academic
- **creator**: FLORES authors (per arXiv:2507.22345)
- **disclosure**: FLORES authors. 'FLORES: A Reconfigured Wheel-Legged Robot for Enhanced Steering and Adaptability'. arXiv:2507.22345, July 2025. Authors per arXiv listing.
- **ip status**: open-permissive
- **prior art notes**: FLORES is a contemporary (July 2025) wheel-legged-hybrid academic publication. Architecturally distinct from the STAR family by swapping hip-roll for hip-yaw on the front legs — a design choice that complements the DSTAR sprawl-tuned approach. Shields any commercial claim on hip-yaw front-leg wheel-leg-hybrid configurations and adds to the wheel-leg prior-art chain alongside DSTAR, RSTAR, STAR, AmphiSTAR. Specific authorship and venue per the arXiv preprint.

## Decoupled STAR (DSTAR) (2026-01)

- **id**: `dstar-zarrouk-2026`
- **corpus**: academic
- **creator**: Ben-Gurion University; Tomer Siboni, Matan Coronel, David Zarrouk
- **disclosure**: Siboni, T., Coronel, M., Zarrouk, D. 'Design and Modeling of a Reconfigurable Robot: Decoupled STAR (DSTAR)'. IEEE Robotics and Automation Letters vol. 11 no. 1, January 2026, pp. 882-889. DOI: 10.1109/LRA.2025.3634888. Ben-Gurion University, Department of Mechanical Engineering / Bio-inspired Robotics Lab. Funded by Helmsley Charitable Trust + Marcus Endowment Fund.
- **ip status**: open-permissive
- **prior art notes**: DSTAR is the most recent STAR-family member, published IEEE RA-L January 2026. Establishes very-recent (4-month-deep) open-academic prior art for: decoupled-FBEM wheel-leg reconfigurable robotics, sideways rolling via asymmetric mechanical configuration, COM-shifting via independent left/right leg actuation, 18-20 cm obstacle traversal in palm-sized class. Directly anticipates free-humanoid-centaur's wheel-leg hybrid mode-switching commitment, free-humanoid-wheeled's obstacle-climbing requirement, and any commercial humanoid claim on reconfigurable wheel-leg architectures (including any mid-size extrapolation of DSTAR to humanoid scale). The full STAR family lineage (Berkeley original 2013 → Zarrouk RSTAR 2019 → AmphiSTAR 2023 → DSTAR 2026) provides 13-year-deep open-academic continuous publication coverage of every architectural element. Highly relevant for shoal dock-A wetland service: DSTAR's terrain-adaptation gait library is a published reference design for centaur-class wetland mode-transition.
