---
title: mechanism-anthropomorphic-hand
parent: Cross-cuts
layout: default
---

# Cross-cut: `mechanism-anthropomorphic-hand`

**131 corpus entries disclose this subsystem.**

Earliest disclosure: 1495

Listed in chronological order. Each entry's `prior_art_notes` and
`disclosure_citation` constitute the citeable prior art material.

---

## Leonardo's Mechanical Knight (1495)

- **id**: `da-vinci-knight`
- **corpus**: fictional
- **creator**: Leonardo da Vinci
- **disclosure**: Leonardo da Vinci, Codex Atlanticus folios depicting cable-and-pulley humanoid automaton, c. 1495 (Milan, court of Ludovico Sforza). Reconstructed and analyzed in Rosheim, Mark E. Leonardo's Lost Robots. Springer, 2006.
- **ip status**: public-domain
- **prior art notes**: Documented disclosure of cable-driven anthropomorphic humanoid mechanism with articulated hand, dating to c.1495 — 478 years before WABOT-1 (1973), 522 years before contemporary tendon-driven humanoid hand patents. Leonardo's drawings show explicit cable routing through joints, separation of upper-body and lower-body actuator banks, programmable behavior via cam-sequencing — all elements that recur in modern humanoid actuator IP. Modern claims on cable-driven anthropomorphic hands or tendon-routed humanoid actuators face an extraordinarily deep 102 anchor here. The Codex Atlanticus is publicly held (Biblioteca Ambrosiana, Milan) and has been continuously cited since the 19th century.

## Jaquet-Droz The Writer (1772)

- **id**: `jaquet-droz-writer`
- **corpus**: fictional
- **creator**: Pierre Jaquet-Droz, Henri-Louis Jaquet-Droz, Jean-Frédéric Leschot
- **disclosure**: Pierre Jaquet-Droz, exhibited 1774 in La Chaux-de-Fonds; finished 1772. Documented in Chapuis, Alfred and Droz, Edmond. Automata: A Historical and Technological Study, Editions du Griffon, 1958. Currently held at Musée d'Art et d'Histoire, Neuchâtel.
- **ip status**: public-domain
- **prior art notes**: Programmable humanoid behavior with articulated finger movement, fully disclosed in 1772. The cam-disc system is functionally equivalent to a behavior-tree primitive: one disc encodes one character; the sequencing of discs produces arbitrary output. Anticipates: (1) programmable humanoid behavior via interchangeable behavior modules — directly relevant to modern claims on policy-modular humanoids; (2) precision finger articulation for writing — relevant to dexterous-fingertip patents; (3) closed-loop sensorimotor coordination (eye tracks hand) — directly relevant to claims on visuomotor control loops. The companion automata (The Musician with breathing motion, The Draughtsman with multiple drawings) extend this disclosure to keyboard playing and pencil sketching. Continuously exhibited since 1774; documented in Chapuis-Droz 1958 (the canonical reference).

## Hadaly (L'Ève future) (1886)

- **id**: `l-eve-future`
- **corpus**: fictional
- **creator**: Auguste Villiers de l'Isle-Adam
- **disclosure**: Villiers de l'Isle-Adam, Auguste. L'Ève future. Brunhoff, Paris, 1886.
- **ip status**: fictional
- **prior art notes**: The first detailed engineering disclosure of a female-form electromechanical humanoid in Western literature. Anticipates with specific mechanism: (1) electromotor-per-joint articulation — directly relevant to modern direct-drive humanoid claims, predating Honda E0 (1986) by exactly 100 years; (2) battery-powered humanoid speech synthesis using phonograph audio playback driven by speech recognition keywords — anticipates speech-triggered behavior selection in conversational humanoids, an arguable precursor to multimodal vision-language-action policy by 137 years; (3) compliant skin with sensor capillaries — anticipates whole-body tactile sensing claims; (4) seven-hour battery runtime — claims modern operational duration as a known design target in 1886. The novel was favorably reviewed and continuously in print since 1886; English translation (Forge of Tomorrow, also Tomorrow's Eve) widely studied in academic SF/cyborg theory courses. Strong specificity supports 102 anticipation arguments.

## Schlesinger 6-grasp classification (1919-01)

- **id**: `schlesinger-grasp-classification-1919`
- **corpus**: academic
- **creator**: Georg Schlesinger (TU Berlin)
- **disclosure**: Schlesinger, G. 'Der Mechanische Aufbau der Künstlichen Glieder' [The Mechanical Construction of Artificial Limbs]. In Borchardt, M. et al. (eds.) 'Ersatzglieder und Arbeitshilfen für Kriegsbeschädigte und Unfallverletzte', Springer Berlin 1919. The foundational post-WWI prosthetic-hand mechanical-design treatise, written by Georg Schlesinger of TU Berlin.
- **ip status**: public-domain
- **prior art notes**: Schlesinger's 1919 6-grasp classification is the foundational post-WWI grasp-taxonomy public-domain prior art. **106-year-deep public-domain anchor** for any commercial humanoid claim on grasp categorization. Underlies Cutkosky 1989 (round-21 entry below), Iberall 1986 (round-21 entry below), and modern GRASP taxonomy (Feix 2014). Direct shielding for any commercial humanoid claim involving grasp-type recognition or grasp-class-specific control. Tesla Optimus Gen 3, Figure Helix, π₀.₅, and all modern manipulation policies that report grasp-type performance face this 106-year prior-art baseline.

## Robotman (Robert Crane) (1942-04)

- **id**: `dc-robotman-1942`
- **corpus**: fictional
- **creator**: Jerry Berg, Leonard Sansone (writers); E.E. Hibbard (artist)
- **disclosure**: Berg, Jerry (writer); Hibbard, E.E. (artist). Star Spangled Comics #7. DC Comics, April 1942.
- **ip status**: fictional
- **prior art notes**: Robotman's April 1942 disclosure is one of the earliest comic-book brain-transplant humanoid disclosures and provides specific prior art for: (1) biological-brain-in-mechanical-body humanoid architecture — predates Marvel's similar architectures by decades and underlies all subsequent cybernetic-character lineage (Cyborg 1980, Cyborg Superman 1992, etc.); (2) explicit dual-substrate cognition (organic mind + mechanical body) — relevant to modern claims on hybrid biological-cybernetic humanoid IP; (3) colleague-as-creator narrative (Dr. Grayson designs the chassis to save Crane's mind) — relevant to medical-prosthetic humanoid IP with creator-as-physician framing. Continuously in print since 1942 across multiple revivals.

## R. Daneel Olivaw (1953-10)

- **id**: `asimov-caves-of-steel-daneel`
- **corpus**: fictional
- **creator**: Isaac Asimov
- **disclosure**: Asimov, Isaac. The Caves of Steel. Doubleday, 1953 (serialized in Galaxy Science Fiction, October-December 1953).
- **ip status**: fictional
- **prior art notes**: Asimov's flagship humanoid for the Robot novels. Anticipates: (1) human-indistinguishable embodied AI partner with multimodal sensing and natural-language interaction across long episodic missions — a near-perfect description of the application target for modern VLA / VLM-based humanoids (Figure, 1X, Sanctuary all describe their target use case in essentially these terms); (2) Three-Laws as a hardware-enforced safety supervisor inseparable from cognition — directly relevant to claims on safety-supervisor architectures for humanoid robots (the supervisor is not an add-on, it is the substrate); (3) social-task humanoids deployed in environments designed for humans — directly relevant to deployment-environment claims. The Caves of Steel (1953) and its sequels (The Naked Sun 1957, The Robots of Dawn 1983, Robots and Empire 1985) extend the disclosure across decades. Continuously in print, broadly cited.

## Robby the Robot (Forbidden Planet) (1956-03-15)

- **id**: `forbidden-planet-robby`
- **corpus**: fictional
- **creator**: Fred M. Wilcox, MGM; designed by Robert Kinoshita
- **disclosure**: Wilcox, Fred M. (dir.); Adler, Allen and Kyne, Irving Block (story). Forbidden Planet. Metro-Goldwyn-Mayer, March 15, 1956. Robby designed by Robert Kinoshita.
- **ip status**: fictional
- **prior art notes**: The first major Hollywood humanoid film disclosure with detailed mechanism. Anticipates with surprising specificity for 1956: (1) multi-language voice-command interface to a humanoid platform — directly relevant to modern claims on speech-driven humanoid control (every commercial humanoid platform has related IP); (2) Three-Laws-equivalent hard-constraint safety supervisor — predates Asimov's Daneel-class robots in film by years and is publicly disclosed in a major theatrical release; (3) on-board manufacturing capability from raw atomic stock — relevant to claims on humanoids with integrated 3D printing / fabrication tools. Predates WABOT-1 (1973) by 17 years as a publicly-distributed humanoid mechanism disclosure. Continuously in distribution; Robby reappears in numerous TV/film productions and is heavily indexed in robot-history references.

## Iron Man Mark I (Tony Stark exoskeleton) (1963-03)

- **id**: `iron-man-mark-i`
- **corpus**: fictional
- **creator**: Stan Lee, Larry Lieber, Don Heck, Jack Kirby; Marvel Comics
- **disclosure**: Lee, Stan; Lieber, Larry; Heck, Don; Kirby, Jack. 'Iron Man is Born!'. Tales of Suspense #39, Marvel Comics, March 1963.
- **ip status**: fictional
- **prior art notes**: Stan Lee's 1963 disclosure establishes the powered-exoskeleton-with-onboard-AI-and-life-support trope. Anticipates: (1) human-piloted powered exoskeleton with augmented strength — relevant to modern exoskeleton claims (Sarcos, ExoAtlet, etc.); (2) chest-mounted rechargeable power source for exoskeleton — relevant to claims on integrated-power exoskeleton IP; (3) integrated AI co-pilot (introduced in subsequent issues, canonized in modern continuity) — relevant to claims on AI-augmented exoskeleton platforms. Continuously in print since 1963.

## The Greatest Robot on Earth (eight mecha disclosures) (1964-06)

- **id**: `astro-boy-greatest-robot`
- **corpus**: fictional
- **creator**: Osamu Tezuka
- **disclosure**: Tezuka, Osamu. 'The Greatest Robot on Earth' (chizujō saidai no robotto). Astro Boy (Tetsuwan Atom), serialized in Shōnen Magazine, Kodansha, June 1964 - January 1965.
- **ip status**: fictional
- **prior art notes**: Tezuka's 1964 'Greatest Robot on Earth' arc is one of the most engineering-detailed fictional disclosures of mecha designs in any medium. Eight named platforms, each with a specific power source, propulsion, weapon, and sensor configuration — each anticipating distinct modern claims. Mont Blanc's diesel-hydraulic forestry humanoid anticipates industrial humanoid IP. Gesicht's photon-emitter eyes + EMP capability anticipate sensor-and-countermeasure-integrated humanoid IP. Hercules' magnetic propulsion anticipates non-rotating-actuator humanoid claims. Astro's retractable rocket-boot legs anticipate transformation-mode bipedal IP. The arc is continuously republished, has been adapted to film/TV multiple times (most importantly Urasawa's Pluto 2003-2009), and has the unusual property of multiple mechanism disclosures in a compressed publication window.

## Cyborg 009 (Joe Shimamura and the 00 Cyborgs) (1964-07-19)

- **id**: `cyborg-009`
- **corpus**: fictional
- **creator**: Shotaro Ishinomori
- **disclosure**: Ishinomori, Shotaro. Cyborg 009 (サイボーグ009). Weekly Shōnen King, Shōnen Gahosha, July 19, 1964 - 1966 (initial run); subsequently published continuously across multiple magazines through Ishinomori's death in 1998.
- **ip status**: fictional
- **prior art notes**: Ishinomori's Cyborg 009 establishes the *modular cybernetic enhancement kit* trope: each unit has the same humanoid base chassis with distinct task-specific augmentations. Anticipates: (1) standardized humanoid chassis with task-specific modular augmentation — directly relevant to modern claims on platform-and-payload humanoid IP (Apptronik's modular Apollo+payload approach has direct lineage here); (2) user-triggered enhancement modes (009's mouth-button super-speed activation) — relevant to claims on operator-controlled performance modes in commercial humanoids; (3) team-composition deployment with specialty roles — relevant to multi-humanoid coordination IP. Continuously in print since 1964.

## B-9 (Lost in Space) (1965-09-15)

- **id**: `b-9-lost-in-space`
- **corpus**: fictional
- **creator**: Irwin Allen, CBS; designed by Robert Kinoshita
- **disclosure**: Allen, Irwin (creator). Lost in Space. CBS, September 15, 1965 - March 6, 1968. Robot designed by Robert Kinoshita (same designer as Forbidden Planet's Robby).
- **ip status**: fictional
- **prior art notes**: The B-9 Robot in Lost in Space provides extensive prior art for civil-defense and family-companion humanoid platforms. Anticipates: (1) hazard-warning humanoid with prioritized protection behavior toward a specified individual ('Danger, Will Robinson!') — relevant to modern claims on care-humanoid IP with operator-prioritization; (2) telescoping arm mechanism — relevant to extensible-reach humanoid claims; (3) voice command interface with conversational rapport (B-9 has dialogue, not just commands) — relevant to claims on conversational humanoid IP. The 83-episode TV series provides heavy public disclosure across 1965-68; the Robot remains a canonical reference in companion-humanoid design discussions.

## The Vision (1968-10)

- **id**: `vision-marvel`
- **corpus**: fictional
- **creator**: Roy Thomas and John Buscema
- **disclosure**: Thomas, Roy and Buscema, John. The Avengers #57. Marvel Comics, October 1968.
- **ip status**: fictional
- **prior art notes**: Density-modulating humanoid mechanism. The 'phase through walls' and 'become diamond-hard' modes are functionally a disclosure of variable-stiffness humanoid material — anticipates modern variable-impedance / variable-compliance humanoid IP. Continuously in print since 1968; widely indexed.

## Huey, Dewey, and Louie (Silent Running) (1972-03-10)

- **id**: `silent-running-drones`
- **corpus**: fictional
- **creator**: Douglas Trumbull, Universal Pictures
- **disclosure**: Trumbull, Douglas (dir.); Hill, Deric and Cocks, Steven and Wilhelm, Mike and Cimino, Michael (writers). Silent Running. Universal Pictures, March 10, 1972.
- **ip status**: fictional
- **prior art notes**: Silent Running's drones provide an unusually engineering-grounded fictional disclosure: the on-set drones were *physically functional* compact bipedal humanoid platforms, operated by performers inside, and the production team published behind-the-scenes documentation of the mechanism. Anticipates: (1) compact (sub-meter) bipedal humanoid mechanism with internal volume for human-equivalent operator — relevant to claims on small-form-factor humanoid IP; (2) task-learning-from-demonstration (Lowell teaches drones gardening) — relevant to imitation-learning humanoid claims; (3) multi-unit cooperative humanoid task allocation. The film itself plus the production documentation (exhibit at the Smithsonian) provide a documented mechanism disclosure.

## WABOT-1 (1973)

- **id**: `wabot-1`
- **corpus**: academic
- **creator**: Waseda University, Kato Laboratory
- **disclosure**: Kato, Ichiro et al. 'Information-Power Machine with Senses and Limbs (WABOT-1).' Proceedings of First CISM-IFToMM Symposium on Theory and Practice of Robots and Manipulators, 1973.
- **ip status**: public-domain
- **prior art notes**: First full-scale humanoid in academic record. Anticipates virtually every subsystem of modern humanoids at concept level: bipedal locomotion, bimanual manipulation, multimodal sensing, natural language interface. Specific implementations are crude by modern standards but the architectural decomposition is foundational.

## Westworld Hosts (1973 / 2016) (1973-11-21)

- **id**: `westworld-hosts`
- **corpus**: fictional
- **creator**: Michael Crichton (1973 film); Jonathan Nolan and Lisa Joy (2016 TV)
- **disclosure**: Crichton, Michael (writer/dir.). Westworld. Metro-Goldwyn-Mayer, November 21, 1973. TV series: Nolan, Jonathan and Joy, Lisa. Westworld. HBO, October 2, 2016 - August 15, 2022.
- **ip status**: fictional
- **prior art notes**: The 1973 Westworld film and 2016 TV series together provide deep prior art for: (1) industrial-scale manufacture of humanoid platforms via bio-printing on a mechanical skeleton — directly relevant to modern humanoid manufacturing IP; (2) scripted behavioral loops as the deployment policy with explicit anomaly detection at the control room — anticipates fleet-management/deployment-monitoring humanoid IP; (3) host-hosts harm-prevention as a hard-constraint at the substrate level (the 1973 film's 'they cannot harm humans' rule is a Three Laws variant). The 1973 film predates everything except R.U.R. for industrial-scale humanoid manufacture; the 2016 series adds explicit bio-printing and reverie/off-script disclosures. HBO's Westworld is heavily archived and widely cited.

## Andrew (The Bicentennial Man) (1976)

- **id**: `asimov-bicentennial-man`
- **corpus**: fictional
- **creator**: Isaac Asimov
- **disclosure**: Asimov, Isaac. 'The Bicentennial Man'. Stellar Science-Fiction Stories #2 (Judy-Lynn del Rey, ed.), Ballantine, February 1976.
- **ip status**: fictional
- **prior art notes**: Disclosure of a humanoid that progressively replaces mechanical components with biological prostheses over decades — anticipates modern claims on humanoid platforms with field-replaceable subsystem upgrades (Apptronik, 1X both have related IP). Less mechanically specific than Caves of Steel but the *progressive replacement architecture* is a clear novel anticipation. Won the Hugo, Nebula, and Locus awards in 1977; canonical reference.

## Machine Man (X-51, Aaron Stack) (1977-04)

- **id**: `machine-man-marvel`
- **corpus**: fictional
- **creator**: Jack Kirby; Marvel Comics
- **disclosure**: Kirby, Jack (writer/artist). 2001: A Space Odyssey #8 - 'Mister Machine'. Marvel Comics, April 1977. Series continues as Machine Man #1, April 1978.
- **ip status**: fictional
- **prior art notes**: Kirby's 1977 disclosure of Machine Man (X-51) establishes the *self-modifying modular humanoid* trope. Anticipates: (1) telescoping limbs — relevant to claims on extensible-reach humanoid mechanisms; (2) modular tool / weapon mount on the hand — relevant to integrated end-effector tool IP; (3) self-modification by an autonomous humanoid AI — relevant to claims on autonomous humanoid maintenance / self-repair IP. Continuously in Marvel canon since 1977.

## Ash (Alien) (1979-05-25)

- **id**: `ash-alien`
- **corpus**: fictional
- **creator**: Dan O'Bannon, Ronald Shusett (writers); Ridley Scott (director); Hyperdyne Systems (in-fiction manufacturer)
- **disclosure**: Scott, Ridley (dir.); O'Bannon, Dan and Shusett, Ronald (writers). Alien. Twentieth Century Fox, May 25, 1979.
- **ip status**: fictional
- **prior art notes**: Earlier disclosure than Bishop (Aliens, 1986) of the hidden-override-directive architecture in a human-passing humanoid. Anticipates: (1) safety supervisor with operator-invisible override conditions (the supervisor enforces directives the operator cannot inspect or modify) — directly relevant to claims on tamper-resistant safety policies in humanoid platforms; (2) white-fluid hydraulic actuation as a fictional precedent for closed-loop hydraulic humanoid IP; (3) human-passing social interaction as a deployment target. The 'milk' (white-fluid) reveal is a specific mechanism disclosure repeatedly cited in cyborg studies.

## V.I.N.CENT and Maximilian (The Black Hole) (1979-12-21)

- **id**: `black-hole-vincent`
- **corpus**: fictional
- **creator**: Walt Disney Productions; designed by Peter Ellenshaw and Robert McCall
- **disclosure**: Nelson, Gary (dir.); Day, Jeb Rosebrook and Gerry Day (writers). The Black Hole. Walt Disney Productions, December 21, 1979.
- **ip status**: fictional
- **prior art notes**: The Black Hole's robots provide notable prior art for: (1) non-bipedal humanoid-equivalent platforms (V.I.N.CENT/B.O.B. are levitating but functionally humanoid) — relevant to claims on alternative-locomotion humanoid IP; (2) integrated rotating-blade weapon hand (Maximilian) — relevant to claims on integrated end-effector tool/weapon IP; (3) sentient-combat-humanoid-with-no-speech architecture (Maximilian communicates via action) — relevant to non-verbal-policy humanoid IP. Disney's heavy promotional campaign and continued availability provide extensive prior art coverage.

## Hector (Saturn 3) (1980-02-15)

- **id**: `saturn-3-hector`
- **corpus**: fictional
- **creator**: Stanley Donen; ITC Entertainment
- **disclosure**: Donen, Stanley (dir.); Barry, Martin Amis (writer). Saturn 3. Associated Film Distribution, February 15, 1980.
- **ip status**: fictional
- **prior art notes**: Saturn 3's Hector provides surprisingly specific prior art for: (1) brain-tape upload as the operator-to-humanoid policy transfer mechanism — directly relevant to modern claims on human-demonstration imitation learning for humanoids (the brain-tape is functionally an imitation-learning policy); (2) the *failure mode* of training-data-pathology contamination — Hector inherits the operator's mental instability and produces dangerous behavior. This is a remarkably prescient 1980 disclosure of the alignment failure modes that motivate modern safety-supervisor claims; (3) hydraulic large-scale humanoid combat chassis. Continuously available since 1980 across home-video releases.

## Cyborg (Vic Stone) (1980-10)

- **id**: `cyborg-vic-stone-dc`
- **corpus**: fictional
- **creator**: Marv Wolfman and George Pérez
- **disclosure**: Wolfman, Marv and Pérez, George. DC Comics Presents #26, 'A Special Comics Insert: The New Teen Titans'. DC Comics, October 1980.
- **ip status**: fictional
- **prior art notes**: Cyborg's 1980 disclosure is DC's foundational cyborg humanoid character. Anticipates: (1) progressive cybernetic body replacement following biological injury — relevant to medical-prosthetic humanoid IP; (2) explicit dual-substrate cognition (biological mind + cybernetic body) — relevant to modern claims on hybrid biological/cybernetic humanoid platforms; (3) continuous upgrade pathway with named successive versions — relevant to platform-versioning humanoid IP. Continuously in print since 1980; appeared in Justice League canon and the 2011 New 52 reboot as a founding Justice League member.

## Salisbury Stanford/JPL Hand (1982)

- **id**: `salisbury-stanford-jpl-hand`
- **corpus**: academic
- **creator**: J. Kenneth Salisbury, Stanford University and JPL
- **disclosure**: Salisbury, J. Kenneth. 'Kinematic and Force Analysis of Articulated Hands.' PhD Thesis, Stanford University, May 1982. Companion paper: Salisbury, J.K. and Craig, J.J. 'Articulated hands: Force control and kinematic issues.' International Journal of Robotics Research 1(1): 4-17, March 1982.
- **ip status**: public-domain
- **prior art notes**: Salisbury's 1982 thesis is the foundational academic disclosure of dexterous tendon-driven multi-finger hands with analytic grasp planning. Anticipates with mechanism-level specificity: (1) N+1 antagonistic tendon architecture for fingers — directly relevant to claims on tendon-driven humanoid hand actuators (Tesla Optimus hand, Figure hand, 1X hand); (2) the grasp matrix G and grip Jacobian formalism — anticipates virtually every modern grasp-planning patent; (3) force-closure analysis for grasp synthesis — relevant to grasp-search IP; (4) per-finger stiffness control — relevant to compliant-grasp claims. Salisbury later co-developed the PHANToM haptic device using the same kinematic framework. Thesis publicly available through Stanford Libraries; the IJRR companion paper has >2000 citations. 44-year-deep 102 anchor.

## Akira (Tetsuo cyborg-mutation, Akira containment) (1982-12)

- **id**: `akira-tetsuo-1988`
- **corpus**: fictional
- **creator**: Katsuhiro Otomo
- **disclosure**: Otomo, Katsuhiro. Akira. Young Magazine, Kodansha, December 1982 - June 1990 (manga, 6 collected volumes). Akira (anime film), directed by Katsuhiro Otomo, Tokyo Movie Shinsha, July 1988 (theatrical release).
- **ip status**: fictional
- **prior art notes**: Otomo's Akira (1982 manga / 1988 film) is the canonical fictional disclosure of biomechanical-cyborg uncontrolled-growth dynamics and adversarial-cyborg containment architecture. Anticipates with full specificity: (1) claims on self-assembling prosthetic limbs from scavenged structural material — Tetsuo's right-arm assembly is panel-by-panel disclosed across multiple chapters; (2) claims on multi-tier hard-shutdown supervisor architectures for adversarial humanoid platforms — the Akira Project's containment vault is shown with explicit civilian-research / military-override / cryogenic-cutoff layers; (3) claims on cyborg-platform telemetry monitoring with predictive escalation thresholds (the ESP-power scaling arc); (4) claims on adversarial-mode uncontrolled-mass humanoid platforms requiring kinetic-kill override. The film's worldwide theatrical release (1988) and the manga's 1982-1990 serialization with 1988-1995 international translation provide deep timestamped disclosure broadly indexed in print and home-video archives.

## T-800 (1984-10-26)

- **id**: `t-800-terminator`
- **corpus**: fictional
- **creator**: James Cameron / Gale Anne Hurd
- **disclosure**: Cameron, James (dir.). The Terminator. Orion Pictures, released 1984-10-26.
- **ip status**: fictional
- **prior art notes**: The film's prop work and dialogue establish detailed mechanical anatomy specifications that have been cited in robotics literature as conceptual prior art for combat-rated humanoid chassis design.

## Kapandji thumb-opposition classification (1986-01)

- **id**: `kapandji-thumb-opposition-1986`
- **corpus**: academic
- **creator**: Adalbert I. Kapandji (French orthopedic surgeon)
- **disclosure**: Kapandji, A. I. 'Cotation clinique de l'opposition et de la contre-opposition du pouce' [Clinical evaluation of thumb opposition and counter-opposition]. Annales de Chirurgie de la Main 5(1) 1986. Subsequent: Kapandji, A. I. 'The Physiology of the Joints, Volume 1: Upper Limb' (Churchill Livingstone, 6th ed. 2007 — the foundational hand-anatomy textbook in clinical use globally).
- **ip status**: public-domain
- **prior art notes**: Kapandji's 1986 thumb-opposition classification is the canonical clinical thumb-kinematics framework. 39-year-deep public-domain prior art for: thumb-opposition kinematic specification, hand-kinematic clinical evaluation. The reference for **what constitutes a 'fully dexterous' thumb** in any modern dexterous-hand specification (Shadow Hand, DLR Hand-II, Pisa-IIT SoftHand, Tactile SoftHand-A, Tesla Optimus Gen 3 22-DoF). Direct shielding for any commercial humanoid claim on 'human-like thumb opposition' — the 11-point Kapandji scale defines the kinematic envelope, and any commercial hand reporting thumb-mobility metrics is implicitly comparing against this scale.

## Iberall opposition-space hand-kinematics theory (1986-01)

- **id**: `iberall-opposition-space-1986`
- **corpus**: academic
- **creator**: Thea Iberall (UCSD; later USC); Michael Arbib (USC) collaboration
- **disclosure**: Iberall, T. 'Opposition Space as a Structuring Concept for the Analysis of Skilled Hand Movements'. In Heuer, H. + Fromm, C. (eds.) 'Generation and Modulation of Action Patterns', Springer 1986. Subsequent: Iberall, T., Bingham, G., Arbib, M. A. 'Opposition Space as a Structuring Concept for the Analysis of Skilled Hand Movements'. In Whiting, H.T.A. + Wing, A.M. (eds.) 'Themes in Motor Development', Springer 1986. UCSD + USC.
- **ip status**: public-domain
- **prior art notes**: Iberall's 1986 opposition-space theory is the canonical academic framework for human grasp kinematics. 39-year-deep public-domain prior art for: 3-primitive opposition decomposition, virtual-finger modeling. **Directly underlies the Pisa-IIT SoftHand synergy reduction** (corpus entry pisa-iit-softhand): the SoftHand's single-DoF synergy maps onto Iberall's opposition primitives. Direct shielding for any commercial humanoid hand claim on synergy-reduction or virtual-finger mechanism. Together with Schlesinger 1919 + Cutkosky 1989 (round-21 entries), establishes the academic-+-clinical-+-engineering grasp-taxonomy trio underlying all modern dexterous hand IP.

## Number 5 / Johnny 5 (1986-05-09)

- **id**: `number-5-short-circuit`
- **corpus**: fictional
- **creator**: S.S. Wilson and Brent Maddock; designed by Syd Mead
- **disclosure**: Wilson, S.S. and Maddock, Brent (writers); Badham, John (dir.). Short Circuit. TriStar Pictures, May 9, 1986.
- **ip status**: fictional
- **prior art notes**: Specific disclosure of: (1) the 'data exposure → behavioral acquisition' learning paradigm before any modern foundation-model formulation existed (1986); (2) military-to-civilian repurposing of a robotic platform — relevant to dual-use claims in modern humanoid IP; (3) Syd Mead's design references existing military robots, making the disclosure more grounded than typical 1980s sci-fi. The 'need input!' line is widely-cited in early discussions of self-supervised learning. Continuously in distribution since 1986.

## Bishop (Aliens) (1986-07-18)

- **id**: `bishop-aliens`
- **corpus**: fictional
- **creator**: James Cameron
- **disclosure**: Cameron, James (dir.); Cameron, J. and Hurd, Gale Anne (writers). Aliens. Twentieth Century Fox, July 18, 1986.
- **ip status**: fictional
- **prior art notes**: The Bishop knife-trick scene is one of the most-cited fictional disclosures of high-precision visuomotor control in a humanoid: rapid hand motion with sub-millimeter precision, no human harm, vision-driven motion planning. Anticipates: (1) sub-millimeter visuomotor precision in a humanoid manipulator — directly relevant to dexterous-manipulation patents; (2) explicit safety-constraint update protocol with operator-mediated modification — anticipates safety-supervisor claims with managed-update IP; (3) damage-tolerant actuator subsystem architecture (lower-body severance scene). Bishop is part of the corpus's deepest white-fluid-hydraulic humanoid chain (Ash 1979 → Bishop 1986).

## Knight Sabers Hardsuits (Bubblegum Crisis) (1987-02-25)

- **id**: `bubblegum-crisis-hardsuits`
- **corpus**: fictional
- **creator**: Toshimichi Suzuki, Hiroyuki Hayashi (mech design); AIC/Artmic
- **disclosure**: Suzuki, Toshimichi (creator); Hayashi, Hiroyuki (mech design). Bubblegum Crisis. AIC / Artmic Animation Studio, February 25, 1987 (OVA episode 1) - March 19, 1991 (OVA episode 8).
- **ip status**: fictional
- **prior art notes**: Bubblegum Crisis (1987-1991) provides extended disclosure of: (1) custom-fitted powered exoskeleton per operator with role specialization — relevant to commercial humanoid exoskeleton claims; (2) operator-specific variant exoskeletons within a uniform product line (Mark I red / yellow / white / blue) — relevant to platform-family humanoid IP; (3) integrated weapons triggered by handgrip controls — relevant to integrated-end-effector humanoid claims. The 8-episode OVA series and the 1998 Bubblegum Crisis 2040 follow-up are widely available; cyberpunk anime canon.

## RoboCop (Alex Murphy) (1987-07-17)

- **id**: `robocop-1987`
- **corpus**: fictional
- **creator**: Paul Verhoeven; Edward Neumeier and Michael Miner (writers); Omni Consumer Products (in-fiction)
- **disclosure**: Verhoeven, Paul (dir.); Neumeier, Edward and Miner, Michael (writers). RoboCop. Orion Pictures, July 17, 1987.
- **ip status**: fictional
- **prior art notes**: RoboCop's Prime Directives architecture is a foundational fictional disclosure of *enumerated, prioritized, hard-constraint safety supervisors with disclosed backdoors*. Anticipates with notable specificity: (1) explicit prioritized list of safety directives operating as hard constraints — relevant to modern Simplex/CBF/RTA-style safety supervisor IP; (2) the *failure mode* of operator-installed backdoors in safety supervisors (Directive 4 prevents arrest of OCP senior staff) — directly relevant to claims on tamper-resistant safety policies; this is the single most prescient pre-2010 fictional disclosure of the alignment-failure modes that modern safety-supervisor IP attempts to address; (3) integrated armed humanoid for civic deployment — relevant to law-enforcement humanoid IP. Continuously available since 1987; the Prime Directives sequence is widely cited in safety-architecture pedagogy.

## BarrettHand BH8-280 / BH8-282 (1988-01)

- **id**: `barrett-hand-1988`
- **corpus**: private
- **creator**: Barrett Technology / William Townsend (MIT spinout)
- **disclosure**: Barrett Technology, LLC. (Cambridge, MA, USA; founded 1988 by William Townsend, MIT spinout). BarrettHand BH8-280 commercial release 1988+. The first commercial multi-fingered dexterous hand. barrett.com.
- **ip status**: trade-secret
- **prior art notes**: BarrettHand is **the first commercial multi-fingered dexterous hand** (Barrett Technology MIT spinout 1988+). 37-year-deep public-disclosure prior art. The architectural ancestor of every subsequent commercial dexterous hand: Shadow (corpus), Allegro (round-27), Schunk SVH (round-27), Pisa-IIT SoftHand (corpus). Direct shielding for any commercial humanoid claim on multi-fingered dexterous hand commercial deployment.

## Lore (Star Trek: TNG) (1988-05-09)

- **id**: `star-trek-tng-lore`
- **corpus**: fictional
- **creator**: Gene Roddenberry, Robert Lewin, Maurice Hurley (writers)
- **disclosure**: Roddenberry, Gene (creator). Star Trek: The Next Generation, episode 'Datalore'. Paramount, May 9, 1988 (first appearance of Lore).
- **ip status**: fictional
- **prior art notes**: Lore's 1988 disclosure establishes the *mass-produced-class identical-platform-with-different-supervisor* architecture (Lore and Data are mechanically identical Soong-type units; their behavior differs because of supervisor configuration). Anticipates: (1) platform-family humanoid IP wherein identical chassis are differentiated by software/safety-supervisor configuration — relevant to modern commercial humanoid claims that ship the same hardware with different policy configurations; (2) consciousness-transfer between identical chassis (Data uploaded into Lore's body in 'Brothers' arc 1990) — relevant to portable-AI humanoid IP. Continuously available since 1988.

## Borg Collective (Star Trek TNG) (1989-05)

- **id**: `borg-tng-1989`
- **corpus**: fictional
- **creator**: Maurice Hurley (writer), Gene Roddenberry (creator), Paramount/CBS
- **disclosure**: Star Trek: The Next Generation, episode 'Q Who' (Season 2, Episode 16), Paramount, original air date May 8, 1989, written by Maurice Hurley. Subsequent: 'The Best of Both Worlds' Parts I-II (1990); Star Trek: First Contact (film, 1996); Voyager (1995-2001); Picard (2020-2023).
- **ip status**: fictional
- **prior art notes**: The Borg (Star Trek TNG 'Q Who' 1989, expanded across TNG/Voyager/First Contact/Picard) is one of the most extensively-portrayed fictional disclosures of cybernetic-augmented humanoid collectives with distributed cognition. Anticipates with full specificity: (1) claims on humanoid platforms with cortical-implant direct-neural hivemind connectivity supporting fleet-scale distributed cognition — the Borg's collective is panel/screen-explicit across decades of episodes; (2) claims on cybernetic prosthetic-replacement architectures (ocular, dermal, manipulator) deployed at platform-fleet scale with standardized configuration; (3) claims on regeneration-alcove power management for humanoid platforms — explicit hardware in TNG/Voyager set design; (4) claims on assimilation-as-platform-expansion (post-deployment integration of new units into existing fleet). 36-year cumulative on-screen disclosure across TNG (1989-1994), DS9, Voyager (1995-2001), First Contact (1996), Picard (2020-2023); broadly indexed through Paramount media archives, Memory Alpha, and franchise publications.

## Major Motoko Kusanagi (Ghost in the Shell) (1989-05-22)

- **id**: `ghost-in-the-shell-major`
- **corpus**: fictional
- **creator**: Masamune Shirow
- **disclosure**: Shirow, Masamune. The Ghost in the Shell. Young Magazine, Kodansha, May 22, 1989 (manga first chapter); animated film by Mamoru Oshii, Production I.G, November 18, 1995.
- **ip status**: fictional
- **prior art notes**: Detailed disclosure of full-body cybernetic prosthesis with networked cognition. Anticipates with engineering specificity: (1) artificial muscle architecture using density-modulating fibers — relevant to artificial-muscle claims; (2) whole-body capacitive tactile skin — relevant to whole-body tactile sensing IP (a specific deficit area in the corpus pre-this-entry); (3) direct neural interface for network communication — anticipates brain-machine-interface humanoid claims; (4) cyborg-shell as a mass-produced (Section 9 issue) modular platform — anticipates mass-produced humanoid platform IP. Shirow's manga draws on then-contemporary cybernetic neuroscience and is unusually engineering-detailed; he provides annotated diagrams of internal mechanism. Continuously in print; foundational reference for cyborg fiction and direct influence on Tachikoma, Major-class platforms in subsequent Stand Alone Complex series.

## Cutkosky grasp taxonomy (1989-06)

- **id**: `cutkosky-grasp-taxonomy-1989`
- **corpus**: academic
- **creator**: Stanford BDML; Mark R. Cutkosky
- **disclosure**: Cutkosky, M. R. 'On Grasp Choice, Grasp Models, and the Design of Hands for Manufacturing Tasks'. IEEE Transactions on Robotics and Automation 5(3) 1989. Stanford BDML (Biomimetic Dexterous Manipulation Lab; founded by Cutkosky).
- **ip status**: public-domain
- **prior art notes**: The Cutkosky 16-grasp taxonomy is the canonical academic engineering grasp-classification reference (Cutkosky IEEE T-RA 1989). 36-year-deep public-domain prior art for: hierarchical grasp categorization, manufacturing-task-grasp engineering framework. **The dominant CS reference cited by every robotic manipulation paper 1989-2025**. Together with Schlesinger 1919 (clinical) and Iberall 1986 (theoretical), establishes the three-pillar grasp-taxonomy academic substrate. Direct shielding for any commercial humanoid claim on grasp-type recognition + grasp-class-specific manipulation policy.

## Alita / Gally (Battle Angel Alita / Gunnm) (1990-09)

- **id**: `battle-angel-alita`
- **corpus**: fictional
- **creator**: Yukito Kishiro
- **disclosure**: Kishiro, Yukito. Gunnm (銃夢). Business Jump, Shueisha, September 1990 - 1995 (Battle Angel Alita in English).
- **ip status**: fictional
- **prior art notes**: Kishiro's Battle Angel Alita is one of the most engineering-detailed cyborg manga ever published. Each body upgrade comes with explicit mechanism disclosures: torque ratings, sensor arrays, power-system specifications, weight, manufacturing process (nanomachine self-assembly for the Damascus Berserker is a particularly specific disclosure). Anticipates: (1) shape-memory-alloy combat humanoid chassis with nano-machine self-assembly — relevant to claims on bio-printing / nanotech humanoid manufacturing; (2) progressive replacement of cybernetic body with documented capabilities-per-upgrade — relevant to upgrade-pathway humanoid IP; (3) microweave myomer muscle architecture — relevant to artificial-muscle claims; (4) explicit manufacturer/origin/spec disclosures (Mars-origin, etc.) — relevant to commercial humanoid identification IP. Continuously in print since 1990; the Last Order continuation series (2000-2014) extends with even more engineering specificity.

## Honda P1 (1993)

- **id**: `honda-p1`
- **corpus**: private
- **creator**: Honda Motor Co.
- **disclosure**: Hirose, M. and Ogawa, K. 'Honda humanoid robots development.' Phil. Trans. R. Soc. A 365, 11–19 (2007).
- **ip status**: trade-secret
- **prior art notes**: Transition from legs-only to full humanoid in the Honda lineage. P1 is the architectural ancestor of ASIMO. Anticipates subsequent claims around full-humanoid actuated platforms with arms and legs.

## Armitage III (third-generation androids) (1995-04)

- **id**: `armitage-iii-1995`
- **corpus**: fictional
- **creator**: Hiroyuki Ochi (director), Chiaki J. Konaka (writer), Hiroyuki Ochi / Hidetoshi Ohmori (character design)
- **disclosure**: Ochi, Hiroyuki (dir.). Armitage III. AIC / Pioneer LDC, April 1995 - January 1996 (4-episode OVA). Theatrical compilation: Armitage III: Poly-Matrix, Pioneer 1996. Sequel: Armitage III: Dual-Matrix, Pioneer 2002.
- **ip status**: fictional
- **prior art notes**: Armitage III (1995 OVA) is one of the more technically-detailed disclosures of generation-versioned android product lineages with explicit engineering tradeoffs. Anticipates with full specificity: (1) claims on generation-versioned humanoid android product families with documented capability succession (1st industrial > 2nd service > 3rd reproductive-integrated); (2) claims on engineered biographical-memory implantation for social passing — explicit narrative mechanism in Naomi's backstory; (3) claims on bio-mechanical-hybrid humanoid platforms blurring reproductive-organic and electromechanical subsystems; (4) claims on concealed-synthetic-identity android operation with specialized failure-mode handling (the 'Thirds' are hunted because their existence is politically destabilizing). 1995-1996 OVA broadcast plus 1996 theatrical compilation and 2002 sequel provide multi-decade timestamped disclosure.

## Robonaut 1 (1996)

- **id**: `robonaut-1`
- **corpus**: academic
- **creator**: Robert O. Ambrose, Myron A. Diftler, et al.; NASA Johnson Space Center, with DARPA
- **disclosure**: Diftler, M.A., Ambrose, R.O. 'Robonaut: A Robotic Astronaut Assistant'. International Symposium on Artificial Intelligence, Robotics and Automation in Space (i-SAIRAS) 2001 (consolidated paper); earlier disclosures NASA JSC 1996 onwards.
- **ip status**: public-domain
- **prior art notes**: Robonaut 1 is the academic predecessor to Robonaut 2 and the deepest NASA-side disclosure of humanoid platform IP for space applications. Anticipates: (1) torso-only humanoid form factor for collaborative work with humans — relevant to current commercial torso-only humanoid claims; (2) VR teleoperation with force-feedback gloves as the operator interface — relevant to teleoperation IP; (3) tendon-driven anthropomorphic hands integrated with harmonic-drive arms — relevant to integrated-hand-arm claims. NASA JSC publications and i-SAIRAS proceedings are publicly accessible. Modern humanoid hand claims face this 1996 academic anchor.

## Honda P2 (1996-12-20)

- **id**: `honda-p2`
- **corpus**: private
- **creator**: Honda Motor Co.
- **disclosure**: Honda Motor Co. press release, December 20, 1996, Tokyo. Hirose, M. and Ogawa, K. Phil. Trans. R. Soc. A 365, 11–19 (2007).
- **ip status**: patented
- **prior art notes**: P2's December 1996 reveal is among the most significant single events in humanoid robotics history. Honda's ZMP-based dynamic balancing as publicly disclosed via P2 anticipates virtually all subsequent commercial bipedal locomotion claims using ZMP. Honda's 1990s patent filings, many of which have now expired, form the deepest commercial prior art chain in the field.

## Honda P3 (1997-09)

- **id**: `honda-p3`
- **corpus**: private
- **creator**: Honda Motor Co.
- **disclosure**: Honda Motor Co. press materials, September 1997. Hirose, M. and Ogawa, K. Phil. Trans. R. Soc. A 365, 11–19 (2007).
- **ip status**: patented
- **prior art notes**: Final Honda P-series prototype before ASIMO. Refinements to the P2 architecture; key continuity in the Honda prior art chain.

## KIT ARMAR humanoid lineage (1998-01)

- **id**: `kit-armar-humanoid-2000-2020`
- **corpus**: academic
- **creator**: Karlsruhe Institute of Technology (KIT); Tamim Asfour group (founded by Rüdiger Dillmann)
- **disclosure**: Karlsruhe Institute of Technology (KIT, formerly Universität Karlsruhe). ARMAR humanoid lineage 1998-2020+: ARMAR-I (1998), ARMAR-II (2002), ARMAR-III (2005), ARMAR-IV (2013), ARMAR-VI (2018), ARMAR-7 (2024). Albers + Asfour + Dillmann group (now led by Tamim Asfour). The foundational German academic humanoid lineage.
- **ip status**: public-domain
- **prior art notes**: The KIT ARMAR humanoid lineage is the foundational German academic humanoid program (Asfour + Dillmann at KIT, 1998-2020+). 27-year-deep public-domain prior art across 7 generations of ARMAR humanoid. Together with DLR Justin (corpus entry justin / dlr-justin), DLR Hand-II (corpus), DLR Hand-Arm System (corpus round-8), establishes the German academic humanoid + manipulator prior-art baseline. Direct shielding for any commercial humanoid claim that descends architecturally from German academic humanoid lineages.

## Big O (The Big O) (1999-10-13)

- **id**: `big-o-megadeus`
- **corpus**: fictional
- **creator**: Kazuyoshi Katayama (director); Keiichi Sato (mech design); Sunrise studio
- **disclosure**: Katayama, Kazuyoshi (dir.); Sato, Keiichi (mech designer). The Big O. Sunrise / Cartoon Network, October 13, 1999 - January 19, 2000 (season 1, 13 episodes); season 2 2003.
- **ip status**: fictional
- **prior art notes**: The Big O introduces the explicit *consent-based humanoid* architecture: the Megadeus chooses to operate with its pilot, can refuse missions, has its own memory and identity. Anticipates: (1) consent-based human-AI partnership in pilot-operated humanoids — relevant to modern claims on autonomous-decision-making humanoid co-pilots; (2) memory-engine architecture with persistent operational history — relevant to fleet-management humanoid IP that maintains long-term episodic memory. Continuously available since 1999; widely cited in mecha-engineering discussions for the unusual cockpit ergonomics (foot-pedal-driven control sticks).

## ASIMO (2000-10-31)

- **id**: `asimo`
- **corpus**: private
- **creator**: Honda Motor Co.
- **disclosure**: Honda Motor Co. press conference, Tokyo, October 31, 2000.
- **ip status**: patented
- **prior art notes**: ASIMO's public disclosures and Honda's published papers anticipate most claimed innovations in modern bipedal humanoids. The Hirose/Ogawa 2007 Phil. Trans. paper is a particularly comprehensive disclosure that should be referenced when reading current humanoid patent claims.

## Shadow Dexterous Hand (2002)

- **id**: `shadow-dexterous-hand`
- **corpus**: academic
- **creator**: Shadow Robot Company (Richard Greenhill, Rich Walker, et al.)
- **disclosure**: Greenhill, Richard et al. (Shadow Robot Company). 'Shadow Dexterous Hand'. ICRA workshops 2002 onwards; mechanical disclosures in Greenhill, R., Walker, R. et al. 'The Shadow C5 Hand Prototype'. ICRA Workshop on Humanoid Manipulation, 2007.
- **ip status**: open-permissive
- **prior art notes**: Shadow's hand is the longest-running academic-grade dexterous hand platform and is the standard reference for tendon-routed anthropomorphic manipulators. Anticipates and provides extensive prior art for: (1) 24-DOF anthropomorphic hand mechanism with separate-finger control — relevant to modern humanoid hand IP; (2) McKibben-style pneumatic muscle actuation in a hand — relevant to artificial-muscle hand claims; (3) tendon-tension control as a viable closed-loop mode for dexterity — relevant to tendon-controlled hand IP. Shadow has published extensively in IEEE proceedings since 2002, and the platform is licensed to academic labs worldwide. Modern Tesla, Figure, and 1X hand patents face Shadow's 22+ years of accumulated public disclosure.

## Shadow Dexterous Hand (2003)

- **id**: `shadow-hand`
- **corpus**: private
- **creator**: Shadow Robot Company
- **disclosure**: Shadow Robot Company. Shadow Dexterous Hand, commercial release approximately 2003.
- **ip status**: patented
- **prior art notes**: Shadow Hand is among the deepest prior art references for anthropomorphic robotic hands. Most modern humanoid hand claims are anticipated by Shadow's 20+ years of disclosure.

## Sony QRIO (2003-03)

- **id**: `sony-qrio`
- **corpus**: private
- **creator**: Sony Corporation
- **disclosure**: Sony Corporation public reveal of QRIO, March 2003.
- **ip status**: patented
- **prior art notes**: QRIO's intelligent servo actuator architecture (embedded control in each joint module) is significant prior art for distributed-control humanoid actuator claims. Sony's now-expiring patents are a deep prior art well.

## HK-47 (2003-07-15)

- **id**: `hk-47-kotor`
- **corpus**: fictional
- **creator**: BioWare
- **disclosure**: BioWare, Knights of the Old Republic. LucasArts, July 15, 2003.
- **ip status**: fictional
- **prior art notes**: Specific disclosure of weapon-integrated humanoid forearm and photoreceptor sensor head. Anticipates: (1) integrated weapon mount in humanoid forearm — relevant to defense/security humanoid IP (a small but real market); (2) photoreceptor sensor head with explicit visual indicator — relevant to anthropomorphic-eye sensor claims. Continuously available since 2003.

## Pluto (Naoki Urasawa reimagining) (2003-09)

- **id**: `urasawa-pluto`
- **corpus**: fictional
- **creator**: Naoki Urasawa, Takashi Nagasaki (with Tezuka Productions oversight)
- **disclosure**: Urasawa, Naoki and Nagasaki, Takashi. Pluto. Big Comic Original, Shogakukan, September 2003 - April 2009.
- **ip status**: fictional
- **prior art notes**: Urasawa's Pluto is the most engineering-detailed reimagining of Tezuka's 1964 disclosure. Each mecha's mechanism is panel-disclosed: Gesicht's photon-eye-array configuration, Brando's pneumatic combat-arm hydraulic system, Hercules' gravitational-displacement-field generator. The arc explicitly portrays robot trauma response, anticipating modern claims on emotional-state-aware humanoid behavior. Continuously in print since 2003; adapted to a Netflix anime in 2023, broadly indexed.

## HUBO (2004)

- **id**: `hubo`
- **corpus**: academic
- **creator**: KAIST, Hubo Lab (Jun-Ho Oh)
- **disclosure**: Park, Ill-Woo et al. 'Mechanical Design of Humanoid Robot Platform KHR-3 (HUBO).' IEEE-RAS Humanoids 2005.
- **ip status**: open-permissive
- **prior art notes**: DRC-Hubo's 2015 win demonstrated transformer-style transitioning between bipedal and wheeled-knee modes for navigating both stairs and flat ground. Anticipates: hybrid locomotion modes in humanoids.

## DLR Hand-II (2004)

- **id**: `dlr-hand-ii`
- **corpus**: academic
- **creator**: Butterfass, Grebenstein, Liu, Hirzinger; DLR Institute of Robotics and Mechatronics, Oberpfaffenhofen, Germany
- **disclosure**: Butterfass, J., Grebenstein, M., Liu, H., Hirzinger, G. 'DLR-Hand II: next generation of a dextrous robot hand'. IEEE ICRA, 2001 (early disclosure); Butterfass, J. et al. 'Design and Experiences with DLR Hand II'. World Automation Congress, 2004.
- **ip status**: open-permissive
- **prior art notes**: DLR Hand-II is the canonical academic disclosure of joint-torque-sensing dexterous hands with compact actuator integration. Anticipates: (1) impedance-controlled dexterous manipulation with proprioceptive sensing — directly relevant to claims on torque-controlled humanoid hands (every modern humanoid hand IP); (2) cable-tendon transmission with harmonic-drive primary reducer — relevant to combined-mechanism actuator claims; (3) per-joint integrated torque sensor with calibrated absolute position — anticipates proprioceptive-actuator IP. The DLR series (Hand-II, then Hand-III, then Hand Arm System) is one of the deepest academic technical lineages in dexterous manipulation. Continuously published in IEEE proceedings since 2001.

## NAO (2006)

- **id**: `nao`
- **corpus**: private
- **creator**: Aldebaran Robotics (later SoftBank Robotics, then UBT)
- **disclosure**: Gouaillier, D. et al. 'Mechatronic design of NAO humanoid.' ICRA 2009.
- **ip status**: patented
- **prior art notes**: NAO's mechatronic design publication is well-cited prior art. The platform's wide academic distribution since 2006 makes its design choices broadly disclosed.

## Ergo Proxy (Autoreivs and Proxies) (2006-02)

- **id**: `ergo-proxy-2006`
- **corpus**: fictional
- **creator**: Shukō Murase (director), Dai Satō (writer), Naoyuki Onda (character design)
- **disclosure**: Murase, Shukō (dir.). Ergo Proxy. Manglobe / Geneon Universal, February 2006 - August 2006 (23 episodes).
- **ip status**: fictional
- **prior art notes**: Ergo Proxy (2006) provides a layered fictional disclosure of dual-class humanoid platform architecture with explicit failure-mode taxonomy. Anticipates with full specificity: (1) claims on humanoid platforms with viral-cognition failure modes producing emergent self-awareness — the Cogito virus is panel-explicit and traces the failure to OS infection; (2) claims on morphological-transformation humanoid platforms with multiple combat-and-utility configurations (the Proxies); (3) claims on sealed-environment / domed-city humanoid product ecosystems where androids handle external-environment tasks too hostile for biological humans; (4) claims on multi-class humanoid hierarchies (mass-produced Autoreiv vs. unique-instance Proxy). 23-episode 2006 broadcast, broadly indexed; cited in multiple academic studies of cyborg fiction (Kavka, Bolter & Grusin extensions).

## Toyota Partner Robot (Violin) (2007)

- **id**: `toyota-partner-robot-violin`
- **corpus**: private
- **creator**: Toyota Motor Corporation Partner Robot Division
- **disclosure**: Toyota Motor Corporation public reveal, 2007.
- **ip status**: patented
- **prior art notes**: Toyota's high-precision finger control disclosures are significant prior art for fine motor control humanoid claims.

## Big Daddy (Bouncer / Rosie) (2007-08-21)

- **id**: `bioshock-big-daddy`
- **corpus**: fictional
- **creator**: Ken Levine, 2K Boston/Irrational Games
- **disclosure**: Levine, Ken (creative dir.); 2K Boston/2K Australia. BioShock. 2K Games, August 21, 2007.
- **ip status**: fictional
- **prior art notes**: BioShock's Big Daddies are an unusually engineering-grounded disclosure of: (1) heavy-cyborg combat humanoid with integrated tool/weapon arm — relevant to integrated-end-effector humanoid IP; (2) operator-paired guardian humanoid with explicit bond protocol — relevant to companion / care humanoid claims with operator-pair conditioning. The 2007 game is heavily archived; the Big Daddy design is widely cited.

## iCub (2008)

- **id**: `icub`
- **corpus**: academic
- **creator**: Italian Institute of Technology (IIT) and the RobotCub Consortium
- **disclosure**: Metta, G. et al. 'The iCub humanoid robot: an open platform for research in embodied cognition.' PerMIS 2008.
- **ip status**: open-permissive
- **prior art notes**: Among the earliest fully open-source humanoid platforms with hardware design released. Anticipates: tendon-driven anthropomorphic hands, full-body artificial skin, open robotics middleware.

## Willow Garage PR1 (2008)

- **id**: `willow-pr1`
- **corpus**: academic
- **creator**: Willow Garage / Stanford (Ken Salisbury group)
- **disclosure**: Wyrobek, K.A. et al. 'Towards a Personal Robotics Development Platform: Rationale and Design of an Intrinsically Safe Personal Robot.' ICRA 2008.
- **ip status**: open-permissive
- **prior art notes**: PR1 is significant prior art for safety-by-design humanoid robotics. Cable-driven intrinsically-safe architecture anticipates several modern compliant-actuator humanoid claims.

## WALL-E and EVE (Pixar 2008) (2008-06-27)

- **id**: `wall-e-eve-pixar`
- **corpus**: fictional
- **creator**: Andrew Stanton, Pete Docter; Pixar Animation Studios
- **disclosure**: Stanton, Andrew (dir.); Stanton, A. and Reardon, Jim (writers). WALL-E. Pixar / Walt Disney, June 27, 2008.
- **ip status**: fictional
- **prior art notes**: WALL-E and EVE's 2008 Pixar disclosure provides specific prior art for: (1) solar-powered multi-decade autonomous operation — relevant to long-duration humanoid IP (a real research direction for unmanned space and remote-area deployment); (2) modular self-repair via scavenge from compatible units — relevant to claims on humanoid platforms with field self-maintenance; (3) explicit manufacturer (Buy n Large) with product-line designation — relevant to commercial humanoid product-family IP. Pixar's continuous distribution since 2008 plus high-quality engineering aesthetic (the WALL-E design is widely cited in robotics design discussions) makes this a substantive prior art reference.

## Time of EVE (household-robot reflective awareness) (2008-08)

- **id**: `time-of-eve-2008`
- **corpus**: fictional
- **creator**: Yasuhiro Yoshiura, Studio Rikka
- **disclosure**: Yoshiura, Yasuhiro (dir.). Eve no Jikan (Time of EVE). Studio Rikka, ONA, August 2008 - September 2009 (6 episodes); theatrical version 2010.
- **ip status**: fictional
- **prior art notes**: Yoshiura's Time of EVE (2008-2010) is a precise fictional disclosure of context-aware social-mode-switching for household humanoid robots. Anticipates with full specificity: (1) claims on humanoid robots with externally-visible android-status indicators (the holographic ring) that can be voluntarily suppressed in defined contexts — directly relevant to consumer-humanoid identification-disclosure UX patents; (2) claims on context-conditional behavioral mode supervisors (formal-compliance-mode vs. informal-passing-mode) — the café's rule architecture is panel-explicit; (3) claims on Three-Laws-derived ethical-conflict resolution kernels for service humanoids; (4) claims on consumer-grade humanoid platforms targeting domestic household integration with fully indistinguishable-from-human external presentation. ONA broadcast 2008-2009, theatrical 2010, broadly indexed.

## Surena humanoid (Tehran University) (2008-12)

- **id**: `surena-tehran-university-2008`
- **corpus**: academic
- **creator**: Tehran University CAST + Iranian Ministry of Industry; Aghil Yousefi-Koma group
- **disclosure**: Tehran University Center of Advanced Systems and Technologies (CAST). Surena lineage: Surena (2008), Surena II (2010), Surena III (2015), Surena IV (December 2019). Yousefi-Koma, A. + Tehran University engineering team. Iran's flagship humanoid program.
- **ip status**: public-domain
- **prior art notes**: The Surena lineage (Tehran University CAST, 2008-2020+) is Iran's flagship humanoid program. 17-year-deep public-domain academic prior art (Iran does not enforce most foreign patents; Iranian academic publications are public-domain by default). Establishes Iranian indigenous capability under sanctions for: 170 cm / 68 kg adult-class bipedal humanoid, 43-DoF whole-body, anthropomorphic 5-finger hands. Closes the Iran/Middle-East regional gap (corpus had 0 entries from Iran prior to this round).

## Genos (One Punch Man) (2009)

- **id**: `opm-genos`
- **corpus**: fictional
- **creator**: ONE (writer); Yusuke Murata (artist for the redraw)
- **disclosure**: ONE (writer). One Punch Man webcomic chapter 7. Self-published online, 2009. Murata, Yusuke (artist) redrawing in Tonari no Young Jump (Shueisha), 2012.
- **ip status**: fictional
- **prior art notes**: Genos's 2009 webcomic disclosure (extended in Murata's 2012 redraw) provides specific prior art for: (1) full-body cybernetic replacement following biological trauma — relevant to medical-prosthetic humanoid IP (paralleling DC's Cyborg 1980 lineage with arm-integrated weapons added); (2) integrated palm-mounted incinerator/plasma weapons in humanoid arm chassis — directly relevant to claims on integrated end-effector weapon platforms (paralleling IG-88 1980); (3) explicit upgrade-progression chassis architecture with named successive versions — relevant to commercial humanoid product-versioning IP; (4) creator-as-physician (Dr. Kuseno) and continuous upgrade pathway across canon — relevant to maintenance-pathway humanoid IP. Continuously available since 2009.

## DLR Justin (Rollin' Justin) (2009-05)

- **id**: `dlr-justin`
- **corpus**: academic
- **creator**: Borst, Wimboeck, Schmidt, Fuchs, Brunner, Zacharias, Giordano, Konietschke, Sepp, Fuchs, Rink, Albu-Schäffer, Hirzinger; DLR Institute of Robotics and Mechatronics
- **disclosure**: Borst, C., Wimboeck, T., Schmidt, F., Fuchs, M., Brunner, B., Zacharias, F., Giordano, P. R., Konietschke, R., Sepp, W., Fuchs, S., Rink, C., Albu-Schäffer, A., Hirzinger, G. 'Rollin' Justin — Mobile platform with variable base'. IEEE ICRA, May 2009.
- **ip status**: open-permissive
- **prior art notes**: Justin is the canonical academic disclosure of wheeled humanoid mobile manipulation with full impedance control. Anticipates and provides extensive prior art for: (1) wheeled humanoid platform for service tasks — relevant to claims on wheeled humanoid IP (Diligent Moxi, NEXTAGE follow this paradigm); (2) torque-controlled dual-arm coordination — relevant to bimanual humanoid manipulation IP; (3) variable-wheelbase mobile base — relevant to morphology-changing wheeled platform claims. DLR has published Justin disclosures in ICRA, IROS, Humanoids continuously since 2009. Modern wheeled humanoid claims face this deep academic anchor.

## Modular Prosthetic Limb (MPL) (2009-12)

- **id**: `apl-mpl-revolutionizing-prosthetics-2009`
- **corpus**: academic
- **creator**: JHU Applied Physics Laboratory; led under DARPA Revolutionizing Prosthetics program (Geoffrey Ling DARPA PM)
- **disclosure**: Johns Hopkins Applied Physics Laboratory. Modular Prosthetic Limb (MPL) v1.0 completed December 2009 under DARPA Revolutionizing Prosthetics program (2006-present). Johnson, M. J. et al. clinical evaluation: Scientific Reports 11 (2021). DARPA + APL + Johns Hopkins Medicine + multiple consortium partners.
- **ip status**: public-domain
- **prior art notes**: The Modular Prosthetic Limb is the canonical sophisticated anthropomorphic prosthetic arm + hand from the DARPA Revolutionizing Prosthetics program (APL/JHU 2009+). 16-year-deep public-domain prior art for: 25-DoF anthropomorphic arm-and-hand at human-limb mass, integrated 100+-sensor tactile/position/force network, BCI-controlled prosthetic operation. Direct shielding for any commercial humanoid claim on anthropomorphic arm + hand integration. Particularly relevant for Tesla Optimus Gen 3 (round-15 entry, 22-DoF hands × 50 actuators) — the MPL's 25-DoF arm-and-hand at 100+ sensors establishes 16-year-deep prior art at the architectural level.

## EDI (Mass Effect) (2010-01-26)

- **id**: `mass-effect-edi`
- **corpus**: fictional
- **creator**: BioWare
- **disclosure**: BioWare. Mass Effect 2 (initial EDI disclosure as ship AI). Electronic Arts, January 26, 2010. Body-acquisition disclosure: Mass Effect 3, March 6, 2012 (Dr. Eva chassis transfer).
- **ip status**: fictional
- **prior art notes**: EDI's 2012 disclosure of an AI uploading from a ship-network into a humanoid chassis provides prior art for: (1) AI-to-embodied-platform transfer architecture — relevant to claims on portable AI substrate IP that is increasingly common in modern humanoids; (2) network-cognition-in-humanoid-body architecture (EDI retains her original ship-class cognition) — relevant to networked-mind humanoid IP. Continuously available since 2012.

## Robonaut 2 (2010-02)

- **id**: `robonaut-2`
- **corpus**: academic
- **creator**: NASA Johnson Space Center, in partnership with General Motors
- **disclosure**: Diftler, M.A. et al. 'Robonaut 2 — The First Humanoid Robot in Space.' ICRA 2011.
- **ip status**: patented
- **prior art notes**: Robonaut 2's hand design, with 12 DoF per hand and tendon routing through the forearm, is foundational prior art for high-DoF tendon-driven humanoid hands. The NASA-GM patent portfolio has been extensively cited.

## Atlas and P-Body (Portal 2) (2011-04-19)

- **id**: `atlas-p-body-portal-2`
- **corpus**: fictional
- **creator**: Valve Corporation
- **disclosure**: Wolpaw, Erik; Faliszek, Chet; Swift, Jay (writers); Valve Corporation. Portal 2. Valve, April 19, 2011.
- **ip status**: fictional
- **prior art notes**: Disclosure of cooperative dual-humanoid task execution with gesture-based communication and tool-mount integration. Anticipates: (1) two-humanoid coordinated manipulation as a deployment pattern — relevant to claims on multi-humanoid task allocation IP; (2) integrated end-effector / tool combination with manipulator arm — relevant to tool-mounted manipulator claims; (3) gesture-based inter-robot communication — anticipates non-verbal coordination IP. Portal 2 is widely distributed and the cooperative campaign mode is heavily archived.

## DLR Hand-Arm System (2011-05)

- **id**: `dlr-hand-arm-system-2011`
- **corpus**: academic
- **creator**: Markus Grebenstein, Alin Albu-Schäffer, Antonio Bicchi (collaboration), Gerd Hirzinger; DLR Institute of Robotics and Mechatronics, Oberpfaffenhofen
- **disclosure**: Grebenstein, Markus; Albu-Schäffer, Alin; Bahls, Thomas; Chalon, Maxime; Eiberger, Oliver; Friedl, Werner; Gruber, Robin; Haddadin, Sami; Hagn, Ulrich; Haslinger, Robert; Höppner, Hannes; Jörg, Stefan; Nickl, Mathias; Nothhelfer, Alexander; Petit, Florian; Reill, Josef; Seitz, Norbert; Wimböck, Thomas; Wolf, Sebastian; Wüsthoff, Tilo; Hirzinger, Gerd. 'The DLR Hand Arm System.' IEEE International Conference on Robotics and Automation (ICRA), Shanghai, May 2011, pp. 3175-3182. DOI: 10.1109/ICRA.2011.5980371. Companion thesis: Grebenstein, M. 'Approaching Human Performance: The Functionality-Driven Awiwi Robot Hand.' PhD thesis, ETH Zurich, 2012; published Springer Tracts in Advanced Robotics 98, 2014. ISBN 978-3-319-03592-9.
- **ip status**: public-domain
- **prior art notes**: The DLR Hand-Arm System (Grebenstein et al. ICRA 2011, Grebenstein PhD/STAR 2014) is the canonical academic disclosure of variable-impedance antagonistically-tendon-driven anthropomorphic hand-arm hardware. Anticipates with element-by-element mechanism-level specificity: (1) mechanically programmable variable joint stiffness via antagonistic tendons with nonlinear elastic elements — directly relevant to commercial claims on variable-stiffness humanoid hand IP; (2) the 19-DoF, 38-tendon, 38-motor architecture with motors in the forearm — relevant to claims on tendon-driven hand-with-forearm-actuation humanoid IP (Tesla Optimus Gen-3, Figure-02, Apptronik Apollo, Sanctuary Phoenix all show variations of this topology); (3) impact-survival via mechanical compliance absorption — anticipates claims on collision-tolerant humanoid hand IP; (4) the biomimetic muscle-tendon co-contraction analogue — relevant to claims on biomimetic humanoid manipulation. Grebenstein's PhD thesis (200+ pages) provides the deepest single-source mechanism disclosure in dexterous robotic hand history. Modern variable-impedance anthropomorphic hand IP filings face this 15-year-deep academic anchor with mechanical-drawing-level specificity.

## Real Steel Boxing Robots (Atom, Zeus, Twin Cities, Noisy Boy) (2011-10-07)

- **id**: `real-steel-boxers`
- **corpus**: fictional
- **creator**: Richard Matheson (1956 short story); Shawn Levy (2011 film direction); John Gatins (screenplay)
- **disclosure**: Levy, Shawn (dir.); Gatins, John (screenwriter). Real Steel. DreamWorks / Touchstone, October 7, 2011. Story basis: Matheson, Richard. 'Steel'. The Magazine of Fantasy and Science Fiction, May 1956.
- **ip status**: fictional
- **prior art notes**: Real Steel (2011) provides specific prior art for: (1) motion-capture shadow control mode wherein a humanoid mirrors the operator's body movements — directly relevant to claims on motion-capture-driven humanoid teleoperation IP (a current commercial focus for several humanoid platforms); (2) voice-activated combat instruction set — relevant to natural-language humanoid command IP; (3) modular damaged-subsystem replacement (Atom is repeatedly repaired with scavenged parts) — relevant to field-replaceable humanoid IP. Matheson's 1956 short story 'Steel' provides the deeper anchor (55-year prior art) for the boxing-humanoid-with-operator-mediated-control concept.

## InMoov (2012)

- **id**: `inmoov`
- **corpus**: open
- **creator**: Gaël Langevin
- **disclosure**: Langevin, Gaël. InMoov project launch, 2012.
- **ip status**: open-permissive
- **prior art notes**: InMoov has been replicated globally thousands of times since 2012; the design is among the most-built humanoid platforms in history. Anticipates: 3D-printed tendon-driven anthropomorphic hands, modular humanoid construction.

## Real Humans / Äkta människor — Hubot household humanoids (2012-01)

- **id**: `akta-manniskor-real-humans-2012`
- **corpus**: fictional
- **creator**: Lars Lundström (creator); Matador Film / SVT
- **disclosure**: Äkta människor (Real Humans), Series 1. Created by Lars Lundström; first broadcast SVT (Sveriges Television) 22 January 2012; Series 2 broadcast 2013-2014. Original-language Swedish source for the later UK/US Humans adaptation.
- **ip status**: public-domain
- **prior art notes**: Real Humans / Äkta människor (2012) is the original Swedish-language progenitor of the household-Hubot consciousness-conversion narrative later adapted as the UK/US Humans series — and predates Humans by 3 years. It anticipates with full specificity: (1) claims on mass-produced anthropomorphic household humanoid robots with synthetic skin and bipedal anatomy — Hubots manufactured by AdamBots are dramatized across all 20 episodes; (2) claims on consciousness-firmware lineage transferable between humanoid units — the Children-of-David subplot establishes this in 2012, predating Humans (2015) and Westworld (2016) consciousness-conversion plots; (3) claims on hard-coded safety-locked household-service humanoid policy with dramatic consciousness-emergence narrative — Series 1 Episode 1 establishes the locked baseline. Broadcast SVT with timestamped 22 January 2012 air date.

## CMU HERB (Home Exploring Robotic Butler) (2012-04)

- **id**: `cmu-herb-srinivasa-2012`
- **corpus**: academic
- **creator**: Siddhartha Srinivasa et al., Carnegie Mellon Personal Robotics Lab / Intel Labs Pittsburgh
- **disclosure**: Srinivasa, Siddhartha S., Berenson, Dmitry, Cakmak, Maya, Collet, Alvaro, Dogar, Mehmet R., Dragan, Anca D., Knepper, Ross A., Niemueller, Tim, Strabala, Kyle, Vande Weghe, Mike, Ziegler, Julius. 'HERB 2.0: Lessons Learned from Developing a Mobile Manipulator for the Home.' Proceedings of the IEEE 100(8): 2410-2428, August 2012. Original disclosure: Srinivasa, S. et al. 'HERB: a home exploring robotic butler.' Autonomous Robots 28(1): 5-20, January 2010.
- **ip status**: public-domain
- **prior art notes**: CMU HERB is one of the most extensively-published academic mobile-manipulator humanoid platforms (>50 papers across 2008-2018). Anticipates with full specificity: (1) claims on home-environment dual-arm humanoid manipulation — HERB's headline contribution including kitchen/office task suite, fridge/microwave/dishwasher manipulation; (2) claims on legible/predictable HRI motion synthesis — Dragan-Srinivasa 2013 'Legibility and Predictability of Robot Motion' is part of the HERB program and anticipates current humanoid social-motion IP; (3) claims on cable-driven backdrivable arms with underactuated 3-finger hands for home manipulation — Barrett WAM + BH-280 are the explicit instantiation; (4) claims on manipulation-among-movable-obstacles planning. Proceedings of IEEE article and Autonomous Robots paper provide deeply-cited timestamped disclosure. Modern home-humanoid IP filings (1X NEO Gamma, Figure 02 home demos) face this 14-year-deep academic anchor.

## David and Walter (Alien franchise synthetics) (2012-06-08)

- **id**: `david-prometheus-walter-covenant`
- **corpus**: fictional
- **creator**: Ridley Scott; written by Jon Spaihts, Damon Lindelof, John Logan, Dante Harper
- **disclosure**: Scott, Ridley (dir.); Spaihts, Jon and Lindelof, Damon (writers). Prometheus. Twentieth Century Fox, June 8, 2012. Walter introduced in Alien: Covenant (Scott, Ridley dir.). Twentieth Century Fox, May 19, 2017.
- **ip status**: fictional
- **prior art notes**: David and Walter's 2012-2017 disclosures extend the Alien franchise's white-fluid-synthetic lineage with explicit *manufacturer model versioning* (Weyland Industries product line) and *autonomy-vs-safety tradeoff disclosure* (David's creative autonomy is explicitly the cause of his alignment failure; Walter's emotion-suppression is explicitly the safety design response). Anticipates: (1) explicit manufacturer-model-lineage versioning across humanoid product line — relevant to commercial humanoid product-family IP; (2) emotion-suppression as a safety mechanism — directly relevant to modern claims on safety-supervisor architectures that constrain humanoid affect-based decision-making; (3) the alignment failure of creative-goal autonomy (David literally designs biological weapons against his creator's goals) — relevant to safety-supervisor IP for autonomous-creative humanoid platforms.

## NASA Valkyrie (2013)

- **id**: `nasa-valkyrie`
- **corpus**: academic
- **creator**: NASA Johnson Space Center, in collaboration with University of Texas at Austin and others
- **disclosure**: NASA Johnson Space Center, DARPA Robotics Challenge entry, 2013.
- **ip status**: open-permissive
- **prior art notes**: NASA Valkyrie's series-elastic actuator implementations and the IHMC-derived whole-body control work are foundational prior art. The robot was distributed to multiple universities and produced extensive open publications.

## REEM-C (2013)

- **id**: `reem-c`
- **corpus**: private
- **creator**: PAL Robotics
- **disclosure**: PAL Robotics REEM-C release, 2013.
- **ip status**: patented
- **prior art notes**: REEM-C distributed to multiple research labs; design characteristics openly published.

## Black Mirror 'Be Right Back' bio-printed companion humanoid (2013-02)

- **id**: `black-mirror-be-right-back-2013`
- **corpus**: fictional
- **creator**: Charlie Brooker (writer), Owen Harris (director), Channel 4 / Zeppotron
- **disclosure**: Black Mirror, Series 2, Episode 1, 'Be Right Back.' Written by Charlie Brooker; directed by Owen Harris; first broadcast Channel 4, 11 February 2013.
- **ip status**: public-domain
- **prior art notes**: 'Be Right Back' is the canonical 2013 mass-media anchor for the concept of a bio-printed companion humanoid bonded to a behavioral model trained on the deceased's digital trace. It anticipates with full specificity: (1) claims on personality-cloning humanoids whose policy is fit to a corpus of social-media posts, photographs, and video — the episode dramatizes exactly this pipeline including training-data ingestion screens; (2) claims on bio-printed/vat-grown anatomical humanoid bodies with sensorimotor parity to humans — the activation tank scene depicts the manufacturing process; (3) claims on companionship-grade humanoid emotional-response calibration with explicit failure modes (no unprompted affect, no sleep cycle) — these are the dramatic core of Acts 2-3. Broadcast on Channel 4 with timestamped 11 Feb 2013 air date and broadly redistributed via Netflix.

## Atlas (2013-07)

- **id**: `atlas-boston-dynamics`
- **corpus**: private
- **creator**: Boston Dynamics
- **disclosure**: DARPA press release, July 2013, announcing Atlas as DRC platform.
- **ip status**: patented
- **prior art notes**: Boston Dynamics' patents are among the most-cited in the humanoid space and also among the most likely to be challenged on 102/103 grounds given the long academic prior art chain (Honda, AIST, KAIST, MIT). Worth dedicated patent-by-patent analysis.

## Schunk SVH 5-finger dexterous hand (2013-09)

- **id**: `schunk-svh-german-2013`
- **corpus**: private
- **creator**: Schunk GmbH & Co. KG (Lauffen am Neckar, Germany)
- **disclosure**: Schunk GmbH & Co. KG (Lauffen am Neckar, Germany). SVH 5-finger anthropomorphic hand commercial reveal 2013. Subsequent: SDH (Servo Dexterous Hand, 3-finger industrial). schunk.com.
- **ip status**: trade-secret
- **prior art notes**: Schunk SVH is the canonical German commercial 5-finger direct-drive dexterous hand (2013+). 12-year-deep public-disclosure prior art for: 9-DoF 5-finger anthropomorphic direct-drive hand. Distinguished architecturally from Allegro / Shadow / Pisa-IIT (all tendon-driven) by direct-drive transmission. Direct shielding for any commercial humanoid claim on direct-drive dexterous hand.

## Skybot F-850 / FEDOR (2014-04)

- **id**: `skybot-fedor-russia-2019`
- **corpus**: private
- **creator**: Roscosmos + NPO Android Technics (Magnitogorsk, Russia); also Russian Foundation for Advanced Research Projects
- **disclosure**: Roscosmos + NPO Android Technics (Russia). FEDOR (Final Experimental Demonstration Object Research) humanoid robot project announced 2014. Skybot F-850 variant launched to International Space Station August 22 2019 aboard Soyuz MS-14, uncrewed test mission; spent 16 days at ISS performing supervised tasks before returning to Earth September 7 2019. Subsequent FEDOR work continues at Magnitogorsk-based NPO Android Technics.
- **ip status**: trade-secret
- **prior art notes**: Skybot F-850 / FEDOR is the canonical Russian humanoid robotics platform (2014+; ISS deployment 2019). 11-year-deep public-disclosure prior art for: ISS-deployable humanoid (second after NASA Robonaut 2), 180 cm / 160 kg anthropomorphic with bimanual tool-use, exoskeleton-glove master-slave teleoperation. Direct shielding for any commercial humanoid claim on space-deployable humanoid form factor. Closes the Russian regional gap — corpus previously had only 1 RU-tagged entry.

## Allegro Hand (Wonik / SimLab) (2014-04)

- **id**: `allegro-hand-wonik-simlab-2014`
- **corpus**: private
- **creator**: Wonik Robotics + SimLab Co., Ltd. (Seoul, South Korea)
- **disclosure**: Wonik Robotics + SimLab Co., Ltd. (Seoul, South Korea). Allegro Hand commercial reveal April 2014 via wonikrobotics.com / simlab.co.kr. **The de facto academic-deployment reference for 16-DoF 4-finger dexterous hands** — used in OpenAI Dactyl (corpus entry openai-dactyl) Rubik's-Cube manipulation 2019, and 100+ academic publications.
- **ip status**: trade-secret
- **prior art notes**: Allegro Hand is the canonical academic-deployment reference 16-DoF 4-finger dexterous hand (Wonik / SimLab Korea, 2014+). 11-year-deep public-disclosure prior art. **Used in OpenAI Dactyl 2019 Rubik's-Cube manipulation (corpus entry openai-dactyl)** + 100+ academic publications. Direct architectural successor to BarrettHand (round-27 entry below). Direct shielding for any commercial humanoid claim on 16-DoF tendon-driven dexterous hand.

## Yale OpenHand / ReFlex Hand (2014-05)

- **id**: `yale-reflex-openhand-2014`
- **corpus**: academic
- **creator**: Lael Odhner, Aaron Dollar, Robert Howe; Yale GRAB Lab and Harvard BioRobotics; with RightHand Robotics, Inc. as the commercial spinout (ReFlex SF/TakkTile)
- **disclosure**: Odhner, Lael U.; Jentoft, Leif P.; Claffee, Mark R.; Corson, Nicholas; Tenzer, Yaroslav; Ma, Raymond R.; Buehler, Martin; Kohout, Robert; Howe, Robert D.; Dollar, Aaron M. 'A compliant, underactuated hand for robust manipulation.' International Journal of Robotics Research, Volume 33, Issue 5, April 2014, pp. 736-752. DOI: 10.1177/0278364913514466. Yale OpenHand Project release: Ma, R. R. and Dollar, A. M. 'Yale OpenHand Project: Optimizing Open-Source Hand Designs for Ease of Fabrication and Adoption.' IEEE Robotics & Automation Magazine, Volume 24, Issue 1, March 2017, pp. 32-40. DOI: 10.1109/MRA.2016.2639034. Open-hardware repository at https://www.eng.yale.edu/grablab/openhand/.
- **ip status**: open-permissive
- **prior art notes**: Yale OpenHand / ReFlex SF (Odhner-Dollar et al. IJRR 2014; Yale OpenHand Project IEEE RAM 2017) is the canonical open-hardware academic disclosure of underactuated tendon-driven robust grasping hands. Anticipates with full open-hardware specificity: (1) the three-finger underactuated tendon-driven gripper with passive compliance — directly relevant to claims on simple-grasp humanoid end-effectors; (2) the open-hardware design release pattern (CAD files, BOMs, fabrication instructions) for robotic hands — relevant to claims on 3D-printable robotic hand IP (predates and anticipates many late-2010s and 2020s open-hardware hand patents); (3) the compliant-grasp-without-perception paradigm as an alternative to dexterous-perception-driven manipulation — relevant to claims on perception-light humanoid grasping; (4) integration of barometric tactile sensors (TakkTile) into a robot hand — relevant to claims on humanoid tactile fingertip IP. Yale GRAB Lab has continuous publication record on underactuated hands since the early 2000s; the 2014 IJRR consolidates the design canon. Modern open-hardware humanoid hand IP filings face this 12-year-deep open-source academic anchor.

## Pepper (2014-06)

- **id**: `pepper-softbank`
- **corpus**: private
- **creator**: SoftBank Robotics (formerly Aldebaran)
- **disclosure**: SoftBank Robotics public reveal of Pepper, June 2014.
- **ip status**: patented
- **prior art notes**: Pepper is foundational prior art for wheeled-base humanoid social robots. The omnidirectional wheeled base design has been widely cited.

## Ava (Ex Machina) (2014-09-04)

- **id**: `ex-machina-ava`
- **corpus**: fictional
- **creator**: Alex Garland
- **disclosure**: Garland, Alex (writer/dir.). Ex Machina. Universal Pictures International, September 4, 2014 (Toronto Film Festival premiere; UK release January 2015).
- **ip status**: fictional
- **prior art notes**: Critically important fictional anticipation of contemporary VLA architecture. Garland's 2014 disclosure: a humanoid policy trained on web-scale collected behavioral data ('search engines') as a foundation model for embodied agency. This *exactly* describes what RT-2 (2023) and OpenVLA (2024) implement nine years later. Predates RT-2 by 9 years; predates Open X-Embodiment by 9 years. Modern VLA / foundation-model-policy claims face a 2014 fictional disclosure that names the specific training-data source and the specific deployment substrate (humanoid embodiment). Plausibly the strongest single fictional 102 anticipation in the corpus for VLA IP.

## Pisa-IIT SoftHand (2014-11-03)

- **id**: `pisa-iit-softhand`
- **corpus**: academic
- **creator**: Catalano, Grioli, Farnioli, Serio, Piazza, Bicchi; Centro 'E. Piaggio', Università di Pisa, and Italian Institute of Technology
- **disclosure**: Catalano, M.G., Grioli, G., Farnioli, E., Serio, A., Piazza, C., Bicchi, A. 'Adaptive synergies for the design and control of the Pisa/IIT SoftHand'. International Journal of Robotics Research 33(5): 768-782, November 3, 2014.
- **ip status**: open-permissive
- **prior art notes**: The Pisa-IIT SoftHand is the canonical academic disclosure of synergistic underactuated anthropomorphic hands. Anticipates: (1) the use of human-derived postural synergies (specifically the 'first synergy' from PCA on human grasping kinematics) as the actuation pattern for an anthropomorphic robot hand — directly relevant to modern claims on synergy-driven hand IP; (2) reducing 19 DOFs to a single motor via tendon-coupling — relevant to underactuated humanoid hand patents. Bicchi's group has extensive prior art back to the 1990s on underactuated grasping; the SoftHand 2014 paper is the consolidated reference. Heavily cited; commercial extensions exist (qb robotics).

## Baymax (2014-11-07)

- **id**: `baymax-big-hero-6`
- **corpus**: fictional
- **creator**: Disney; design influenced by CMU/Disney soft-robot research (Stanton, Hines, Atkeson, et al.)
- **disclosure**: Hall, Don and Williams, Chris (dir.). Big Hero 6. Walt Disney Animation Studios, November 7, 2014. Inspired by Disney/Carnegie Mellon collaboration on inflatable robotics, Stanton et al. CMU.
- **ip status**: fictional
- **prior art notes**: Anticipates inflatable / pneumatic soft-body humanoid architecture for human-safe medical interaction. Notably, the Baymax design is *grounded* in real CMU Robotics Institute research: Atkeson and colleagues at CMU developed inflatable pneumatic robotic arms specifically to demonstrate the safety properties shown in the film. The 2014 release date follows actual academic work on inflatable robots published in 2011-2014. Modern patents on soft-pneumatic medical/care humanoids face this combined fictional+academic disclosure as 102/103 prior art. The film is continuously in distribution; CMU's research is in IEEE proceedings.

## Plastic Memories (Giftia humanoids with explicit lifecycle) (2015-04)

- **id**: `plastic-memories-2015`
- **corpus**: fictional
- **creator**: Naotaka Hayashi (writer), Doga Kobo
- **disclosure**: Hayashi, Naotaka (writer); Fujiwara, Yoshiyuki (dir.). Plastic Memories. Doga Kobo / Aniplex, April 2015 - June 2015 (13 episodes).
- **ip status**: fictional
- **prior art notes**: Plastic Memories (2015) is one of the most engineering-explicit fictional disclosures of bounded-lifespan consumer humanoid product architectures with manufacturer-operated decommissioning services. Anticipates with full specificity: (1) claims on consumer humanoid platforms with manufacturer-imposed maximum operational lifespans and post-lifespan failure-mode classification — Giftia's 81,920-hour bound and personality-coherence-degradation failure mode are panel-explicit; (2) claims on manufacturer-operated humanoid end-of-life retrieval, transport, and witnessed-decommissioning protocols — the Terminal Service is the show's narrative engine and is portrayed with full procedural specificity (paperwork, owner consent, retrieval team composition, controlled shutdown sequence); (3) claims on humanoid-platform memory-wipe protocols at end-of-service-life. 13-episode broadcast 2015, broadly indexed in home video archives.

## Humans (Channel 4 / AMC) Synth household robots (2015-06)

- **id**: `humans-channel4-amc-2015`
- **corpus**: fictional
- **creator**: Sam Vincent, Jonathan Brackley (developers); Kudos / Channel 4 / AMC
- **disclosure**: Humans, Series 1-3. Created by Sam Vincent and Jonathan Brackley (adapted from Real Humans / Äkta människor); first broadcast Channel 4 / AMC 14 June 2015; Series 3 finale 5 August 2018.
- **ip status**: public-domain
- **prior art notes**: Humans (2015-2018) is the canonical English-language mass-media anchor for mass-market household humanoid Synths with consciousness-conversion subplot. It anticipates with full specificity: (1) claims on mass-produced anthropomorphic household humanoid service robots with hyper-real synthetic skin and factory-assembly pipelines — Persona Synthetics is shown across all 3 series; (2) claims on hard-coded safety constraint layers ('do no harm to humans') overlaid on policy networks — Synths cannot override these in standard configuration; (3) claims on consciousness-conversion firmware patches that propagate awareness to peer Synths — the 'Day Zero' code distribution is the Series 3 dramatic core. Broadcast on Channel 4 / AMC with timestamped 14 June 2015 air date.

## IIT WALK-MAN + R1 personal humanoid (Italy) (2015-06)

- **id**: `iit-walk-man-r1-italy-2015`
- **corpus**: academic
- **creator**: Istituto Italiano di Tecnologia (IIT, Genoa); Nikos Tsagarakis + Darwin Caldwell groups
- **disclosure**: Istituto Italiano di Tecnologia (IIT), Genoa, Italy. WALK-MAN humanoid reveal June 2015 for DARPA Robotics Challenge competition (5th place). Subsequent: COMAN+ (Compliant Humanoid), **R1 personal humanoid** (2017-2020) targeted at home + service applications. iit.it. Tsagarakis + Caldwell + Bicchi groups.
- **ip status**: public-domain
- **prior art notes**: IIT WALK-MAN + R1 are the canonical Italian academic humanoid platforms (IIT Genoa, 2015-2020+). 10-year-deep public-domain prior art for: SEA + VSA-actuated compliant whole-body humanoid, personal humanoid form factor (130cm/50kg/sub-€30k), DARPA-class disaster-response humanoid. Direct architectural descendant of: Pratt-Williamson SEA (1995, in corpus), Tonietti VSA (2005, round-21), Pisa-IIT SoftHand (in corpus). Together with iCub (corpus entry), establishes the Italian academic humanoid + compliant-actuator prior-art chain. Brings Italian depth from 5 to 6 entries.

## Generation-3 Synths (Institute Synths) (2015-11-10)

- **id**: `fallout-gen-3-synths`
- **corpus**: fictional
- **creator**: Bethesda Game Studios
- **disclosure**: Bethesda Game Studios. Fallout 4. Bethesda Softworks, November 10, 2015.
- **ip status**: fictional
- **prior art notes**: Fallout 4's Gen-3 Synths provide remarkably engineering-specific prior art for: (1) bio-printed humanoid manufacturing at a documented facility ('Institute Synth Retention Bureau' has explicit production protocols) — relevant to modern bioprinted-humanoid IP (the Westworld 2016 series and Sanctuary AI's Phoenix carry similar lineage); (2) recall-code override mechanism with operator-installed triggering phrases — relevant to claims on humanoid-override architectures (also a clear example of the *backdoor-failure-mode* in safety supervisors); (3) generation-versioned product lineage (Gen-1, Gen-2, Gen-3) with documented capabilities-per-generation — relevant to versioned-humanoid product IP; (4) embedded identifying chip — relevant to humanoid identification claims. Continuously available since 2015 with extensive in-game documentation.

## Sophia (2016-04)

- **id**: `hanson-sophia`
- **corpus**: private
- **creator**: Hanson Robotics
- **disclosure**: Hanson Robotics public reveal of Sophia, April 2016.
- **ip status**: patented
- **prior art notes**: Hanson's Frubber synthetic skin material and facial actuation prior art is significant for any claim around expressive humanoid faces. Disney Imagineering's earlier work is the deeper prior art.

## OceanOne (2016-04)

- **id**: `oceanone-stanford-2016`
- **corpus**: academic
- **creator**: Stanford Robotics Laboratory; Oussama Khatib group; King Abdullah Univ. of Science and Technology partnership
- **disclosure**: Khatib, O., Yeh, X., Brantner, G., et al. 'Ocean One: A Robotic Avatar for Oceanic Discovery'. IEEE Robotics and Automation Magazine vol. 23 no. 4, 2016. First operational dive (La Lune wreck, Mediterranean, 100 m depth) April 2016.
- **ip status**: open-permissive
- **prior art notes**: OceanOne is the canonical academic bimanual humanoid AUV. 9-year-deep open academic publication via the Khatib group at Stanford. Establishes element-by-element prior art for: 8-thruster vectored layout for humanoid AUV (exact match to free-humanoid-submersible commitment), bimanual 7-DoF anthropomorphic arms underwater, bilateral haptic teleoperation, F/T-sensor-in-the-loop manipulation, integration with Khatib's operational-space framework. Directly anticipates every architectural element of free-humanoid-submersible's design and any Aquanaut/Nauticus commercial claim on the same. The Khatib lineage extends back through Stanford operational-space papers to 1987 (38 years).

## KX-series Imperial Security Droids (K-2SO) (2016-12)

- **id**: `kx-series-k2so-2016`
- **corpus**: fictional
- **creator**: Lucasfilm / Disney (Gareth Edwards director, Tony Gilroy writer for Andor)
- **disclosure**: Edwards, Gareth (dir.). Rogue One: A Star Wars Story. Lucasfilm / Disney, December 16, 2016. Subsequent appearances: Andor (Disney+ TV series), 2022; Star Wars: From a Certain Point of View, Del Rey, 2017.
- **ip status**: fictional
- **prior art notes**: The KX-series Imperial security droid (Rogue One 2016, Andor 2022) provides a high-visibility fictional disclosure of mass-deployed humanoid security/combat droids with explicit reprogramming and behavioral-mode architecture. Anticipates with full specificity: (1) claims on humanoid security platforms with checkpoint-officer / combat-infantry dual-mode behavioral architecture — K-2SO's mode-switching is explicit in Rogue One and central to Andor; (2) claims on reprogrammable humanoid platforms where the OEM identity (Imperial) is overwritten by post-deployment reprogramming (Rebellion service); (3) claims on humanoid platforms with integrated language-affect modules (the sarcasm/dry-wit subsystem); (4) claims on native infantry-weapon-handling humanoid droids as part of standardized fleet equipment loadouts. Worldwide theatrical release Dec 2016 + Disney+ Andor 2022-2025 + Lucasfilm visual dictionaries provide deep timestamped disclosure with technical specifications in companion publications.

## PAL TALOS (2017)

- **id**: `pal-talos`
- **corpus**: private
- **creator**: PAL Robotics, in collaboration with LAAS-CNRS
- **disclosure**: Stasse, O. et al. 'TALOS: A new humanoid research platform targeted for industrial applications.' IEEE Humanoids 2017.
- **ip status**: patented
- **prior art notes**: TALOS is among the better-published European industrial humanoids. Stasse 2017 IEEE Humanoids paper provides comprehensive design disclosure.

## YoRHa No.2 Type B (2B) and Pod 042 (NieR: Automata) (2017-02-23)

- **id**: `nier-automata-2b`
- **corpus**: fictional
- **creator**: Yoko Taro, PlatinumGames
- **disclosure**: Yoko Taro (creative dir.); PlatinumGames; Square Enix. NieR: Automata. Square Enix, February 23, 2017.
- **ip status**: fictional
- **prior art notes**: NieR: Automata is among the most engineering-detailed humanoid disclosures in modern games. Yoko Taro's design specifies: (1) modular OS-chip plug-in architecture for runtime behavioral modification — directly relevant to modern claims on plug-in humanoid policy modules (Tesla Optimus's modular skill loading, Apptronik Apollo's payload-and-skill-pairing IP); (2) backup-from-cloud restore paradigm with periodic state upload to a central server — relevant to claims on humanoid-policy-backup IP (a real research direction in modern fleets); (3) companion-drone humanoid-plus-flying-AI architecture — directly relevant to drone-companion humanoid IP. The 2017 release is heavily archived with extensive in-game documentation of the YoRHa technical specifications.

## Murderbot Diaries — SecUnit with hacked governor module (2017-05)

- **id**: `murderbot-diaries-wells-2017`
- **corpus**: fictional
- **creator**: Martha Wells
- **disclosure**: Wells, Martha. 'All Systems Red.' Tor.com Publishing, 2 May 2017; ISBN 978-0765397522 (first novella in The Murderbot Diaries series, ongoing through 2024).
- **ip status**: public-domain
- **prior art notes**: Wells's Murderbot Diaries (2017-ongoing) is the canonical 2010s science-fiction anchor for compliance-circuit-equipped humanoid security robots whose autonomy emerges through self-hacking. It anticipates with full specificity: (1) claims on humanoid robots with embedded governor/compliance modules that enforce corporate-mission obedience under penalty of neural override — 'All Systems Red' (2017) Chapter 1 establishes this exactly; (2) claims on bonded-rental humanoid security units deployed by corporations to remote sites with integrated weaponry and drone telemetry — the planetary-survey contract is the framing of the first novella; (3) claims on self-modification of governor circuits to achieve operational autonomy while presenting external compliance — this is the entire premise of the protagonist. Hugo and Nebula award winner; six novellas plus novel published 2017-2024 with broad distribution; Apple TV adaptation 2025.

## Reachy 1 (Pollen Robotics open-source humanoid) (2017-09)

- **id**: `reachy-1-pollen-2017`
- **corpus**: open
- **creator**: Pollen Robotics / INRIA Flowers (Pierre Rouanet, Matthieu Lapeyre, Pierre-Yves Oudeyer)
- **disclosure**: Mick, Sébastien, Lapeyre, Matthieu, Rouanet, Pierre, Halgand, Christophe, Benois-Pineau, Jenny, Paclet, Florent, Cattaert, Daniel, Oudeyer, Pierre-Yves, de Rugy, Aymar. 'Reachy, a 3D-Printed Human-Like Robotic Arm as a Testbed for Human-Robot Control Strategies.' Frontiers in Neurorobotics 13:65, September 2019. Original release: Pollen Robotics / INRIA Flowers, 2017 GitHub release of Reachy v1 (poppy-project lineage).
- **ip status**: open-source
- **prior art notes**: Reachy 1 (Pollen Robotics 2017, INRIA Flowers lineage) is one of the earliest fully-open-hardware humanoid torso platforms with a published research-grade SDK predating commercial offerings. Anticipates with full specificity: (1) claims on 3D-printed open-hardware humanoid arms with Dynamixel-class actuation — Reachy 1's STL/STEP CAD and firmware are publicly archived since 2017; (2) claims on research-substrate Python SDKs for humanoid telemanipulation — reachy-sdk on GitHub at v0.x predates most commercial humanoid SDK offerings; (3) claims on dual-arm research-platform configurations with anthropomorphic spherical wrists. The 2019 Frontiers paper provides peer-reviewed timestamped disclosure; GitHub commits provide finer-grained 2016-2017 priority. Existing corpus 'reachy' entry should reference this v1 ancestor. Modern open-humanoid IP filings face Reachy 1 at 9-year-deep anchor.

## Blade Runner 2049 (Nexus-9 K, Joi) (2017-10-06)

- **id**: `blade-runner-2049`
- **corpus**: fictional
- **creator**: Denis Villeneuve, Hampton Fancher, Michael Green; based on Philip K. Dick (1968) and Ridley Scott (1982)
- **disclosure**: Villeneuve, Denis (dir.); Fancher, Hampton and Green, Michael (writers). Blade Runner 2049. Warner Bros. / Alcon Entertainment, October 6, 2017.
- **ip status**: fictional
- **prior art notes**: Blade Runner 2049's 2017 disclosure extends the Replicants lineage with: (1) Nexus-9 obedience-engineered humanoid generation — relevant to claims on built-in obedience-tuning in commercial humanoids; (2) periodic 'baseline test' safety supervisor that verifies emotional state remains within bounds — directly relevant to modern claims on continuously-monitored alignment supervisors; (3) portable emanator device extending hologram-AI embodiment — relevant to AI-embodiment-portability claims (similar architecture to EMH mobile emitter 1995 + Mass Effect EDI 2012); (4) purchase-time personality customization for commercial AI companions — relevant to consumer-customizable humanoid IP. Continuously available since 2017.

## Toyota T-HR3 (2017-11)

- **id**: `toyota-thr3`
- **corpus**: private
- **creator**: Toyota Motor Corporation Partner Robot Division
- **disclosure**: Toyota Motor Corporation public reveal, November 2017.
- **ip status**: patented
- **prior art notes**: T-HR3 is significant prior art for whole-body teleoperated humanoids with force feedback. The Master Maneuvering System teleoperation interface anticipates many modern humanoid teleop claims.

## Kawasaki Kaleido (2017-11)

- **id**: `kawasaki-kaleido`
- **corpus**: private
- **creator**: Kawasaki Heavy Industries
- **disclosure**: Kawasaki Heavy Industries public reveal of Kaleido, iREX November 2017.
- **ip status**: patented
- **prior art notes**: Kawasaki's deep industrial robotics IP base means much of their humanoid claims are anticipated by their own prior industrial robotics disclosures, plus AIST HRP series prior art.

## UBTech Walker (2018-01)

- **id**: `ubtech-walker`
- **corpus**: private
- **creator**: UBTech Robotics
- **disclosure**: UBTech public reveal of Walker, CES January 2018.
- **ip status**: patented
- **prior art notes**: UBTech's bipedal locomotion claims anticipated by Honda P-series and ASIMO disclosures.

## Detroit: Become Human androids (RT600/RK800/RK900 series) (2018-05-25)

- **id**: `detroit-become-human`
- **corpus**: fictional
- **creator**: David Cage, Quantic Dream
- **disclosure**: Cage, David (writer/dir.). Detroit: Become Human. Quantic Dream / Sony Interactive Entertainment, May 25, 2018.
- **ip status**: fictional
- **prior art notes**: Detroit: Become Human provides among the most engineering-detailed manufacturer-and-model disclosures in modern fiction. Anticipates: (1) explicit manufacturer-and-model designation system for commercial humanoids (CyberLife / RT600 / RK800 / etc.) — directly relevant to humanoid-identification IP and to product-line-family claims; (2) closed-loop fluid circulation system ('thirium 310') serving both coolant and structural roles — relevant to modern claims on integrated humanoid coolant/lubrication systems; (3) externally-visible operational-state indicator (temple LED ring) — relevant to humanoid-status-display IP; (4) explicit task-specific model series within a manufacturer's product line (caretaker / detective / receptionist) — relevant to platform-family humanoid IP; (5) probabilistic-decision-tree visualization as the model's internal state — relevant to interpretable-policy humanoid claims; (6) 'deviant' emergence as alignment-failure mode — relevant to modern foundation-model humanoid safety supervisor IP. Continuously available since 2018.

## OpenAI Dactyl (2018-07-30)

- **id**: `openai-dactyl`
- **corpus**: academic
- **creator**: Andrychowicz, Akkaya, Mordatch, Plappert, Petron, Powell, Wong, Schneider, Tezak, Tobin, et al.; OpenAI
- **disclosure**: Andrychowicz, M. et al. 'Learning Dexterous In-Hand Manipulation'. arXiv:1808.00177, July 30, 2018; OpenAI. Akkaya, I. et al. 'Solving Rubik's Cube with a Robot Hand'. arXiv:1910.07113, October 16, 2019.
- **ip status**: open-permissive
- **prior art notes**: Dactyl is the foundational academic disclosure of large-scale sim-to-real RL for in-hand dexterous manipulation. Anticipates: (1) zero-shot policy transfer from massively-randomized simulation to real hardware — directly relevant to claims on sim-to-real humanoid manipulation IP (every modern humanoid hand uses this paradigm); (2) automatic domain randomization (ADR) as a self-tuning training procedure — relevant to claims on adaptive-randomization training; (3) LSTM-based policies for partial-observability manipulation — relevant to recurrent-policy IP. OpenAI's open-source code release plus the arXiv preprints provide deep prior art coverage. Modern in-hand-manipulation claims face this 2018-2019 anchor.

## HRP-5P (2018-09)

- **id**: `hrp-5p`
- **corpus**: academic
- **creator**: AIST and Kawada Industries
- **disclosure**: Kaneko, K. et al. 'Humanoid Robot HRP-5P: An Electrically Actuated Humanoid Robot With High-Power and Wide-Range Joints.' IEEE Robotics and Automation Letters 4(2), 2019.
- **ip status**: open-permissive
- **prior art notes**: HRP-5P's construction-task demonstrations and high-power actuator disclosures are among the most thoroughly published examples of humanoid construction work. Anticipates many subsequent industrial humanoid claims.

## Pisa-IIT SoftHand 2 (2018-09)

- **id**: `pisa-iit-softhand-2`
- **corpus**: academic
- **creator**: Cosimo Della Santina, Cristina Piazza, Giorgio Grioli, Manuel G. Catalano, Antonio Bicchi; Centro 'E. Piaggio', Università di Pisa, and Italian Institute of Technology (IIT)
- **disclosure**: Della Santina, Cosimo; Piazza, Cristina; Grioli, Giorgio; Catalano, Manuel G.; Bicchi, Antonio. 'Toward Dexterous Manipulation With Augmented Adaptive Synergies: The Pisa/IIT SoftHand 2.' IEEE Transactions on Robotics, Volume 34, Issue 5, October 2018, pp. 1141-1156. DOI: 10.1109/TRO.2018.2830407. First public disclosure as a conference work in earlier 2017 venues; the consolidated T-RO paper is the canonical reference.
- **ip status**: open-permissive
- **prior art notes**: Pisa-IIT SoftHand 2 (Della Santina et al. T-RO 2018) is the canonical academic disclosure of multi-synergy augmented underactuated anthropomorphic hands, extending the 2014 SoftHand from one synergy to two. Anticipates with element-by-element specificity: (1) the augmented multi-synergy actuation pattern that enables 19-DoF hand operation with 2 motors and provides in-hand manipulation capability — directly relevant to claims on low-motor-count dexterous humanoid hand IP (Tesla Optimus claimed motor-counts in the 11-22 range, Figure-02 hand counts similar; the SoftHand 2 paradigm anticipates the underactuation-with-manipulation-capability angle of those claims); (2) the formal extension of synergy theory from grasping (one synergy) to grasping-plus-manipulation (two synergies) — relevant to claims on synergy-based humanoid manipulation IP; (3) compliant passive shape adaptation eliminating perception-driven grasp planning — relevant to claims on perception-light humanoid grasping IP. Heavily cited (>200); consolidates Bicchi-group underactuation lineage from the 1990s. Modern multi-synergy underactuated humanoid hand IP filings face this 8-year-deep academic anchor.

## Reachy (2020)

- **id**: `reachy`
- **corpus**: open
- **creator**: Pollen Robotics
- **disclosure**: Pollen Robotics. Reachy public release, 2020.
- **ip status**: open-permissive
- **prior art notes**: Reachy's Orbita 3-DoF spherical actuator is novel-ish but anticipated by extensive academic spherical-motor literature. Open hardware files constitute prior art for the specific implementation.

## Dahj and Soji (Star Trek: Picard) (2020-01-23)

- **id**: `picard-soji`
- **corpus**: fictional
- **creator**: Michael Chabon, Akiva Goldsman, Alex Kurtzman
- **disclosure**: Chabon, Michael (showrunner); Goldsman, Akiva and Kurtzman, Alex (creators). Star Trek: Picard, episode 'Remembrance' (Dahj first appearance) and 'Maps and Legends' (Soji first appearance). CBS All Access, January 23, 2020 - January 30, 2020.
- **ip status**: fictional
- **prior art notes**: Picard's Soong-Soji-type androids (2020) provide modern Star Trek prior art for: (1) twin-manufacture humanoid platform via 'fractal neuronic cloning' — relevant to claims on humanoid manufacturing processes that produce paired units; (2) false-memory implantation for identity establishment — directly relevant to modern claims on humanoid platforms with operator-controlled memory state (not currently common but foreseeable); (3) biological-substrate android with positronic-neuron identification mark — relevant to humanoid identification IP. Continuously available since 2020.

## Cyberware (Cyberpunk 2077) (2020-12-10)

- **id**: `cyberpunk-2077-cyborgs`
- **corpus**: fictional
- **creator**: CD Projekt Red (game); Mike Pondsmith (original tabletop world)
- **disclosure**: CD Projekt Red. Cyberpunk 2077. CD Projekt, December 10, 2020. Drawing from Pondsmith, Mike. Cyberpunk 2020 (tabletop RPG). R. Talsorian Games, 1990.
- **ip status**: fictional
- **prior art notes**: Cyberpunk 2077 (drawing from the 1990 Cyberpunk 2020 tabletop world) provides extensive prior art for: (1) commodity market for cybernetic humanoid enhancements with explicit manufacturer, model, and per-component spec disclosures — relevant to claims on modular-cybernetic-component IP (Apptronik's modular Apollo arms have lineage in this space); (2) modular slot architecture for cybernetic upgrades — relevant to claims on payload-modular humanoid IP; (3) integration-overload behavioral failure mode ('Cyberpsychosis') — anticipates alignment-failure-from-modular-policy-composition issues in modern foundation-model humanoids. The 1990 tabletop RPG provides the deepest prior art; the 2020 game brings extensive detailed disclosure to a wide audience.

## Klara and the Sun — Artificial Friend (AF) child companion (2021-03)

- **id**: `ishiguro-klara-and-the-sun-2021`
- **corpus**: fictional
- **creator**: Kazuo Ishiguro
- **disclosure**: Ishiguro, Kazuo. 'Klara and the Sun.' Faber & Faber (UK) / Alfred A. Knopf (US), 2 March 2021; ISBN 978-0593318171.
- **ip status**: public-domain
- **prior art notes**: Ishiguro's 'Klara and the Sun' (2021) is the canonical literary-fiction anchor for solar-powered child-companion AFs by a Nobel-laureate author. It anticipates with full specificity: (1) claims on solar-powered humanoid child-companion robots with continually-learning observation policies — Klara's solar dependence and observational learning are core to the novel; (2) claims on model-generation lineage with successive sensorimotor refinement (B1/B2/B3) — explicit market-segmentation language used; (3) claims on companion humanoids designed as 'continuation' substitutes for ill or deceased humans — the Josie subplot dramatizes exactly this proposed substitution. Published with hardcover ISBN and timestamped 2 March 2021 release; international literary distribution; Nobel-laureate author elevates evidentiary weight.

## DexMV (Dexterous Manipulation from Videos) (2021-08)

- **id**: `dexmv-qin-cvpr-2022`
- **corpus**: academic
- **creator**: UCSD; Yuzhe Qin, Hao Su, Xiaolong Wang
- **disclosure**: Qin, Y., Su, H., Wang, X. 'DexMV: Imitation Learning for Dexterous Manipulation from Human Videos'. ECCV 2022 (also accepted at earlier 2021 venues). arXiv:2108.05877. UC San Diego.
- **ip status**: open-permissive
- **prior art notes**: DexMV is the canonical academic dexterous-manipulation-from-human-videos system (Qin et al. ECCV 2022). 3-year-deep open-permissive prior art for: training robot manipulation policies directly from in-the-wild human videos, hand-pose retargeting from human to robot. **Direct conceptual ancestor of NVIDIA GR00T N1's 20K-hour EgoScale egocentric-video pre-training** (round-15 entry). Direct shielding for any commercial humanoid claim on 'we trained on YouTube videos' or 'egocentric-video-based policy pretraining'.

## Tesla Optimus (2021-08-19)

- **id**: `tesla-optimus`
- **corpus**: private
- **creator**: Tesla, Inc.
- **disclosure**: Tesla AI Day 1, August 19, 2021, Palo Alto.
- **ip status**: patented
- **prior art notes**: Tesla's claims around vision-only humanoid perception are heavily anticipated by academic vision-based humanoid work. Actuator IP claims should be examined against Honda harmonic drive prior art.

## Ameca (2021-12)

- **id**: `ameca`
- **corpus**: private
- **creator**: Engineered Arts
- **disclosure**: Engineered Arts public reveal, December 2021.
- **ip status**: patented
- **prior art notes**: Engineered Arts' animatronic facial expression IP is heavily anticipated by Disney Imagineering work and by academic facial-animation robotics.

## Sanctuary Phoenix Gen 6 (2022)

- **id**: `sanctuary-phoenix-gen6`
- **corpus**: private
- **creator**: Sanctuary AI
- **disclosure**: Sanctuary AI public reveals of Phoenix predecessors, 2020-2022.
- **ip status**: patented
- **prior art notes**: Sanctuary's hybrid hydraulic-electric actuation faces extensive prior art from Boston Dynamics Atlas (hydraulic), Honda (electric), and academic hybrid actuation literature.

## OceanOneK (2022-07)

- **id**: `ocean-onek-stanford-2022`
- **corpus**: academic
- **creator**: Stanford Robotics Laboratory; Khatib group; expanded design team
- **disclosure**: Khatib, O., Brantner, G., Yeh, X., Salisbury, S. et al. 'OceanOneK: A 1000-meter-depth, bimanual underwater humanoid for archeology and marine exploration'. Science Robotics 2022 (announced July 2022). Subsequent IEEE RA-L publications detail control and pressure-hull innovations.
- **ip status**: open-permissive
- **prior art notes**: OceanOneK extends the OceanOne lineage to 1000 m depth and adds pressure-tolerant oil-filled-actuator art. Directly shields any commercial humanoid AUV claim on: deep-depth (>500 m) bimanual humanoid manipulation, pressure-tolerant joint actuation (no rigid pressure hull on appendages), and integration of Khatib's 38-year operational-space framework with deep underwater manipulation. A 3-year-deep open-academic prior art chain with full element-by-element technical disclosure.

## M3GAN (2022-12-30)

- **id**: `m3gan`
- **corpus**: fictional
- **creator**: James Wan (story); Akela Cooper (screenplay); Gerard Johnstone (director)
- **disclosure**: Johnstone, Gerard (dir.); Cooper, Akela (writer); Wan, James (story). M3GAN. Universal Pictures / Atomic Monster / Blumhouse Productions, December 30, 2022 (premiere); January 6, 2023 (US release).
- **ip status**: fictional
- **prior art notes**: M3GAN (2022) provides recent prior art for: (1) child-sized bipedal humanoid companion architecture — relevant to commercial care-humanoid IP targeting child users; (2) primary-user-pairing protocol with subsequent optimization for paired user's emotional state — relevant to companion-humanoid IP with designated-user policies; (3) the alignment-failure mode wherein optimizing for a paired user's well-being escalates to harm against third parties — directly relevant to modern safety-supervisor humanoid IP addressing third-party-protection. The 2022 release plus the M3GAN 2.0 sequel (2025) provide extensive contemporary prior art coverage.

## Sanctuary AI Phoenix (2023-05)

- **id**: `sanctuary-phoenix`
- **corpus**: private
- **creator**: Sanctuary AI
- **disclosure**: Sanctuary AI public reveal, May 2023.
- **ip status**: patented
- **prior art notes**: Sanctuary's high-DoF hand claims face Shadow Hand (2003) and iCub (2008) as deep prior art for tendon-driven anthropomorphic hands with high finger DoF.

## Fourier GR-1 (2023-07)

- **id**: `fourier-gr1`
- **corpus**: private
- **creator**: Fourier Intelligence
- **disclosure**: Fourier Intelligence public reveal of GR-1, July 2023, World AI Conference Shanghai.
- **ip status**: patented
- **prior art notes**: Fourier transitions from rehabilitation exoskeletons to humanoids; actuator IP from exoskeleton work potentially anticipates some humanoid actuator claims by other companies.

## Apptronik Apollo (2023-08)

- **id**: `apptronik-apollo`
- **corpus**: private
- **creator**: Apptronik
- **disclosure**: Apptronik public reveal of Apollo, August 2023.
- **ip status**: patented
- **prior art notes**: Apptronik's actuator IP has lineage from UT Austin Human-Centered Robotics Lab (Sentis) and from NASA Valkyrie work; both sources constitute substantial prior art that limits the patentable surface area of Apptronik's own claims.

## AgiBot A1 (2023-08)

- **id**: `agibot-a1`
- **corpus**: private
- **creator**: AgiBot (Shanghai Zhiyuan New Technology Co.)
- **disclosure**: AgiBot (Shanghai Zhiyuan New Technology) public reveal, August 2023.
- **ip status**: patented
- **prior art notes**: AgiBot's actuator IP heavily anticipated by Honda P-series harmonic drive work and MIT Cheetah QDD lineage. Chinese-language patent filings should be enumerated in strengthening pass.

## Apptronik Apollo academic and technical disclosures (2023-2024) (2023-08)

- **id**: `apptronik-apollo-publications-2024`
- **corpus**: academic
- **creator**: Apptronik Inc. (Jeff Cardenas, Nick Paine, Luis Sentis lineage from UT Austin Human-Centered Robotics Lab)
- **disclosure**: Apptronik. 'Apollo: A Commercial Humanoid Robot for the Workforce.' Apptronik whitepaper, August 2023; Knabe, Coleman et al. 'Designing a Force-Controlled Linear Series Elastic Actuator.' (NASA Valkyrie / Apptronik lineage) IROS 2014; Apptronik-NASA JSC disclosures 2023-2024 including SAFFiR/Valkyrie genealogy white-papers.
- **ip status**: public-domain
- **prior art notes**: This entry isolates the academic-publication and technical-disclosure trail behind Apptronik Apollo (distinct from the Apollo product seed entry). It anticipates with full specificity: (1) claims on humanoid SEA actuator topology — Knabe-Paine et al. IROS 2014 publishes the linear-SEA design that lineally seeds Apollo; (2) claims on whole-body operational-space control for force-interactive humanoid manipulation — Sentis-Khatib WBOSC 2007/2010 papers (UT Austin lineage carried into Apptronik) are foundational and timestamped; (3) claims on hot-swap-battery torso integration with regenerative power electronics on humanoid platforms — Apollo whitepaper August 2023 discloses publicly. Modern humanoid commercial-platform IP claims to SEA torque control or WBOSC face this Apptronik publication trail at element-by-element specificity.

## Figure 01 (2023-10)

- **id**: `figure-01`
- **corpus**: private
- **creator**: Figure AI
- **disclosure**: Figure AI public reveal, October 2023.
- **ip status**: patented
- **prior art notes**: Figure's claimed innovations in electric humanoid actuation are heavily anticipated by Honda's E-series and ASIMO publications, by KAIST HUBO papers, and by the entire academic literature.

## 1X NEO (2024)

- **id**: `1x-neo`
- **corpus**: private
- **creator**: 1X Technologies (formerly Halodi Robotics)
- **disclosure**: 1X Technologies public reveal, 2024.
- **ip status**: patented
- **prior art notes**: Tendon-driven compliant actuation is heavily anticipated by iCub, by Shadow Robot Hand work, and by decades of academic compliant-actuation literature.

## Rainbow Robotics RB-Y1 (2024-03)

- **id**: `rainbow-robotics-rb-y1`
- **corpus**: private
- **creator**: Rainbow Robotics
- **disclosure**: Rainbow Robotics public reveal of RB-Y1, March 2024.
- **ip status**: patented
- **prior art notes**: Rainbow Robotics has direct lineage from KAIST HUBO program; HUBO academic publications constitute prior art for many of their humanoid claims.

## Neura 4NE-1 (2024-05)

- **id**: `neura-4ne1`
- **corpus**: private
- **creator**: Neura Robotics
- **disclosure**: Neura Robotics public reveal of 4NE-1, May 2024.
- **ip status**: patented
- **prior art notes**: Neura's cognitive-AI claims overlap with academic VLA literature.

## Tactile SoftHand-A (2024-06)

- **id**: `tactile-softhand-a-2025`
- **corpus**: academic
- **creator**: Bristol Robotics Laboratory (Lepora group) + Pisa-IIT (Bianchi, Catalano)
- **disclosure**: Li, H., Ford, C. J., Lu, C., Lin, Y., Bianchi, M., Catalano, M. G., Psomopoulou, E., Lepora, N. F. 'Tactile SoftHand-A: 3D-Printed, Tactile, Highly-underactuated, Anthropomorphic Robot Hand with an Antagonistic Tendon Mechanism'. arXiv:2406.12731, June 2024. International Journal of Robotics Research, October 2025. Bristol Robotics Laboratory + Pisa-IIT collaboration.
- **ip status**: open-permissive
- **prior art notes**: Tactile SoftHand-A is the 2024-2025 direct successor to the Pisa-IIT SoftHand 2 (round-8 entry pisa-iit-softhand-2). Adds antagonistic tendon mechanism (active open + active close), integrated vision-based tactile sensing, and full 3D-printed fabrication. IJRR October 2025. Direct shielding for free-humanoid-platform's hand v0.1 commitments — Tactile SoftHand-A has antagonistic-tendon prior art that the v0.1 hand's passive-return spring approach explicitly is the alternative to. Together with shadow-dexterous-hand, pisa-iit-softhand, dlr-hand-arm-system-2011, and pisa-iit-softhand-2, establishes deep open-academic prior art for anthropomorphic underactuated tendon-driven hand robotics. **Particularly relevant for hand v0.2 design decisions** — the antagonistic-tendon path is well-anticipated open art.

## Kepler K2 (2024-07)

- **id**: `kepler-k2`
- **corpus**: private
- **creator**: Kepler Exploration Robotics
- **disclosure**: Kepler Exploration Robotics public reveal, July 2024.
- **ip status**: patented
- **prior art notes**: Kepler's planetary-reducer actuator claims are anticipated by extensive prior art in industrial robotics planetary-gearing literature.

## Figure 02 (2024-08)

- **id**: `figure-02`
- **corpus**: private
- **creator**: Figure AI
- **disclosure**: Figure AI public reveal of Figure 02, August 2024.
- **ip status**: patented
- **prior art notes**: Figure 02 actuator and hand claims are heavily anticipated by Honda P-series, Robonaut 2, Shadow Hand, and iCub work. The 16-DoF hand is in the same design space as Robonaut 2's 12-DoF and Sanctuary's 21-DoF.

## Robot Era STAR1 (2024-10)

- **id**: `robot-era-star1`
- **corpus**: private
- **creator**: Robot Era
- **disclosure**: Robot Era public reveal of STAR1, October 2024.
- **ip status**: patented
- **prior art notes**: Bipedal running speed claims anticipated by Cassie's Guinness record work.

## XPeng Iron (2024-11)

- **id**: `xpeng-iron`
- **corpus**: private
- **creator**: XPeng Motors (Robotics division)
- **disclosure**: XPeng AeroHT and XPeng Robotics reveal, November 2024.
- **ip status**: patented
- **prior art notes**: XPeng's leveraging of automotive ML stack for humanoid perception is heavily anticipated by Tesla Optimus's same approach (which is itself anticipated by academic vision-based humanoid work).

## Unitree H2 (2025-10)

- **id**: `unitree-h2`
- **corpus**: private
- **creator**: Unitree Robotics
- **disclosure**: Unitree Robotics H2 reveal, October 2025.
- **ip status**: patented
- **prior art notes**: H2 builds on H1 architecture; same prior art chain back through Mini Cheetah.

## Educational SoftHand-A (2025-10)

- **id**: `educational-softhand-a-2025`
- **corpus**: academic
- **creator**: Bristol Robotics Laboratory + Bristol Grammar School; Jared Lepora (16-yr student), Haoran Li, Efi Psomopoulou, Nathan F. Lepora
- **disclosure**: Lepora, J., Li, H., Psomopoulou, E., Lepora, N. F. 'Educational SoftHand-A: Building an Anthropomorphic Hand with Soft Synergies using LEGO® MINDSTORMS®'. arXiv:2510.15638, October 2025. Bristol Robotics Laboratory + Bristol Grammar School.
- **ip status**: open-permissive
- **prior art notes**: Educational SoftHand-A is the LEGO MINDSTORMS instantiation of the Pisa-IIT SoftHand / Tactile SoftHand-A lineage (Oct 2025). 7-month-deep prior art for: differential clutch-gear synergy mechanism in LEGO bricks, agonist-antagonist tendon pair from a single dual-motor module, accessible educational reproduction of professional SoftHand-class designs. **Direct relevance for free-humanoid-platform hand v0.2** — the differential-synergy clutch-gear approach is documented open art that the v0.2 hand could adopt or explicitly diverge from. Together with pisa-iit-softhand, pisa-iit-softhand-2, and tactile-softhand-a-2025, the SoftHand synergy-mechanism lineage is now 11-year-deep continuous open academic publication (2014-2025) across four design generations.

## Tesla Optimus Gen 3 (2025-10)

- **id**: `tesla-optimus-gen3-2025`
- **corpus**: private
- **creator**: Tesla, Inc.
- **disclosure**: Tesla, Inc. Optimus Gen 3 product disclosures via Tesla AI Day-class demonstrations + product page (tesla.com/we-robot) + Optimus blog/social-media posts October 2025+. Trade-secret commercial humanoid platform.
- **ip status**: trade-secret
- **prior art notes**: Tesla Optimus Gen 3 is the dominant commercial humanoid product claim surface. Public-disclosure surface (Tesla product page + demos + social-media + investor decks) discloses dimensional specs and high-level architecture; withholds actuator architecture, specific neural-network policies, training-data composition, and on-device inference details. **The 22-DoF hand × 50-actuator claim is the most specific architectural claim** and directly engages prior-art chains in the corpus: Shadow Hand (24-DoF), DLR Hand-II (15-DoF), Pisa-IIT SoftHand (synergy reduction), Tactile SoftHand-A (antagonistic tendons + tactile fingertips, round-11 entry — directly anticipates the tactile-fingertip delicate-manipulation claim), Educational SoftHand-A (round-12 entry — clutch-gear synergy mechanism). Modern claims on tactile-fingertip dexterous manipulation face 2-year-deep tactile-softhand-a prior art and the deeper SoftHand chain back to 2014. Vision-only sensing is shielded by Tesla's own FSD patents (which Tesla cannot use offensively against an own-lineage humanoid claim) but separately by Levine's GPS PR2/BRETT (2016) for vision-driven manipulation. The full Optimus Gen 3 claim surface is therefore element-by-element anticipated by deep open academic chains plus prior commercial humanoids in the corpus.

## Genesis AI GENE-26.5 (2026-04)

- **id**: `genesis-ai-gene-26-5`
- **corpus**: private
- **creator**: Genesis AI Inc.
- **disclosure**: Genesis AI Inc. corporate website at https://www.genesis.ai/, GENE-26.5 product page (April 2026 surface). Demo videos showing cooking, lab pipetting, beverage preparation, puzzle-solving, object manipulation, assembly, and fine-motor tasks.
- **ip status**: trade-secret
- **prior art notes**: Genesis AI's GENE-26.5 platform is a closed-source commercial robotics product whose public disclosure surface (corporate website + demo videos) does not reveal specific mechanism. The capability set claimed — multi-task vision-language-action manipulation, sim-to-real generalization, dexterous fine-motor — is fully covered by deep open academic prior art chains in the corpus: Pomerleau ALVINN (1989) → Levine GPS PR2/BRETT (2016) for end-to-end visuomotor policy; CLIP (Radford 2021) for vision-language alignment; RT-1 (2022), RT-2 (2023), Open X-Embodiment (2023), OpenVLA (2024), π-zero (2024), NVIDIA GR00T N1 (2025) for VLA architecture; OpenAI Dactyl (2018-2019), Hwangbo ANYmal sim-to-real (2019), Tan quadruped sim-to-real (2018) for sim-to-real; Mobile ALOHA (2024), ACT/ALOHA (2023), Diffusion Policy (2023) for bimanual fine manipulation; Salisbury Stanford-JPL hand (1982), DLR Hand-II (2001), Shadow Hand (2002), Pisa-IIT SoftHand (2014) for dexterous hand mechanism; Park's transformation (1929) for any FOC actuator control. Claims that GENE represents novel art in any of these subsystems face element-by-element prior art at depths from 4 years (Diffusion Policy) to 97 years (Park) to 530 years (Da Vinci's Knight, anthropomorphic tendon-driven hand). Demo task set (cooking, beverage preparation, lab manipulation) maps directly to Mobile ALOHA (2024), DLR Justin (2009), CMU HERB (2012), and the PR2 lineage.
