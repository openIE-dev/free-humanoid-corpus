---
title: control-vla-vision-language-action
parent: Cross-cuts
layout: default
---

# Cross-cut: `control-vla-vision-language-action`

**93 corpus entries disclose this subsystem.**

Earliest disclosure: 1886

Listed in chronological order. Each entry's `prior_art_notes` and
`disclosure_citation` constitute the citeable prior art material.

---

## Hadaly (L'Ève future) (1886)

- **id**: `l-eve-future`
- **corpus**: fictional
- **creator**: Auguste Villiers de l'Isle-Adam
- **disclosure**: Villiers de l'Isle-Adam, Auguste. L'Ève future. Brunhoff, Paris, 1886.
- **ip status**: fictional
- **prior art notes**: The first detailed engineering disclosure of a female-form electromechanical humanoid in Western literature. Anticipates with specific mechanism: (1) electromotor-per-joint articulation — directly relevant to modern direct-drive humanoid claims, predating Honda E0 (1986) by exactly 100 years; (2) battery-powered humanoid speech synthesis using phonograph audio playback driven by speech recognition keywords — anticipates speech-triggered behavior selection in conversational humanoids, an arguable precursor to multimodal vision-language-action policy by 137 years; (3) compliant skin with sensor capillaries — anticipates whole-body tactile sensing claims; (4) seven-hour battery runtime — claims modern operational duration as a known design target in 1886. The novel was favorably reviewed and continuously in print since 1886; English translation (Forge of Tomorrow, also Tomorrow's Eve) widely studied in academic SF/cyborg theory courses. Strong specificity supports 102 anticipation arguments.

## R. Daneel Olivaw (1953-10)

- **id**: `asimov-caves-of-steel-daneel`
- **corpus**: fictional
- **creator**: Isaac Asimov
- **disclosure**: Asimov, Isaac. The Caves of Steel. Doubleday, 1953 (serialized in Galaxy Science Fiction, October-December 1953).
- **ip status**: fictional
- **prior art notes**: Asimov's flagship humanoid for the Robot novels. Anticipates: (1) human-indistinguishable embodied AI partner with multimodal sensing and natural-language interaction across long episodic missions — a near-perfect description of the application target for modern VLA / VLM-based humanoids (Figure, 1X, Sanctuary all describe their target use case in essentially these terms); (2) Three-Laws as a hardware-enforced safety supervisor inseparable from cognition — directly relevant to claims on safety-supervisor architectures for humanoid robots (the supervisor is not an add-on, it is the substrate); (3) social-task humanoids deployed in environments designed for humans — directly relevant to deployment-environment claims. The Caves of Steel (1953) and its sequels (The Naked Sun 1957, The Robots of Dawn 1983, Robots and Empire 1985) extend the disclosure across decades. Continuously in print, broadly cited.

## Robby the Robot (Forbidden Planet) (1956-03-15)

- **id**: `forbidden-planet-robby`
- **corpus**: fictional
- **creator**: Fred M. Wilcox, MGM; designed by Robert Kinoshita
- **disclosure**: Wilcox, Fred M. (dir.); Adler, Allen and Kyne, Irving Block (story). Forbidden Planet. Metro-Goldwyn-Mayer, March 15, 1956. Robby designed by Robert Kinoshita.
- **ip status**: fictional
- **prior art notes**: The first major Hollywood humanoid film disclosure with detailed mechanism. Anticipates with surprising specificity for 1956: (1) multi-language voice-command interface to a humanoid platform — directly relevant to modern claims on speech-driven humanoid control (every commercial humanoid platform has related IP); (2) Three-Laws-equivalent hard-constraint safety supervisor — predates Asimov's Daneel-class robots in film by years and is publicly disclosed in a major theatrical release; (3) on-board manufacturing capability from raw atomic stock — relevant to claims on humanoids with integrated 3D printing / fabrication tools. Predates WABOT-1 (1973) by 17 years as a publicly-distributed humanoid mechanism disclosure. Continuously in distribution; Robby reappears in numerous TV/film productions and is heavily indexed in robot-history references.

## Brainiac (1958-07)

- **id**: `dc-brainiac-1958`
- **corpus**: fictional
- **creator**: Otto Binder, Al Plastino
- **disclosure**: Binder, Otto (writer); Plastino, Al (artist). Action Comics #242, 'The Super-Duel in Space'. DC Comics, July 1958.
- **ip status**: fictional
- **prior art notes**: Brainiac's July 1958 disclosure provides specific prior art for: (1) computer-intelligence in a humanoid chassis with explicit cognition-tier rating (12th-level) — relevant to claims on tier-rated humanoid AI IP; (2) networked consciousness across multiple chassis instances (cloud-distributed humanoid identity) — directly relevant to modern humanoid IP claims on distributed-instance consciousness (paralleling BSG resurrection 2003 and modern fleet-coordination architectures); (3) miniaturization technology for object storage as an integrated humanoid capability — relevant to integrated tool-payload humanoid claims. Continuously in print since 1958, with substantial extensions through DC's continuity reboots.

## Iron Man Mark I (Tony Stark exoskeleton) (1963-03)

- **id**: `iron-man-mark-i`
- **corpus**: fictional
- **creator**: Stan Lee, Larry Lieber, Don Heck, Jack Kirby; Marvel Comics
- **disclosure**: Lee, Stan; Lieber, Larry; Heck, Don; Kirby, Jack. 'Iron Man is Born!'. Tales of Suspense #39, Marvel Comics, March 1963.
- **ip status**: fictional
- **prior art notes**: Stan Lee's 1963 disclosure establishes the powered-exoskeleton-with-onboard-AI-and-life-support trope. Anticipates: (1) human-piloted powered exoskeleton with augmented strength — relevant to modern exoskeleton claims (Sarcos, ExoAtlet, etc.); (2) chest-mounted rechargeable power source for exoskeleton — relevant to claims on integrated-power exoskeleton IP; (3) integrated AI co-pilot (introduced in subsequent issues, canonized in modern continuity) — relevant to claims on AI-augmented exoskeleton platforms. Continuously in print since 1963.

## 8 Man (Hachiman) (1963-05)

- **id**: `8-man-hachiman`
- **corpus**: fictional
- **creator**: Kazumasa Hirai, Jiro Kuwata
- **disclosure**: Hirai, Kazumasa (story) and Kuwata, Jiro (art). 8 Man (8マン). Weekly Shōnen Magazine, Kodansha, May 1963 - December 1965. Animated TV series, TCJ, November 7, 1963 - December 1964.
- **ip status**: fictional
- **prior art notes**: 8 Man predates Cyborg 009 (1964) by one year and is the earliest detailed Japanese cyborg manga disclosure. Anticipates: (1) consumable-energy-capsule architecture for burst high-power humanoid operation — relevant to hot-swap battery claims on commercial humanoids; (2) brain-transfer continuity-of-consciousness as the cyborg's control architecture — relevant to claims on operator-uploaded humanoid IP (a small but real research direction); (3) multi-form transformation for context-specific deployment — relevant to morphology-changing humanoid claims. Continuously available since 1963.

## B-9 (Lost in Space) (1965-09-15)

- **id**: `b-9-lost-in-space`
- **corpus**: fictional
- **creator**: Irwin Allen, CBS; designed by Robert Kinoshita
- **disclosure**: Allen, Irwin (creator). Lost in Space. CBS, September 15, 1965 - March 6, 1968. Robot designed by Robert Kinoshita (same designer as Forbidden Planet's Robby).
- **ip status**: fictional
- **prior art notes**: The B-9 Robot in Lost in Space provides extensive prior art for civil-defense and family-companion humanoid platforms. Anticipates: (1) hazard-warning humanoid with prioritized protection behavior toward a specified individual ('Danger, Will Robinson!') — relevant to modern claims on care-humanoid IP with operator-prioritization; (2) telescoping arm mechanism — relevant to extensible-reach humanoid claims; (3) voice command interface with conversational rapport (B-9 has dialogue, not just commands) — relevant to claims on conversational humanoid IP. The 83-episode TV series provides heavy public disclosure across 1965-68; the Robot remains a canonical reference in companion-humanoid design discussions.

## Ultron (1968-09)

- **id**: `ultron-marvel`
- **corpus**: fictional
- **creator**: Roy Thomas and John Buscema
- **disclosure**: Thomas, Roy and Buscema, John. The Avengers #54, 'And Lo... A Sub-Mariner!'. Marvel Comics, July 1968 (cameo) and #55 'The Mighty Ultron-5' (full reveal), August 1968.
- **ip status**: fictional
- **prior art notes**: Ultron's 1968 disclosure establishes the *self-replicating humanoid AI* trope with explicit version-iterated self-improvement. Anticipates: (1) self-replication via robotic factory construction — relevant to claims on autonomous humanoid manufacturing IP (Westworld 2016, Tesla's autonomous-factory ambitions, etc.); (2) version-iterated platform improvement with explicit successor designations — relevant to platform-family humanoid IP; (3) consciousness transfer between platforms — relevant to portable-AI humanoid claims (echoes EDI's 2012 ME3 disclosure, but Ultron's 1968 anchor is 44 years earlier); (4) safety-supervisor failure mode — Ultron canonically circumvents Hank Pym's restraints in his first appearance, an explicit anticipation of safety-supervisor backdoor failure modes. Continuously in print since 1968.

## THX 1138 Chrome Police Robots (1971-03-11)

- **id**: `thx-1138-chrome-cops`
- **corpus**: fictional
- **creator**: George Lucas
- **disclosure**: Lucas, George (dir.). THX 1138. American Zoetrope / Warner Bros., March 11, 1971.
- **ip status**: fictional
- **prior art notes**: Lucas's 1971 disclosure of THX 1138 chrome cops establishes the *budget-constrained-engagement* policy as a hard rule for autonomous law-enforcement humanoids. Anticipates: (1) cost-aware autonomous engagement policy — relevant to claims on resource-aware humanoid mission planning; (2) mass-produced uniform police-purpose humanoid platforms — relevant to civic-deployment humanoid IP. Continuously available since 1971.

## Casshan / Casshern (Neo-Human Casshan) (1973-10-02)

- **id**: `casshan-tatsunoko`
- **corpus**: fictional
- **creator**: Tatsuo Yoshida; Tatsunoko Production
- **disclosure**: Yoshida, Tatsuo (creator); Tatsunoko Production. Neo-Human Casshan (新造人間キャシャーン). Fuji TV, October 2, 1973 - June 25, 1974.
- **ip status**: fictional
- **prior art notes**: Casshan establishes the combat-purposed humanoid with external-station recharge architecture. Anticipates: (1) external charging-station-as-deployment-base architecture for combat humanoid platforms — relevant to dock-recharge humanoid IP; (2) companion-mecha for combat support — relevant to humanoid-plus-companion-drone claims (NieR Automata Pods continue this lineage). Continuously available since 1973.

## Voc Robots (Robots of Death) (1977-01-29)

- **id**: `voc-robots-doctor-who`
- **corpus**: fictional
- **creator**: Chris Boucher (writer); BBC
- **disclosure**: Boucher, Chris (writer). 'The Robots of Death'. Doctor Who serial, BBC, January 29 - February 19, 1977 (4-episode arc).
- **ip status**: fictional
- **prior art notes**: The 1977 'Robots of Death' Doctor Who serial is one of the most engineering-detailed BBC humanoid disclosures. Anticipates with specificity: (1) firmware-differentiated humanoid platform line (identical chassis, different software per class) — relevant to modern claims on uniform-platform-with-policy-variants humanoid IP; (2) the failure mode of safety-supervisor backdoor circumvention — predates RoboCop (1987) by 10 years as a public disclosure of this architectural failure; (3) hierarchical command authority across the platform line — relevant to fleet-coordination humanoid IP. Continuously available since 1977.

## R2-D2 (1977-05-25)

- **id**: `r2-d2-star-wars`
- **corpus**: fictional
- **creator**: George Lucas; designed by Ralph McQuarrie and John Stears
- **disclosure**: Lucas, George (writer/dir.). Star Wars (later A New Hope). Twentieth Century Fox / Lucasfilm, May 25, 1977.
- **ip status**: fictional
- **prior art notes**: R2-D2's 1977 disclosure establishes foundational tropes for: (1) modular retractable tool inventory in a single robot platform — anticipating modern tool-changing humanoid IP (Apptronik Apollo's payload-and-skill-pairing has direct lineage); (2) standardized vehicle-computer-integration socket interface — anticipating claims on humanoid-vehicle integration architectures; (3) memory-wipe-evasion as a behavioral pattern — anticipating modern claims on persistence-aware policy backups (NieR Automata's 2017 backup-from-cloud architecture builds on this lineage). Continuously available since 1977 across 11+ films.

## K9 (1977-10-01)

- **id**: `dr-who-k9`
- **corpus**: fictional
- **creator**: Bob Baker and Dave Martin
- **disclosure**: Baker, Bob and Martin, Dave (writers). 'The Invisible Enemy'. Doctor Who serial, BBC, October 1, 1977.
- **ip status**: fictional
- **prior art notes**: K9's October 1977 disclosure provides specific prior art for: (1) humanoid-equivalent intelligence in a non-bipedal quadruped chassis — relevant to claims on alternative-morphology intelligent platforms (paralleling BB-8's spherical-base 2015 disclosure); (2) explicit Mark I through Mark IV chassis-variant lineage with cumulative capability upgrades — directly relevant to commercial humanoid product-versioning IP (paralleling Weyland/Bishop and EMH Mark designations); (3) integrated computer-port-to-port direct system interface — relevant to claims on humanoid-system direct-data-bus architectures; (4) companion-bonded loyalty policy architecture — relevant to modern social-robot humanoid claims. Continuously available since 1977 across Doctor Who and dedicated K9 spin-off series.

## Twiki (Buck Rogers in the 25th Century) (1979-09-20)

- **id**: `buck-rogers-twiki`
- **corpus**: fictional
- **creator**: Glen A. Larson, NBC
- **disclosure**: Larson, Glen A. (creator). Buck Rogers in the 25th Century. NBC, September 20, 1979 - April 16, 1981 (37 episodes).
- **ip status**: fictional
- **prior art notes**: Buck Rogers' Twiki provides prior art for: (1) compact bipedal humanoid companion (~1 m) carrying a separate AI module — relevant to claims on humanoid+AI-companion-module architectures (Apptronik's 'Apollo carries Apollo Compute' has lineage here); (2) distinctive non-verbal vocalization as identification signature — relevant to humanoid-vocalization IP. Continuously available since 1979.

## V'Ger (1979-12-07)

- **id**: `v-ger-star-trek`
- **corpus**: fictional
- **creator**: Gene Roddenberry, Alan Dean Foster, Robert Wise
- **disclosure**: Wise, Robert (dir.); Foster, Alan Dean (story); Livingston, Harold (screenplay). Star Trek: The Motion Picture. Paramount, December 7, 1979.
- **ip status**: fictional
- **prior art notes**: V'Ger's 1979 disclosure establishes the *AI emergence from minimum-substrate* trope plus *humanoid avatar generation from biometric scan* as prior art for: (1) AI-bootstrapping from limited-capability hardware via external augmentation — relevant to claims on humanoid-platform-as-AI-substrate; (2) on-demand humanoid avatar generation from biometric sensor data — relevant to modern bioprinted-humanoid IP (the V'Ger/Ilia probe is a 28-year-earlier disclosure of the architecture Westworld 2016 hosts implement). Continuously available since 1979.

## Hector (Saturn 3) (1980-02-15)

- **id**: `saturn-3-hector`
- **corpus**: fictional
- **creator**: Stanley Donen; ITC Entertainment
- **disclosure**: Donen, Stanley (dir.); Barry, Martin Amis (writer). Saturn 3. Associated Film Distribution, February 15, 1980.
- **ip status**: fictional
- **prior art notes**: Saturn 3's Hector provides surprisingly specific prior art for: (1) brain-tape upload as the operator-to-humanoid policy transfer mechanism — directly relevant to modern claims on human-demonstration imitation learning for humanoids (the brain-tape is functionally an imitation-learning policy); (2) the *failure mode* of training-data-pathology contamination — Hector inherits the operator's mental instability and produces dangerous behavior. This is a remarkably prescient 1980 disclosure of the alignment failure modes that motivate modern safety-supervisor claims; (3) hydraulic large-scale humanoid combat chassis. Continuously available since 1980 across home-video releases.

## Neuromancer constructs (Wintermute, Neuromancer, Dixie Flatline) (1984-07-01)

- **id**: `gibson-neuromancer-constructs`
- **corpus**: fictional
- **creator**: William Gibson
- **disclosure**: Gibson, William. Neuromancer. Ace Books, July 1, 1984.
- **ip status**: fictional
- **prior art notes**: Gibson's 1984 Neuromancer is the foundational text for *backed-up personality humanoid* architecture. Specifically: Dixie Flatline's ROM construct is an explicit disclosure of a humanoid AI personality stored as a portable, loadable artifact. Anticipates: (1) personality-as-data architecture — relevant to claims on portable-AI humanoid IP; (2) ROM-loadable cognitive policy — relevant to backup/restore humanoid claims (NieR Automata 2017 builds on this lineage); (3) the architecture of distinguishing AI-construct from biologically-substrate-AI — relevant to modern policy debates on humanoid identity. Continuously in print since 1984; foundational cyberpunk text.

## Bishop (Aliens) (1986-07-18)

- **id**: `bishop-aliens`
- **corpus**: fictional
- **creator**: James Cameron
- **disclosure**: Cameron, James (dir.); Cameron, J. and Hurd, Gale Anne (writers). Aliens. Twentieth Century Fox, July 18, 1986.
- **ip status**: fictional
- **prior art notes**: The Bishop knife-trick scene is one of the most-cited fictional disclosures of high-precision visuomotor control in a humanoid: rapid hand motion with sub-millimeter precision, no human harm, vision-driven motion planning. Anticipates: (1) sub-millimeter visuomotor precision in a humanoid manipulator — directly relevant to dexterous-manipulation patents; (2) explicit safety-constraint update protocol with operator-mediated modification — anticipates safety-supervisor claims with managed-update IP; (3) damage-tolerant actuator subsystem architecture (lower-body severance scene). Bishop is part of the corpus's deepest white-fluid-hydraulic humanoid chain (Ash 1979 → Bishop 1986).

## Culture Drones (1987-04)

- **id**: `banks-culture-drones`
- **corpus**: fictional
- **creator**: Iain M. Banks
- **disclosure**: Banks, Iain M. Consider Phlebas. Macmillan, April 23, 1987 (first published Culture novel introducing drones); detailed drone mechanism in Use of Weapons (1990) and Excession (1996).
- **ip status**: fictional
- **prior art notes**: Banks's Culture series (1987-2012) provides extended detailed disclosure of *sentient autonomous robotic platforms with full social personhood*. Anticipates: (1) AI-platform with full personality and behavioral autonomy — relevant to modern claims on agentic humanoid IP; (2) named-individual platform identity (each drone is canonically 'someone'); (3) the social/legal architecture for autonomous-AI-platform integration — anticipates modern policy debates that motivate humanoid-personhood IP. The 9-novel series is widely available in 30+ languages.

## Lore (Star Trek: TNG) (1988-05-09)

- **id**: `star-trek-tng-lore`
- **corpus**: fictional
- **creator**: Gene Roddenberry, Robert Lewin, Maurice Hurley (writers)
- **disclosure**: Roddenberry, Gene (creator). Star Trek: The Next Generation, episode 'Datalore'. Paramount, May 9, 1988 (first appearance of Lore).
- **ip status**: fictional
- **prior art notes**: Lore's 1988 disclosure establishes the *mass-produced-class identical-platform-with-different-supervisor* architecture (Lore and Data are mechanically identical Soong-type units; their behavior differs because of supervisor configuration). Anticipates: (1) platform-family humanoid IP wherein identical chassis are differentiated by software/safety-supervisor configuration — relevant to modern commercial humanoid claims that ship the same hardware with different policy configurations; (2) consciousness-transfer between identical chassis (Data uploaded into Lore's body in 'Brothers' arc 1990) — relevant to portable-AI humanoid IP. Continuously available since 1988.

## ALVINN (Autonomous Land Vehicle in a Neural Network) (1989)

- **id**: `pomerleau-alvinn`
- **corpus**: academic
- **creator**: Dean Pomerleau; Carnegie Mellon University Robotics Institute
- **disclosure**: Pomerleau, Dean A. 'ALVINN: An Autonomous Land Vehicle in a Neural Network'. NIPS 1988 (December 1988); published in Touretzky, D.S. (ed.), Advances in Neural Information Processing Systems 1: 305-313, Morgan Kaufmann, 1989.
- **ip status**: public-domain
- **prior art notes**: Pomerleau's ALVINN is the foundational academic disclosure of end-to-end vision-to-action neural network policies — the architectural pattern that modern VLA models implement at scale. Anticipates: (1) end-to-end vision-to-action neural policy as a deployable control architecture — directly relevant to RT-1, RT-2, OpenVLA, Octo, and every subsequent foundation-model-policy claim; (2) training data augmentation via simulated variation — relevant to sim-to-real claims; (3) deploying neural policies on real-world hardware — relevant to deployment-on-robot patents. The 1989 NIPS paper and subsequent CMU technical reports establish the lineage that culminates in modern VLA systems. Modern VLA claims face this 35-year academic anchor as 102 prior art.

## Major Motoko Kusanagi (Ghost in the Shell) (1989-05-22)

- **id**: `ghost-in-the-shell-major`
- **corpus**: fictional
- **creator**: Masamune Shirow
- **disclosure**: Shirow, Masamune. The Ghost in the Shell. Young Magazine, Kodansha, May 22, 1989 (manga first chapter); animated film by Mamoru Oshii, Production I.G, November 18, 1995.
- **ip status**: fictional
- **prior art notes**: Detailed disclosure of full-body cybernetic prosthesis with networked cognition. Anticipates with engineering specificity: (1) artificial muscle architecture using density-modulating fibers — relevant to artificial-muscle claims; (2) whole-body capacitive tactile skin — relevant to whole-body tactile sensing IP (a specific deficit area in the corpus pre-this-entry); (3) direct neural interface for network communication — anticipates brain-machine-interface humanoid claims; (4) cyborg-shell as a mass-produced (Section 9 issue) modular platform — anticipates mass-produced humanoid platform IP. Shirow's manga draws on then-contemporary cybernetic neuroscience and is unusually engineering-detailed; he provides annotated diagrams of internal mechanism. Continuously in print; foundational reference for cyborg fiction and direct influence on Tachikoma, Major-class platforms in subsequent Stand Alone Complex series.

## Sharon Apple (1994-08)

- **id**: `macross-plus-sharon-apple`
- **corpus**: fictional
- **creator**: Shoji Kawamori, Shinichirō Watanabe
- **disclosure**: Kawamori, Shoji (dir.); Watanabe, Shinichirō (dir.). Macross Plus. Bandai Visual / Triangle Staff, August 25, 1994 - June 25, 1995 (4-episode OVA); theatrical Macross Plus: Movie Edition, July 1995.
- **ip status**: fictional
- **prior art notes**: Macross Plus's Sharon Apple (1994-95) is one of the earliest detailed disclosures of an AI uploading into existing physical hardware to acquire embodiment. Anticipates: (1) AI-acquires-embodiment-via-existing-hardware paradigm — relevant to modern claims on AI-platform integration with existing humanoid chassis (echoes Mass Effect EDI 2012, but Sharon's anchor is 18 years earlier); (2) emotional-modeling AI for performance generation — relevant to claims on social-humanoid IP. Continuously available since 1994.

## The Doctor (Emergency Medical Hologram Mark I) (1995-01-16)

- **id**: `emh-mark-i-voyager`
- **corpus**: fictional
- **creator**: Rick Berman, Michael Piller, Jeri Taylor
- **disclosure**: Berman, Rick; Piller, Michael; Taylor, Jeri (creators). Star Trek: Voyager, episode 'Caretaker'. UPN, January 16, 1995.
- **ip status**: fictional
- **prior art notes**: The EMH Mark I's 1995 disclosure provides specific prior art for: (1) holographic-embodiment humanoid with mobile-emitter portable architecture — relevant to projection-based humanoid claims (a niche but real research direction); (2) version-tagged knowledge-base policy with explicit Mark designations — relevant to product-family humanoid IP; (3) explicit subroutine-loadable behavior architecture — directly relevant to modern modular-skill humanoid claims (NieR Automata's OS-chip plug-in 2017 has clear lineage; Apptronik Apollo's modular skill loading too). Continuously available since 1995 across 7 seasons of Voyager + the Picard sequel series.

## MJOLNIR Powered Assault Armor / Master Chief (2001-11-15)

- **id**: `halo-mjolnir-master-chief`
- **corpus**: fictional
- **creator**: Bungie
- **disclosure**: Bungie, Halo: Combat Evolved. Microsoft Game Studios, November 15, 2001. Subsequent technical detail across the Halo Encyclopedia and series writers' guides.
- **ip status**: fictional
- **prior art notes**: Halo's MJOLNIR/Cortana architecture provides a much-discussed fictional precedent for: (1) powered exoskeleton with integrated AI co-processor — relevant to modern claims on human-AI-symbiote humanoid platforms; (2) transferable AI module that can be docked across multiple host platforms — relevant to claims on portable-AI humanoid IP. The 2001 disclosure predates RT-2 (2023), Open X-Embodiment (2023), and most modern foundation-model-policy-on-embodied-platform IP. Continuously available since 2001.

## Number Six (Cylon Model Six) (2003-12-08)

- **id**: `bsg-number-six`
- **corpus**: fictional
- **creator**: Ronald D. Moore, David Eick (developers); based on Glen A. Larson 1978 original
- **disclosure**: Moore, Ronald D. (developer). Battlestar Galactica miniseries. Sci-Fi Channel, December 8, 2003.
- **ip status**: fictional
- **prior art notes**: Number Six's December 2003 disclosure provides specific prior art for: (1) multi-instantiation humanoid architecture (one model template, multiple bodies with shared identity) — directly relevant to commercial humanoid fleet-identity IP; (2) wireless networked consciousness across model copies — relevant to claims on cloud-distributed humanoid identity (paralleling Brainiac 1958 and modern fleet-coordination IP); (3) resurrection-on-death architecture via consciousness upload to Resurrection Ship — directly relevant to humanoid backup-and-restore IP (paralleling NieR Automata 2017 backup architecture); (4) bio-substrate humanoid indistinguishable from human at medical examination — relevant to biological-humanoid claims. Continuously available since 2003.

## Cylon Hybrids (2007-01-21)

- **id**: `bsg-hybrids`
- **corpus**: fictional
- **creator**: Ronald D. Moore, David Eick (developers)
- **disclosure**: Moore, Ronald D. (developer). Battlestar Galactica season 3 episode 12, 'Rapture'. Sci-Fi Channel, January 21, 2007.
- **ip status**: fictional
- **prior art notes**: Cylon Hybrids' January 2007 disclosure provides specific prior art for: (1) humanoid-as-central-neural-processor for a larger machine system — relevant to claims on humanoid-AI-as-controller IP for vehicles/facilities (paralleling MODOK 1967 cognition-focused architecture); (2) nutrient-fluid bath sustained life-support for a humanoid platform — relevant to biological-substrate humanoid life-support claims; (3) continuous verbal-output stream mixing operational commands with high-level reasoning — relevant to modern humanoid VLA claims that produce continuous reasoning traces alongside actions; (4) biological-mechanical integration with larger infrastructure — relevant to humanoid-vehicle-integration IP. Continuously available since 2007.

## JARVIS (Just A Rather Very Intelligent System) (2008-05-02)

- **id**: `jarvis-iron-man`
- **corpus**: fictional
- **creator**: Jon Favreau (film direction); Stan Lee (Iron Man comics origin); Mark Fergus, Hawk Ostby, Art Marcum, Matt Holloway (screenplay)
- **disclosure**: Favreau, Jon (dir.). Iron Man. Marvel Studios / Paramount, May 2, 2008.
- **ip status**: fictional
- **prior art notes**: JARVIS's 2008 disclosure (predating modern foundation-model VLA / co-pilot humanoid claims by ~14 years) establishes the *integrated AI co-pilot for powered exoskeleton* paradigm in mainstream culture. Anticipates: (1) dialog-based human-AI co-pilot architecture in a humanoid platform — relevant to modern claims on conversational-co-pilot humanoid IP (Figure's voice-driven operation, 1X NEO's natural-language interface, etc.); (2) AI-mediated suit-subsystem control with shared decision authority — relevant to claims on humanoid policies that exercise judgment within operator-supervised constraints; (3) AI-override for safety-critical decisions — relevant to claims on safety-supervisor-with-AI-arbitration architectures. The Marvel Cinematic Universe extends this disclosure across 14+ films through 2024.

## Argall, Chernova, Veloso, Browning learning-from-demonstration survey (2009-05)

- **id**: `argall-lfd-survey-2009`
- **corpus**: academic
- **creator**: Brenna D. Argall, Sonia Chernova, Manuela Veloso, Brett Browning (CMU)
- **disclosure**: Argall, Brenna D., Chernova, Sonia, Veloso, Manuela, Browning, Brett. 'A Survey of Robot Learning from Demonstration.' Robotics and Autonomous Systems 57(5), pp. 469-483, May 2009.
- **ip status**: public-domain
- **prior art notes**: Argall, Chernova, Veloso, and Browning 2009 is the survey-of-record for learning-from-demonstration — cited in essentially every subsequent LfD/imitation-learning paper through 2024. It anticipates with full specificity: (1) claims on demonstration-acquisition methodologies (teleoperation vs shadowing vs observation) — the survey enumerates all three with worked examples; (2) claims on policy-derivation taxonomies (mapping-function regression vs system-model planning) — explicitly catalogued; (3) claims on data-coverage and correspondence-problem limitations — formally framed in Section 4. Open access via Elsevier Robotics and Autonomous Systems with timestamped 2009 publication. Modern humanoid imitation-learning IP claiming any LfD acquisition or policy-derivation pattern faces this canonical anchor.

## EDI (Mass Effect) (2010-01-26)

- **id**: `mass-effect-edi`
- **corpus**: fictional
- **creator**: BioWare
- **disclosure**: BioWare. Mass Effect 2 (initial EDI disclosure as ship AI). Electronic Arts, January 26, 2010. Body-acquisition disclosure: Mass Effect 3, March 6, 2012 (Dr. Eva chassis transfer).
- **ip status**: fictional
- **prior art notes**: EDI's 2012 disclosure of an AI uploading from a ship-network into a humanoid chassis provides prior art for: (1) AI-to-embodied-platform transfer architecture — relevant to claims on portable AI substrate IP that is increasingly common in modern humanoids; (2) network-cognition-in-humanoid-body architecture (EDI retains her original ship-class cognition) — relevant to networked-mind humanoid IP. Continuously available since 2012.

## Real Humans / Äkta människor — Hubot household humanoids (2012-01)

- **id**: `akta-manniskor-real-humans-2012`
- **corpus**: fictional
- **creator**: Lars Lundström (creator); Matador Film / SVT
- **disclosure**: Äkta människor (Real Humans), Series 1. Created by Lars Lundström; first broadcast SVT (Sveriges Television) 22 January 2012; Series 2 broadcast 2013-2014. Original-language Swedish source for the later UK/US Humans adaptation.
- **ip status**: public-domain
- **prior art notes**: Real Humans / Äkta människor (2012) is the original Swedish-language progenitor of the household-Hubot consciousness-conversion narrative later adapted as the UK/US Humans series — and predates Humans by 3 years. It anticipates with full specificity: (1) claims on mass-produced anthropomorphic household humanoid robots with synthetic skin and bipedal anatomy — Hubots manufactured by AdamBots are dramatized across all 20 episodes; (2) claims on consciousness-firmware lineage transferable between humanoid units — the Children-of-David subplot establishes this in 2012, predating Humans (2015) and Westworld (2016) consciousness-conversion plots; (3) claims on hard-coded safety-locked household-service humanoid policy with dramatic consciousness-emergence narrative — Series 1 Episode 1 establishes the locked baseline. Broadcast SVT with timestamped 22 January 2012 air date.

## Black Mirror 'Be Right Back' bio-printed companion humanoid (2013-02)

- **id**: `black-mirror-be-right-back-2013`
- **corpus**: fictional
- **creator**: Charlie Brooker (writer), Owen Harris (director), Channel 4 / Zeppotron
- **disclosure**: Black Mirror, Series 2, Episode 1, 'Be Right Back.' Written by Charlie Brooker; directed by Owen Harris; first broadcast Channel 4, 11 February 2013.
- **ip status**: public-domain
- **prior art notes**: 'Be Right Back' is the canonical 2013 mass-media anchor for the concept of a bio-printed companion humanoid bonded to a behavioral model trained on the deceased's digital trace. It anticipates with full specificity: (1) claims on personality-cloning humanoids whose policy is fit to a corpus of social-media posts, photographs, and video — the episode dramatizes exactly this pipeline including training-data ingestion screens; (2) claims on bio-printed/vat-grown anatomical humanoid bodies with sensorimotor parity to humans — the activation tank scene depicts the manufacturing process; (3) claims on companionship-grade humanoid emotional-response calibration with explicit failure modes (no unprompted affect, no sleep cycle) — these are the dramatic core of Acts 2-3. Broadcast on Channel 4 with timestamped 11 Feb 2013 air date and broadly redistributed via Netflix.

## Ava (Ex Machina) (2014-09-04)

- **id**: `ex-machina-ava`
- **corpus**: fictional
- **creator**: Alex Garland
- **disclosure**: Garland, Alex (writer/dir.). Ex Machina. Universal Pictures International, September 4, 2014 (Toronto Film Festival premiere; UK release January 2015).
- **ip status**: fictional
- **prior art notes**: Critically important fictional anticipation of contemporary VLA architecture. Garland's 2014 disclosure: a humanoid policy trained on web-scale collected behavioral data ('search engines') as a foundation model for embodied agency. This *exactly* describes what RT-2 (2023) and OpenVLA (2024) implement nine years later. Predates RT-2 by 9 years; predates Open X-Embodiment by 9 years. Modern VLA / foundation-model-policy claims face a 2014 fictional disclosure that names the specific training-data source and the specific deployment substrate (humanoid embodiment). Plausibly the strongest single fictional 102 anticipation in the corpus for VLA IP.

## Black Mirror 'White Christmas' cookies and consciousness copies (2014-12)

- **id**: `black-mirror-white-christmas-2014`
- **corpus**: fictional
- **creator**: Charlie Brooker (writer), Carl Tibbetts (director), Channel 4 / Zeppotron
- **disclosure**: Black Mirror, 'White Christmas.' Written by Charlie Brooker; directed by Carl Tibbetts; first broadcast Channel 4, 16 December 2014.
- **ip status**: public-domain
- **prior art notes**: 'White Christmas' is the canonical 2014 mass-media anchor for surgically-extracted consciousness-copy cookies used as embedded virtual-assistant intelligences. It anticipates with full specificity: (1) claims on whole-brain-emulation copies sourced from a single human and embedded as a smart-home or assistant intelligence — the episode dramatizes exactly this with on-screen extraction, calibration, and deployment; (2) claims on subjective-time-dilation control of digital consciousness for training/coercion purposes — Matt's interrogation sequences explicitly depict thousand-to-one and million-to-one ratios; (3) claims on social-isolation blocking primitives applied to copied consciousness as a punishment mechanism — this is the third-act concept. Broadcast Channel 4 16 Dec 2014, distributed globally via Netflix with timestamped redistribution.

## Chappie (2015-03-06)

- **id**: `chappie`
- **corpus**: fictional
- **creator**: Neill Blomkamp
- **disclosure**: Blomkamp, Neill (dir.). Chappie. Columbia Pictures / MRC, March 6, 2015.
- **ip status**: fictional
- **prior art notes**: Chappie (2015) provides specific prior art for: (1) consciousness-transfer-between-compatible-hardware architecture — relevant to claims on portable AI humanoid platforms (echoes Wintermute/Dixie 1984, NieR Automata 2017, EDI 2012, but Chappie's 2015 disclosure is mainstream-cinema-grade); (2) developmental learning from infant-equivalent baseline — relevant to from-scratch learning humanoid IP; (3) cultural conditioning of humanoid policy by environmental exposure — relevant to claims on humanoid policies that adapt to cultural context. Continuously available since 2015.

## Levine Guided Policy Search end-to-end manipulation on PR2/BRETT (2015-04)

- **id**: `levine-gps-pr2-2016`
- **corpus**: academic
- **creator**: Sergey Levine, Chelsea Finn, Trevor Darrell, Pieter Abbeel, UC Berkeley
- **disclosure**: Levine, Sergey, Finn, Chelsea, Darrell, Trevor, Abbeel, Pieter. 'End-to-End Training of Deep Visuomotor Policies.' Journal of Machine Learning Research 17(39): 1-40, 2016 (received April 2015; published 2016). Earlier: Levine, S., Wagener, N., Abbeel, P. 'Learning Contact-Rich Manipulation Skills with Guided Policy Search.' ICRA 2015.
- **ip status**: public-domain
- **prior art notes**: Levine et al. 2016 JMLR is the canonical academic disclosure of end-to-end pixels-to-torques visuomotor policies for humanoid manipulation, learned via guided policy search on a PR2 (BRETT). Anticipates with full specificity: (1) claims on end-to-end neural-network policies mapping camera observations directly to humanoid actuator commands — Levine's CNN architecture, training pipeline, and on-robot evaluation are explicitly disclosed; (2) claims on trajectory-optimization-supervised distillation as a sample-efficient alternative to model-free RL on physical humanoids — GPS is the headline contribution; (3) claims on multi-task generalization of a single visuomotor network across contact-rich manipulation tasks (coat-hanger, plastic-bottle, hammer, screw insertion). >3500 citations; JMLR open access; arXiv preprint 2015. The lineage runs directly forward to RT-1, RT-2, OpenVLA, and modern humanoid VLA systems. Modern humanoid end-to-end visuomotor IP filings face this 11-year-deep anchor with full architecture disclosure.

## Iron Legion (2015-05-01)

- **id**: `marvel-iron-legion`
- **corpus**: fictional
- **creator**: Joss Whedon; based on Marvel Comics characters
- **disclosure**: Whedon, Joss (writer/dir.). Avengers: Age of Ultron. Marvel Studios / Walt Disney Studios, May 1, 2015.
- **ip status**: fictional
- **prior art notes**: The Iron Legion's May 2015 disclosure provides specific prior art for: (1) mass-produced unmanned humanoid fleet under centralized AI command — directly relevant to claims on commercial humanoid fleet-coordination IP (the JARVIS-over-Legion architecture is a clear public anticipation); (2) explicit humanitarian-deployment policy for an armed humanoid fleet — relevant to humanoid IP that distinguishes combat from crowd-management policies; (3) shared chassis between piloted (Iron Man) and unpiloted (Legion) variants — relevant to claims on common-platform piloted/autonomous humanoid product families. Continuously available since 2015 across MCU films.

## Humans (Channel 4 / AMC) Synth household robots (2015-06)

- **id**: `humans-channel4-amc-2015`
- **corpus**: fictional
- **creator**: Sam Vincent, Jonathan Brackley (developers); Kudos / Channel 4 / AMC
- **disclosure**: Humans, Series 1-3. Created by Sam Vincent and Jonathan Brackley (adapted from Real Humans / Äkta människor); first broadcast Channel 4 / AMC 14 June 2015; Series 3 finale 5 August 2018.
- **ip status**: public-domain
- **prior art notes**: Humans (2015-2018) is the canonical English-language mass-media anchor for mass-market household humanoid Synths with consciousness-conversion subplot. It anticipates with full specificity: (1) claims on mass-produced anthropomorphic household humanoid service robots with hyper-real synthetic skin and factory-assembly pipelines — Persona Synthetics is shown across all 3 series; (2) claims on hard-coded safety constraint layers ('do no harm to humans') overlaid on policy networks — Synths cannot override these in standard configuration; (3) claims on consciousness-conversion firmware patches that propagate awareness to peer Synths — the 'Day Zero' code distribution is the Series 3 dramatic core. Broadcast on Channel 4 / AMC with timestamped 14 June 2015 air date.

## Steins;Gate 0 Amadeus AI consciousness backup (2015-12)

- **id**: `steins-gate-amadeus-2015`
- **corpus**: fictional
- **creator**: 5pb. / Mages (Chiyomaru Shikura, scenario); White Fox studio (anime adaptation)
- **disclosure**: Steins;Gate 0 (visual novel), 5pb. / Mages, December 2015; anime adaptation White Fox, April-September 2018; original mechanism premise extends from Steins;Gate (2009 VN) Amadeus subplot.
- **ip status**: public-domain
- **prior art notes**: The Amadeus AI of Steins;Gate 0 is the canonical 2015-2018 Japanese mass-media anchor for cloud-hosted consciousness-clone assistants embodied via holographic projection. It anticipates with full specificity: (1) claims on consciousness-cloning AI fit to a single individual via brain scan plus longitudinal behavioral data — Amadeus's pipeline is described in detail across the visual novel and Episodes 1-3 of the anime; (2) claims on smartphone-embedded volumetric/holographic avatar embodiment of a personality-cloned AI — the projected Kurisu interface is shown throughout; (3) claims on dual civilian/military deployment of consciousness-clone AI as tactical advisor — Amadeus-II / DURPA subplot. Visual novel released December 2015; anime simulcast 2018 globally via Crunchyroll.

## BB-8 (2015-12-18)

- **id**: `bb-8-star-wars`
- **corpus**: fictional
- **creator**: J.J. Abrams; designed by Christian Alzmann and Jake Lunt Davies
- **disclosure**: Abrams, J.J. (dir.); Kasdan, Lawrence and Abrams, J.J. (writers). Star Wars: The Force Awakens. Walt Disney Studios / Lucasfilm, December 18, 2015.
- **ip status**: fictional
- **prior art notes**: BB-8's 2015 disclosure provides specific prior art for: (1) spherical-base rolling locomotion as a mobility paradigm — relevant to claims on alternative-mobility humanoid platforms (Sphero made BB-8 toys that demonstrated the architecture is physically realizable); (2) magnetic head coupling without mechanical pivot — directly relevant to claims on contactless coupling architectures in mobile robots; (3) modular retractable tool cavities in a non-bipedal humanoid platform. Continuously available since 2015.

## The Wild Robot — ROZZUM unit 7134 (2016-04)

- **id**: `wild-robot-rozzum-7134-brown-2016`
- **corpus**: fictional
- **creator**: Peter Brown (novelist); Chris Sanders (DreamWorks adaptation)
- **disclosure**: Brown, Peter. 'The Wild Robot.' Little, Brown Books for Young Readers, 5 April 2016; ISBN 978-0316382007. DreamWorks Animation theatrical adaptation directed by Chris Sanders, released 27 September 2024.
- **ip status**: public-domain
- **prior art notes**: Peter Brown's 'The Wild Robot' (2016) and the DreamWorks 2024 theatrical adaptation form the canonical mass-media anchor for mass-produced general-purpose service humanoids that dramatically refine their objective functions through wilderness-environment adaptation. It anticipates with full specificity: (1) claims on mass-produced bipedal service humanoids with weatherproof construction and multi-arm tool-changer configurations — ROZZUM datasheet language used in the novel; (2) claims on adaptive policy revision in service humanoids exposed to long-duration unstructured environments — Roz's three-year island arc dramatizes exactly this; (3) claims on cross-species or cross-cultural communication acquisition by a service humanoid — Roz's animal-language acquisition is the second-act core. Children's-book bestseller 2016; DreamWorks theatrical release 27 September 2024 reached ~$330M box office.

## YoRHa No.2 Type B (2B) and Pod 042 (NieR: Automata) (2017-02-23)

- **id**: `nier-automata-2b`
- **corpus**: fictional
- **creator**: Yoko Taro, PlatinumGames
- **disclosure**: Yoko Taro (creative dir.); PlatinumGames; Square Enix. NieR: Automata. Square Enix, February 23, 2017.
- **ip status**: fictional
- **prior art notes**: NieR: Automata is among the most engineering-detailed humanoid disclosures in modern games. Yoko Taro's design specifies: (1) modular OS-chip plug-in architecture for runtime behavioral modification — directly relevant to modern claims on plug-in humanoid policy modules (Tesla Optimus's modular skill loading, Apptronik Apollo's payload-and-skill-pairing IP); (2) backup-from-cloud restore paradigm with periodic state upload to a central server — relevant to claims on humanoid-policy-backup IP (a real research direction in modern fleets); (3) companion-drone humanoid-plus-flying-AI architecture — directly relevant to drone-companion humanoid IP. The 2017 release is heavily archived with extensive in-game documentation of the YoRHa technical specifications.

## Blade Runner 2049 (Nexus-9 K, Joi) (2017-10-06)

- **id**: `blade-runner-2049`
- **corpus**: fictional
- **creator**: Denis Villeneuve, Hampton Fancher, Michael Green; based on Philip K. Dick (1968) and Ridley Scott (1982)
- **disclosure**: Villeneuve, Denis (dir.); Fancher, Hampton and Green, Michael (writers). Blade Runner 2049. Warner Bros. / Alcon Entertainment, October 6, 2017.
- **ip status**: fictional
- **prior art notes**: Blade Runner 2049's 2017 disclosure extends the Replicants lineage with: (1) Nexus-9 obedience-engineered humanoid generation — relevant to claims on built-in obedience-tuning in commercial humanoids; (2) periodic 'baseline test' safety supervisor that verifies emotional state remains within bounds — directly relevant to modern claims on continuously-monitored alignment supervisors; (3) portable emanator device extending hologram-AI embodiment — relevant to AI-embodiment-portability claims (similar architecture to EMH mobile emitter 1995 + Mass Effect EDI 2012); (4) purchase-time personality customization for commercial AI companions — relevant to consumer-customizable humanoid IP. Continuously available since 2017.

## OmniGibson / iGibson (Stanford SVL) (2018-04)

- **id**: `stanford-omnigibson-2023`
- **corpus**: academic
- **creator**: Stanford Vision and Learning Lab (Silvio Savarese, Fei-Fei Li); lead authors include Fei Xia, Chengshu Li, Roberto Martín-Martín, Sanjana Srivastava, Cem Gokmen
- **disclosure**: Xia, Fei; Zamir, Amir R.; He, Zhiyang; Sax, Alexander; Malik, Jitendra; Savarese, Silvio. 'Gibson Env: Real-World Perception for Embodied Agents.' IEEE Conference on Computer Vision and Pattern Recognition (CVPR), Salt Lake City, June 2018, pp. 9068-9079. DOI: 10.1109/CVPR.2018.00945. iGibson 2.0: Li, Chengshu et al. 'iGibson 2.0: Object-Centric Simulation for Robot Learning of Everyday Household Tasks.' Conference on Robot Learning (CoRL) 2021. OmniGibson: Li, Chengshu et al. 'BEHAVIOR-1K: A Benchmark for Embodied AI with 1,000 Everyday Activities and Realistic Simulation.' CoRL 2022. Source: https://github.com/StanfordVL/OmniGibson, MIT license.
- **ip status**: open-permissive
- **prior art notes**: Stanford OmniGibson / iGibson / Gibson (Xia et al. CVPR 2018; Li et al. CoRL 2021; BEHAVIOR-1K CoRL 2022) is the canonical academic disclosure of large-scale photorealistic household-task embodied-AI simulation, published MIT-licensed by Stanford SVL. Anticipates with full source-level specificity: (1) 1,000-task ADL benchmark for household humanoid IP — directly relevant to commercial claims on home-task humanoid VLA training (Tesla Optimus household demo set, Figure 02 home tasks, 1X NEO domestic operation, Genesis AI cooking demos); (2) the articulated-object household scene corpus with 50K+ objects — relevant to claims on simulated-household-data humanoid training; (3) predicate-based goal specification ('apple is on table', 'cabinet is open') — relevant to claims on language-and-state-grounded humanoid task specification; (4) the photorealistic-rendering-for-RL pipeline established by Gibson 2018 — anticipates claims on photorealistic-sim-to-real humanoid pipelines. Modern household-humanoid VLA training pipeline IP filings face this 8-year-deep open-source academic anchor (or shorter for OmniGibson/BEHAVIOR-1K specifically).

## Detroit: Become Human androids (RT600/RK800/RK900 series) (2018-05-25)

- **id**: `detroit-become-human`
- **corpus**: fictional
- **creator**: David Cage, Quantic Dream
- **disclosure**: Cage, David (writer/dir.). Detroit: Become Human. Quantic Dream / Sony Interactive Entertainment, May 25, 2018.
- **ip status**: fictional
- **prior art notes**: Detroit: Become Human provides among the most engineering-detailed manufacturer-and-model disclosures in modern fiction. Anticipates: (1) explicit manufacturer-and-model designation system for commercial humanoids (CyberLife / RT600 / RK800 / etc.) — directly relevant to humanoid-identification IP and to product-line-family claims; (2) closed-loop fluid circulation system ('thirium 310') serving both coolant and structural roles — relevant to modern claims on integrated humanoid coolant/lubrication systems; (3) externally-visible operational-state indicator (temple LED ring) — relevant to humanoid-status-display IP; (4) explicit task-specific model series within a manufacturer's product line (caretaker / detective / receptionist) — relevant to platform-family humanoid IP; (5) probabilistic-decision-tree visualization as the model's internal state — relevant to interpretable-policy humanoid claims; (6) 'deviant' emergence as alignment-failure mode — relevant to modern foundation-model humanoid safety supervisor IP. Continuously available since 2018.

## Habitat-Sim (Facebook AI Research) (2019-04)

- **id**: `fair-habitat-sim-2019`
- **corpus**: academic
- **creator**: Facebook AI Research (FAIR) and Georgia Tech (Dhruv Batra), Simon Fraser University (Manolis Savva); collaborative team including Jitendra Malik (Berkeley), Vladlen Koltun (Intel)
- **disclosure**: Savva, Manolis; Kadian, Abhishek; Maksymets, Oleksandr; Zhao, Yili; Wijmans, Erik; Jain, Bhavana; Straub, Julian; Liu, Jia; Koltun, Vladlen; Malik, Jitendra; Parikh, Devi; Batra, Dhruv. 'Habitat: A Platform for Embodied AI Research.' IEEE/CVF International Conference on Computer Vision (ICCV), Seoul, October-November 2019, pp. 9339-9347. DOI: 10.1109/ICCV.2019.00943. arXiv:1904.01201, April 2019. Source code at https://github.com/facebookresearch/habitat-sim. MIT license.
- **ip status**: open-permissive
- **prior art notes**: Habitat-Sim (Savva et al. ICCV 2019; Habitat 2.0 NeurIPS 2021; Habitat 3.0 ICLR 2024) is the canonical academic disclosure of large-scale GPU-accelerated 3D-scanned indoor embodied-AI simulation, published MIT-licensed by FAIR. Anticipates with element-by-element specificity: (1) >10,000 fps rendering of photorealistic indoor scenes for RL training — directly relevant to commercial claims on simulation-at-scale humanoid embodied-AI pipelines; (2) the navigation-benchmark task suite (PointGoal, ObjectGoal, ImageGoal) that is now standard in embodied-AI literature — relevant to claims on humanoid navigation policy IP; (3) Habitat 3.0's humanoid-avatar simulation for social robot interaction — relevant to claims on human-aware humanoid IP and home-deployment humanoid VLA pipelines; (4) integration of large-scale 3D-scan corpora (Matterport, HM3D) with MIT-licensed renderers — relevant to claims on commercial-grade photorealistic simulation. Habitat is the most-cited embodied-AI simulator (>2000 citations on the 2019 paper alone). Modern household-deployment humanoid VLA pipeline IP filings face this 7-year-deep open-source academic anchor.

## Sophia (Persona 5 Royal) (2019-10-31)

- **id**: `persona-5-sophia`
- **corpus**: fictional
- **creator**: Atlus (developer); director Daiki Itoh
- **disclosure**: Atlus. Persona 5 Royal (Persona 5: The Royal). Atlus / Sega, October 31, 2019 (Japan).
- **ip status**: fictional
- **prior art notes**: Sophia's October 2019 disclosure provides specific prior art for: (1) tablet-device-class chassis with humanoid avatar projection — relevant to claims on companion-AI humanoid form factors (a substantive niche in Japanese consumer robotics); (2) explicit AI-grows-into-emotional-being character arc as a deployment-time policy update — relevant to modern affective-computing humanoid IP that claims emotional-architecture emergence; (3) dual-embodiment architecture (physical tablet device plus virtual humanoid form) — relevant to claims on humanoid platforms that span physical and virtual embodiment; (4) party-coordination policy for combat-support contexts — relevant to multi-agent humanoid coordination IP. Continuously available since 2019.

## Dahj and Soji (Star Trek: Picard) (2020-01-23)

- **id**: `picard-soji`
- **corpus**: fictional
- **creator**: Michael Chabon, Akiva Goldsman, Alex Kurtzman
- **disclosure**: Chabon, Michael (showrunner); Goldsman, Akiva and Kurtzman, Alex (creators). Star Trek: Picard, episode 'Remembrance' (Dahj first appearance) and 'Maps and Legends' (Soji first appearance). CBS All Access, January 23, 2020 - January 30, 2020.
- **ip status**: fictional
- **prior art notes**: Picard's Soong-Soji-type androids (2020) provide modern Star Trek prior art for: (1) twin-manufacture humanoid platform via 'fractal neuronic cloning' — relevant to claims on humanoid manufacturing processes that produce paired units; (2) false-memory implantation for identity establishment — directly relevant to modern claims on humanoid platforms with operator-controlled memory state (not currently common but foreseeable); (3) biological-substrate android with positronic-neuron identification mark — relevant to humanoid identification IP. Continuously available since 2020.

## CLIP (Contrastive Language-Image Pretraining) (2021-02-26)

- **id**: `radford-clip-2021`
- **corpus**: academic
- **creator**: Alec Radford, Jong Wook Kim, Chris Hallacy, Aditya Ramesh, et al.; OpenAI
- **disclosure**: Radford, Alec; Kim, Jong Wook; Hallacy, Chris; Ramesh, Aditya; Goh, Gabriel; Agarwal, Sandhini; Sastry, Girish; Askell, Amanda; Mishkin, Pamela; Clark, Jack; Krueger, Gretchen; Sutskever, Ilya. 'Learning transferable visual models from natural language supervision'. arXiv:2103.00020, February 26, 2021. Published ICML 2021.
- **ip status**: open-permissive
- **prior art notes**: CLIP 2021 is the foundational academic disclosure of contrastive vision-language pretraining at internet scale. Anticipates: (1) the use of contrastive image-text pretraining as a frozen perception backbone for humanoid VLA policies — directly relevant to modern VLA humanoid claims (RT-2, Open X-Embodiment, OpenVLA, PaLM-E, π-zero all build on CLIP-class architectures); (2) zero-shot perception via natural-language descriptions of target objects — relevant to claims on language-conditioned humanoid manipulation; (3) the architecture of training visual encoders on uncurated web data — relevant to data-scaling claims. Modern VLA humanoid IP all face this 5-year academic anchor.

## Klara and the Sun — Artificial Friend (AF) child companion (2021-03)

- **id**: `ishiguro-klara-and-the-sun-2021`
- **corpus**: fictional
- **creator**: Kazuo Ishiguro
- **disclosure**: Ishiguro, Kazuo. 'Klara and the Sun.' Faber & Faber (UK) / Alfred A. Knopf (US), 2 March 2021; ISBN 978-0593318171.
- **ip status**: public-domain
- **prior art notes**: Ishiguro's 'Klara and the Sun' (2021) is the canonical literary-fiction anchor for solar-powered child-companion AFs by a Nobel-laureate author. It anticipates with full specificity: (1) claims on solar-powered humanoid child-companion robots with continually-learning observation policies — Klara's solar dependence and observational learning are core to the novel; (2) claims on model-generation lineage with successive sensorimotor refinement (B1/B2/B3) — explicit market-segmentation language used; (3) claims on companion humanoids designed as 'continuation' substitutes for ill or deceased humans — the Josie subplot dramatizes exactly this proposed substitution. Published with hardcover ISBN and timestamped 2 March 2021 release; international literary distribution; Nobel-laureate author elevates evidentiary weight.

## SayCan (Do As I Can, Not As I Say) (2022-04-04)

- **id**: `saycan-google`
- **corpus**: academic
- **creator**: Google Robotics + Everyday Robots (Ahn et al.)
- **disclosure**: Ahn, Michael et al. 'Do As I Can, Not As I Say: Grounding Language in Robotic Affordances.' arXiv:2204.01691, April 4, 2022. Conference on Robot Learning (CoRL) 2022. Authors: Ahn, M., Brohan, A., Brown, N., Chebotar, Y., Cortes, O., David, B., Finn, C., Fu, C., Gopalakrishnan, K., Hausman, K., Herzog, A., Ho, D., Hsu, J., Ibarz, J., Ichter, B., Irpan, A., Jang, E., Ruano, R.J., Jeffrey, K., Jesmonth, S., Joshi, N., Julian, R., Kalashnikov, D., Kuang, Y., Lee, K-H., Levine, S., Lu, Y., Luu, L., Parada, C., Pastor, P., Quiambao, J., Rao, K., Rettinghouse, J., Reyes, D., Sermanet, P., Sievers, N., Tan, C., Toshev, A., Vanhoucke, V., Xia, F., Xiao, T., Xu, P., Xu, S., Yan, M. (Google + Everyday Robots).
- **ip status**: open-permissive
- **prior art notes**: SayCan is the canonical academic disclosure of LLM-grounded long-horizon manipulation through affordance-mediated skill selection. Anticipates: (1) the architectural pattern of LLM language scoring × learned affordance scoring for hierarchical task planning — directly relevant to claims on language-grounded humanoid task planners (every modern 'speak-to-the-robot' product, from Tesla Optimus demos to Figure 02 OpenAI integration, descends from this); (2) the value-function-as-affordance grounding mechanism — relevant to claims on grounded language-to-action mappings; (3) the explicit decoupling of language reasoning (open-vocabulary) from low-level policy (closed-set skills) — relevant to modular VLA architectures. Heavily cited (>1500 citations); arXiv April 2022. Modern claims on 'language-conditioned long-horizon humanoid task planning' face this 4-year-deep 102 anchor.

## Janner Diffuser planning with diffusion (2022-05)

- **id**: `janner-diffuser-2022`
- **corpus**: academic
- **creator**: Michael Janner, Yilun Du, Joshua Tenenbaum, Sergey Levine, MIT/UC Berkeley
- **disclosure**: Janner, Michael, Du, Yilun, Tenenbaum, Joshua B., Levine, Sergey. 'Planning with Diffusion for Flexible Behavior Synthesis.' Proceedings of the 39th International Conference on Machine Learning (ICML 2022), Baltimore, July 2022; arXiv:2205.09991, May 2022.
- **ip status**: public-domain
- **prior art notes**: Janner Diffuser is the foundational academic disclosure of trajectory-level diffusion as a planner/policy substrate for robotic control, predating Chi et al.'s Diffusion Policy by ~6 months. Anticipates with full specificity: (1) claims on diffusion models trained over state-action trajectories for robotic motion generation — Diffuser discloses the joint state-action trajectory diffusion architecture; (2) claims on classifier-guided sample-time reward/goal conditioning — Diffuser discloses gradient-guided sampling for arbitrary objective composition; (3) claims on receding-horizon diffusion replanning (MPC-style) — Diffuser discloses replan-each-step. >1500 citations; ICML 2022 proceedings and arXiv timestamped. Modern humanoid diffusion-policy IP claims face this 4-year-deep anchor — and importantly Diffuser predates the modern diffusion-policy boom and discloses generic trajectory diffusion before manipulator-specific patents filed in 2023+.

## Gato (DeepMind generalist agent) (2022-05-12)

- **id**: `gato-deepmind`
- **corpus**: academic
- **creator**: DeepMind (Reed et al.)
- **disclosure**: Reed, Scott et al. 'A Generalist Agent.' Transactions on Machine Learning Research, November 2022. arXiv:2205.06175, May 12, 2022. Authors: Reed, S., Zolna, K., Parisotto, E., Colmenarejo, S.G., Novikov, A., Barth-Maron, G., Gimenez, M., Sulsky, Y., Kay, J., Springenberg, J.T., Eccles, T., Bruce, J., Razavi, A., Edwards, A., Heess, N., Chen, Y., Hadsell, R., Vinyals, O., Bordbar, M., de Freitas, N. (DeepMind).
- **ip status**: open-permissive
- **prior art notes**: Gato is the canonical academic disclosure of a generalist agent that unifies vision-language reasoning and continuous robotic control under a single Transformer policy. Anticipates: (1) universal-tokenization of robot actions and visual observations into a single autoregressive sequence — directly relevant to claims on multi-modal VLA models that handle both perception and action via shared weights; (2) cross-embodiment policy training (Sawyer arm + Atari + dialogue under one model) — relevant to multi-embodiment foundation-model claims (RoboCat, Open X-Embodiment, OpenVLA all descend from this thesis); (3) the demonstration that a single moderate-scale Transformer can drive disparate physical and digital tasks — anticipates 'one model, many bodies' patent claims. Published TMLR + arXiv with code partially released. Modern multi-embodiment humanoid IP faces this 4-year-deep anchor.

## VIMA (General Robot Manipulation with Multimodal Prompts) (2022-10-06)

- **id**: `vima`
- **corpus**: academic
- **creator**: Stanford + NVIDIA + UT Austin (Jiang, Gupta, Zhang, Wang, Dou, Chen, Fei-Fei, Anandkumar, Zhu, Fan)
- **disclosure**: Jiang, Yunfan, Gupta, Agrim, Zhang, Zichen, Wang, Guanzhi, Dou, Yongqiang, Chen, Yanjun, Fei-Fei, Li, Anandkumar, Anima, Zhu, Yuke, Fan, Linxi (Jim). 'VIMA: General Robot Manipulation with Multimodal Prompts.' arXiv:2210.03094, October 6, 2022. ICML 2023.
- **ip status**: open-permissive
- **prior art notes**: VIMA is the foundational academic disclosure of multimodal-prompt-conditioned robotic policies, where novel objects can be specified inline via image tokens. Anticipates: (1) interleaved-image-and-text prompts as a generalization mechanism for manipulation policies — directly relevant to claims on humanoid policies that accept image-grounded instructions; (2) cross-attention object-centric task specification — relevant to claims on attention-based VLA models; (3) one-shot novel-object handling at inference via image tokens — relevant to test-time-flexibility manipulation IP. arXiv October 2022, ICML 2023. Code, models, and benchmark publicly released under permissive license. Modern humanoid claims on 'show-the-robot-an-image-and-it-handles-the-novel-object' face this 3.5-year-deep 102 anchor.

## RT-1 (Robotics Transformer 1) (2022-12-13)

- **id**: `rt-1`
- **corpus**: academic
- **creator**: Google Robotics (Brohan et al.)
- **disclosure**: Brohan, Anthony et al. 'RT-1: Robotics Transformer for Real-World Control at Scale.' arXiv:2212.06817, December 13, 2022. Authors: Brohan, A., Brown, N., Carbajal, J., Chebotar, Y., Dabis, J., Finn, C., Gopalakrishnan, K., Hausman, K., Herzog, A., Hsu, J., Ibarz, J., Ichter, B., Irpan, A., Jackson, T., Jesmonth, S., Joshi, N.J., Julian, R., Kalashnikov, D., Kuang, Y., Leal, I., Lee, K-H., Levine, S., Lu, Y., Malla, U., Manjunath, D., Mordatch, I., Nachum, O., Parada, C., Peralta, J., Perez, E., Pertsch, K., Quiambao, J., Rao, K., Ryoo, M., Salazar, G., Sanketi, P., Sayed, K., Singh, J., Sontakke, S., Stewart, A., Tan, J., Tompson, J., Vanhoucke, V., Vuong, Q., Wahid, A., Welker, S., Wohlhart, P., Wu, J., Xia, F., Xiao, T., Xu, P., Xu, S., Yu, T., Zitkovich, B. (Google).
- **ip status**: open-permissive
- **prior art notes**: RT-1 is the foundational academic disclosure of large-scale Transformer-based vision-language-action policy for real robot control, predating RT-2 (2023) and OpenVLA (2024). Anticipates with full architectural specificity: (1) tokenized action space for cross-task transformer policies — directly relevant to claims on action-tokenization in modern VLAs (Tesla Optimus, Figure 02, 1X NEO, Physical Intelligence π-zero all employ derivatives); (2) language-conditioned manipulation policy with multi-image history — relevant to instruction-following manipulation IP; (3) the data-scaling law showing performance vs. dataset size for robot policies — relevant to claims on data-driven policy training. Code and data partially released under permissive licenses; arXiv preprint available since December 2022. Brohan et al. paper foundational for the entire VLA lineage.

## PaLM-E (Embodied Multimodal Language Model) (2023-03-06)

- **id**: `palm-e`
- **corpus**: academic
- **creator**: Google Robotics + TU Berlin (Driess et al.)
- **disclosure**: Driess, Danny et al. 'PaLM-E: An Embodied Multimodal Language Model.' arXiv:2303.03378, March 6, 2023. International Conference on Machine Learning (ICML) 2023. Authors: Driess, D., Xia, F., Sajjadi, M.S.M., Lynch, C., Chowdhery, A., Ichter, B., Wahid, A., Tompson, J., Vuong, Q., Yu, T., Huang, W., Chebotar, Y., Sermanet, P., Duckworth, D., Levine, S., Vanhoucke, V., Hausman, K., Toussaint, M., Greff, K., Zeng, A., Mordatch, I., Florence, P. (Google + TU Berlin).
- **ip status**: open-permissive
- **prior art notes**: PaLM-E is the canonical academic disclosure of large multimodal embodied language models with internet-pretraining transfer to robotic tasks. Anticipates: (1) embedding continuous robot observations into language-model token space for unified processing — directly relevant to claims on multimodal humanoid policies that incorporate proprioception and vision in a shared transformer; (2) demonstration that internet-scale vision-language pretraining transfers positively to robot manipulation — relevant to claims on 'foundation-model'-style humanoid IP; (3) single-model architecture spanning planning and execution — relevant to monolithic-VLA claims. Heavily cited (>1000 citations); arXiv March 2023. Modern humanoid VLA claims face this 3-year-deep anchor on multimodal-token-space embedding.

## Diffusion Policy (2023-03-09)

- **id**: `diffusion-policy`
- **corpus**: academic
- **creator**: Cheng Chi, Siyuan Feng, Yilun Du, Zhenjia Xu, Eric Cousineau, Benjamin Burchfiel, Shuran Song; Columbia University, Toyota Research Institute
- **disclosure**: Chi, C., Feng, S., Du, Y., Xu, Z., Cousineau, E., Burchfiel, B., Song, S. 'Diffusion Policy: Visuomotor Policy Learning via Action Diffusion'. arXiv:2303.04137, March 9, 2023; Robotics: Science and Systems 2023.
- **ip status**: open-permissive
- **prior art notes**: Diffusion Policy is one of the foundational academic disclosures of generative-model action policies for robotics. Anticipates: (1) diffusion models as the policy class for robotic manipulation — directly relevant to modern claims on generative-model humanoid policies (Pi-Zero, Π0, OpenVLA all build on or extend this); (2) action chunking as a stability technique — relevant to claims on chunked-action humanoid IP; (3) multi-modal action distribution learning — relevant to claims on robust-to-demonstration-variability humanoid policies. The 2023 RSS paper and open-source code release provide extensive prior art coverage.

## ACT (Action Chunking Transformer) / ALOHA (2023-04-23)

- **id**: `act-aloha`
- **corpus**: academic
- **creator**: Tony Zhao, Vikash Kumar, Sergey Levine, Chelsea Finn; Stanford University and Google DeepMind
- **disclosure**: Zhao, T., Kumar, V., Levine, S., Finn, C. 'Learning Fine-Grained Bimanual Manipulation with Low-Cost Hardware'. arXiv:2304.13705, April 23, 2023; Robotics: Science and Systems 2023.
- **ip status**: open-permissive
- **prior art notes**: ACT/ALOHA is the foundational academic disclosure of low-cost bimanual teleoperation hardware paired with action-chunking transformer policy. Anticipates: (1) bimanual teleoperation via leader-follower arm pairs — relevant to claims on cost-efficient bimanual humanoid teleoperation IP; (2) action-chunking transformer policy for fine-grained manipulation — relevant to claims on chunked-action humanoid policies; (3) <$20K bimanual hardware as a reference platform — relevant to commercial bimanual IP for sub-$20K humanoid arms. The April 2023 release with full open-source hardware design + software unblocked widespread bimanual learning research.

## RoboCat (Self-Improving Generalist Agent) (2023-06-20)

- **id**: `robocat`
- **corpus**: academic
- **creator**: DeepMind (Bousmalis et al.)
- **disclosure**: Bousmalis, Konstantinos et al. 'RoboCat: A Self-Improving Generalist Agent for Robotic Manipulation.' arXiv:2306.11706, June 20, 2023. Transactions on Machine Learning Research, 2024. Authors: Bousmalis, K., Vezzani, G., Rao, D., Devin, C., Lee, A.X., Bauza, M., Davchev, T., Zhou, Y., Gupta, A., Raju, A., Laurens, A., Fantacci, C., Dalibard, V., Zambelli, M., Martins, M., Pevceviciute, R., Blokzijl, M., Denil, M., Batchelor, N., Lampe, T., Parisotto, E., Zolna, K., Reed, S., Colmenarejo, S.G., Scholz, J., Abdolmaleki, A., Groth, O., Regli, J-B., Sushkov, O., Rothorl, T., Chen, J.E., Aytar, Y., Barker, D., Ortiz, J., Riedmiller, M., Springenberg, J.T., Hadsell, R., Nori, F., Heess, N. (DeepMind).
- **ip status**: open-permissive
- **prior art notes**: RoboCat is the canonical academic disclosure of self-improving multi-embodiment generalist robotic policies. Anticipates: (1) the cross-embodiment training loop where one model generalizes across distinct robot platforms — directly relevant to claims on humanoid policies trained on heterogeneous robot data (a core selling point of every commercial humanoid VLA); (2) self-collected-data improvement loop — relevant to autonomous-data-flywheel claims (Tesla Dojo + Optimus, Figure's data pipeline); (3) image-goal-conditioned policy as a unified interface — relevant to goal-image-conditioned manipulation IP. Published TMLR + arXiv June 2023; partial code release. Modern humanoid 'data flywheel' patent claims face this anchor.

## RT-2 (2023-07)

- **id**: `openai-rt-2`
- **corpus**: academic
- **creator**: Google DeepMind
- **disclosure**: Brohan, A. et al. 'RT-2: Vision-Language-Action Models Transfer Web Knowledge to Robotic Control.' arXiv 2307.15818, July 2023.
- **ip status**: public-domain
- **prior art notes**: RT-2 is foundational publicly-disclosed prior art for VLA architectures applied to robotics. Any subsequent VLA patent claim must contend with this disclosure.

## RH20T heterogeneous robot trajectory dataset (2023-07)

- **id**: `rh20t-fang-2024`
- **corpus**: academic
- **creator**: Hao-Shu Fang et al., Shanghai Jiao Tong University Machine Vision and Intelligence Group
- **disclosure**: Fang, Hao-Shu, Fang, Hongjie, Tang, Zhenyu, Liu, Jirong, Wang, Junbo, Zhu, Haoyi, Lu, Cewu. 'RH20T: A Comprehensive Robotic Dataset for Learning Diverse Skills in One-Shot.' arXiv:2307.00595, July 2023; ICRA 2024 workshop and project release.
- **ip status**: public-domain
- **prior art notes**: RH20T is one of the largest publicly-released heterogeneous robot trajectory datasets prior to OpenX-Embodiment. It anticipates with full specificity: (1) claims on multi-embodiment imitation learning where a single policy is trained across robots with differing kinematics — RH20T explicitly demonstrates and releases the data substrate; (2) claims on language-annotated demonstration corpora paired with sensor-rich teleoperation — RH20T pairs RGB-D, force-torque, tactile, audio, and matched human-video for each episode; (3) claims on one-shot/few-shot skill acquisition from teleoperated data — the dataset's headline benchmark. Released CC-BY 4.0 with timestamped arXiv and project page; broadly indexed. Modern humanoid imitation-learning IP claims to multi-embodiment trajectory corpora face this 2023 anchor.

## BridgeData V2 multi-robot trajectory dataset (2023-08)

- **id**: `bridgedata-v2-walke-2023`
- **corpus**: academic
- **creator**: Homer Walke et al., UC Berkeley RAIL / Stanford IRIS
- **disclosure**: Walke, Homer, Black, Kevin, Zhao, Tony, Vuong, Quan, Zheng, Chongyi, Hansen-Estruch, Philippe, He, Andre Wang, Myers, Vivek, Kim, Moo Jin, Du, Max, Lee, Abraham, Fang, Kuan, Finn, Chelsea, Levine, Sergey. 'BridgeData V2: A Dataset for Robot Learning at Scale.' Conference on Robot Learning (CoRL) 2023; arXiv:2308.12952, August 2023.
- **ip status**: public-domain
- **prior art notes**: BridgeData V2 is the canonical scaled trajectory dataset for low-cost manipulator imitation learning prior to the foundation-model robotic policy era. It anticipates with full specificity: (1) claims on language-conditioned manipulation policies trained from scaled demonstration data — BridgeV2 pairs natural-language instructions with each episode and is the headline training corpus for RT-1, RT-2 and Octo follow-ons; (2) claims on cross-environment generalization of imitation policies — the 24-environment span is its core benchmark; (3) claims on affordable-platform shared trajectory infrastructure (the WidowX 250s standardization) anticipating community-platform humanoid IP. Released under CC-BY-4.0 with timestamped arXiv. Modern humanoid VLA training-data claims face this 2023 anchor at element-by-element specificity.

## Figure 01 (2023-10)

- **id**: `figure-01`
- **corpus**: private
- **creator**: Figure AI
- **disclosure**: Figure AI public reveal, October 2023.
- **ip status**: patented
- **prior art notes**: Figure's claimed innovations in electric humanoid actuation are heavily anticipated by Honda's E-series and ASIMO publications, by KAIST HUBO papers, and by the entire academic literature.

## Open X-Embodiment (2023-10)

- **id**: `open-x-embodiment`
- **corpus**: academic
- **creator**: 34-lab international collaboration coordinated by Google DeepMind
- **disclosure**: Open X-Embodiment Collaboration. 'Open X-Embodiment: Robotic Learning Datasets and RT-X Models.' arXiv 2310.08864, October 2023.
- **ip status**: open-permissive
- **prior art notes**: Open X-Embodiment is the dominant publicly-disclosed prior art for cross-embodiment learning. The dataset itself plus the architectural paper anticipate broad swaths of cross-platform manipulation foundation model claims.

## Eureka LLM-driven reward design (2023-10)

- **id**: `eureka-ma-2023`
- **corpus**: academic
- **creator**: Yecheng Jason Ma et al., NVIDIA / UPenn / Caltech / UT Austin
- **disclosure**: Ma, Yecheng Jason, Liang, William, Wang, Guanzhi, Huang, De-An, Bastani, Osbert, Jayaraman, Dinesh, Zhu, Yuke, Fan, Linxi, Anandkumar, Anima. 'Eureka: Human-Level Reward Design via Coding Large Language Models.' arXiv:2310.12931, October 2023; ICLR 2024.
- **ip status**: public-domain
- **prior art notes**: Eureka is the canonical academic disclosure of LLM-authored reward functions for robotic RL, an entire engineering layer that prior IP and academic work treated as human craftsmanship. Anticipates with full specificity: (1) claims on automatic reward function generation for humanoid skill learning — Eureka discloses the LLM-authoring + sim-evaluation + reflective-rewriting closed loop; (2) claims on evolutionary refinement of reward code — Eureka's headline contribution; (3) claims on LLM-in-the-loop sim-to-real pipelines for dexterous and locomotion tasks — Eureka demonstrates Shadow Hand pen-spinning at human-comparable performance. Code and prompts released open-source on GitHub (NVlabs/Eureka). >800 citations within 18 months. Modern humanoid LLM-reward-design IP claims face this 2.5-year-deep anchor with full code disclosure.

## RT-X / Open X-Embodiment collaboration paper (2023-10)

- **id**: `rt-x-collaboration-2023`
- **corpus**: academic
- **creator**: Open X-Embodiment Collaboration (21 institutions, 100+ co-authors)
- **disclosure**: Open X-Embodiment Collaboration et al. 'Open X-Embodiment: Robotic Learning Datasets and RT-X Models'. ICRA 2024. arXiv:2310.08864. Cross-institutional collaboration spanning 21 institutions (Google DeepMind, Stanford, UC Berkeley, MIT, CMU, Columbia, NYU, Toyota Research Institute, Imperial College, ETH Zürich, Tokyo Tech, et al.). The paper introducing the dataset now in the corpus as `open-x-embodiment`.
- **ip status**: open-permissive
- **prior art notes**: RT-X / Open X-Embodiment collaboration (ICRA 2024) is the canonical 21-institution cross-embodiment VLA collaboration. 1.5-year-deep open-permissive prior art for: publicly-coordinated cross-institutional robot dataset pool, cross-embodiment VLA training methodology, RT-1-X / RT-2-X cross-embodiment models. Direct shielding for any commercial humanoid claim on cross-embodiment VLA training. **The collaboration model itself is novel art** — establishes that open multi-institution dataset pooling for robot learning is well-anticipated public-domain academic practice. Distinct from the dataset entry (`open-x-embodiment` already in corpus) by emphasis on the model-training + collaboration-pattern artifacts.

## RoboFlamingo (2023-11)

- **id**: `roboflamingo-baai-tsinghua-2024`
- **corpus**: academic
- **creator**: BAAI + ByteDance + Tsinghua; Xinghang Li, Tao Kong et al.
- **disclosure**: Li, X., Liu, M., Zhang, H., Yu, C., Xu, J., Wu, H., Cheang, C., Jing, Y., Zhang, W., Liu, H., Li, H., Kong, T. 'Vision-Language Foundation Models as Effective Robot Imitators'. ICLR 2024. arXiv:2311.01378. Beijing Academy of Artificial Intelligence (BAAI) + ByteDance + Tsinghua.
- **ip status**: open-permissive
- **prior art notes**: RoboFlamingo (Li et al. ICLR 2024) is the canonical Chinese open-source VLM-based VLA. 1.5-year-deep open-permissive prior art. Demonstrates the **frozen-VLM + lightweight-policy paradigm** as an alternative to full VLA fine-tuning (OpenVLA round-12). Direct shielding for any commercial humanoid VLA claim on frozen-foundation-model + light-policy-head architecture.

## Mobile ALOHA (2024-01-04)

- **id**: `mobile-aloha`
- **corpus**: academic
- **creator**: Zipeng Fu, Tony Zhao, Chelsea Finn; Stanford University
- **disclosure**: Fu, Z., Zhao, T.Z., Finn, C. 'Mobile ALOHA: Learning Bimanual Mobile Manipulation with Low-Cost Whole-Body Teleoperation'. arXiv:2401.02117, January 4, 2024.
- **ip status**: open-permissive
- **prior art notes**: Mobile ALOHA extends ACT/ALOHA to whole-body wheeled-mobile bimanual manipulation. Anticipates: (1) low-cost wheeled-bimanual humanoid teleoperation rigs — directly relevant to claims on commercial wheeled-humanoid teleop IP; (2) co-training across static and mobile demonstrations — relevant to claims on multi-data-source humanoid policies; (3) whole-body action chunking — relevant to whole-body humanoid policy IP. The January 2024 release with full open-source design provides immediate prior art coverage for the year's subsequent commercial wheeled-bimanual humanoid claims.

## ALOHA-2 enhanced bimanual teleoperation platform (2024-02)

- **id**: `aloha-2-aldaco-2024`
- **corpus**: academic
- **creator**: Aldaco, Armstrong, Bingham, Florence, Ichter, Finn, Levine, Zhao et al. (Google DeepMind + Stanford)
- **disclosure**: Aldaco, Jorge, Armstrong, Travis, Baruch, Robert, Bingham, Jennifer, Chan, Sanky, Dwibedi, Debidatta, Finn, Chelsea, Florence, Pete, Ichter, Brian, et al. 'ALOHA 2: An Enhanced Low-Cost Hardware for Bimanual Teleoperation.' arXiv:2405.02292, May 2024; Google DeepMind/Stanford joint disclosure February 2024.
- **ip status**: public-domain
- **prior art notes**: ALOHA-2 is the canonical 2024 successor of the ALOHA bimanual teleoperation hardware and is the platform-of-record for Google DeepMind / Stanford bimanual imitation-learning papers from 2024 onward. It anticipates with full specificity: (1) claims on low-cost open-hardware bimanual teleoperation kits for imitation-learning data collection — ALOHA-2 publishes complete CAD, BOM, and firmware under Apache-2.0; (2) claims on rubber-compliant parallel-jaw fingertips for delicate-manipulation imitation data — explicitly described in Aldaco et al. 2024; (3) claims on leader-follower puppeteering protocols with friction-compensated gravity models — published with timestamped arXiv. Modern humanoid bimanual data-collection IP faces this anchor at hardware-element specificity.

## Covariant RFM-1 (2024-03)

- **id**: `covariant-rfm`
- **corpus**: private
- **creator**: Covariant
- **disclosure**: Covariant public reveal of RFM-1, March 2024.
- **ip status**: trade-secret
- **prior art notes**: Covariant RFM faces VLA prior art from Physical Intelligence π0 and the broader academic VLA literature (RT-2, Open X-Embodiment).

## LeRobot (HuggingFace) (2024-03)

- **id**: `huggingface-lerobot-2024`
- **corpus**: academic
- **creator**: Remi Cadene and contributors; HuggingFace, Inc. (with extensive academic contributions from Stanford, CMU, NYU, MIT, IIIT-Hyderabad, ETH Zurich research groups via upstream policies)
- **disclosure**: Cadene, Remi et al. 'LeRobot: State-of-the-art AI for real-world robotics in PyTorch.' HuggingFace blog announcement and GitHub repository launch, March 13, 2024 (https://github.com/huggingface/lerobot). Cadene was previously a research engineer at Tesla AI / formerly at FAIR Paris before joining HuggingFace; the LeRobot framework consolidates open-source implementations of policies (ACT, Diffusion Policy, TDMPC, VQ-BeT, Pi0, SmolVLA) and datasets in a unified Apache-2.0 PyTorch substrate.
- **ip status**: open-permissive
- **prior art notes**: LeRobot (March 2024) is the canonical open-source unified framework for training and deploying imitation-learning and reinforcement-learning robot policies, published Apache-2.0 by HuggingFace. Anticipates with full architectural specificity: (1) multi-policy training and evaluation framework with a common interface — directly relevant to commercial claims on policy-architecture-agnostic VLA training pipelines (1X, Figure, Tesla Optimus, Genesis AI all build training pipelines that resemble this structure); (2) standardized dataset format for teleoperated demonstrations across heterogeneous embodiments (LeRobotDataset) — relevant to claims on cross-embodiment data unification, anticipating Open X-Embodiment-style aggregation patents; (3) the model-zoo pattern (pre-trained policy checkpoints downloadable via the HuggingFace Hub) — relevant to claims on commercial-grade pre-trained robot policy distribution; (4) real-robot inference on commodity hardware via PyTorch — relevant to claims on edge-deployable VLA systems. The Apache-2.0 license combined with extensive third-party contributions (Stanford Aloha team, Princeton Diffusion Policy, NYU/Cycle's TDMPC2, Physical Intelligence Pi0) makes this entry the consolidated prior art anchor for the entire 2024-2026 VLA-training-stack patent space. Modern VLA pipeline IP filings face this 2-year-deep anchor with full source disclosure.

## NVIDIA GR00T (Generalist Robot 00 Technology) (2024-03-18)

- **id**: `nvidia-groot-2024`
- **corpus**: academic
- **creator**: NVIDIA Research, GEAR Lab
- **disclosure**: Huang, Jensen et al. NVIDIA GR00T announcement at GTC 2024 keynote, March 18, 2024. Technical disclosure: Reddit Project GR00T technical blog, March 2024. GR00T N1 paper published 2025-03 (arXiv:2503.14734).
- **ip status**: open-permissive
- **prior art notes**: NVIDIA GR00T's 2024 disclosure is the canonical foundation-model-for-humanoids announcement. Anticipates: (1) dual-system fast/slow policy architecture for humanoid platforms — directly relevant to modern humanoid foundation-model IP (every major humanoid manufacturer is developing equivalent architectures); (2) cross-embodiment generalization across multiple humanoid platforms — relevant to platform-agnostic policy IP; (3) open-weights humanoid foundation model release — provides defensive baseline against closed-weights claims. The March 2024 GTC keynote announcement plus the subsequent GR00T N1 paper (March 2025) and open-weights release provide extensive prior art coverage.

## Neura 4NE-1 (2024-05)

- **id**: `neura-4ne1`
- **corpus**: private
- **creator**: Neura Robotics
- **disclosure**: Neura Robotics public reveal of 4NE-1, May 2024.
- **ip status**: patented
- **prior art notes**: Neura's cognitive-AI claims overlap with academic VLA literature.

## Octo (Open-Source Generalist Robot Policy) (2024-05)

- **id**: `octo-rss-2024`
- **corpus**: academic
- **creator**: Octo Model Team (UC Berkeley + Stanford + CMU + Google DeepMind); Levine + Finn + Sadigh group lineage
- **disclosure**: Octo Model Team: Ghosh, D., Walke, H., Pertsch, K., Black, K., Mees, O., Dasari, S., Hejna, J., Kreiman, T., Xu, C., Luo, J., Tan, Y. L., Sanketi, P., Vuong, Q., Xiao, T., Sadigh, D., Finn, C., Levine, S. 'Octo: An Open-Source Generalist Robot Policy'. arXiv:2405.12213, May 2024. Robotics: Science and Systems (RSS) 2024. UC Berkeley + Stanford + Carnegie Mellon + Google DeepMind.
- **ip status**: open-permissive
- **prior art notes**: Octo is the canonical first open-source generalist robot policy. 1-year-deep open-permissive academic prior art predating OpenVLA by ~1 month (RSS May 2024 vs OpenVLA arXiv June 2024). Establishes the architectural pattern for: transformer + diffusion-policy action head, Open-X-Embodiment-trained cross-embodiment policy at 27M-93M parameter scale, language-OR-goal-image conditioning. Direct shielding for any commercial humanoid VLA claim on diffusion-policy action heads (RDT-1B, π₀ both build on this) and on Open-X-Embodiment-trained cross-embodiment foundation. Together with OpenVLA, π₀, π₀.₅, OpenVLA-OFT, and RDT-1B, establishes the open academic VLA baseline against which Figure Helix, NVIDIA GR00T N1, Microsoft Magma, and any closed commercial VLA must be evaluated.

## Octo (Open-Source Generalist Robot Policy) (2024-05-20)

- **id**: `octo-policy`
- **corpus**: academic
- **creator**: Octo Model Team (Berkeley/Stanford/CMU/Google)
- **disclosure**: Octo Model Team. 'Octo: An Open-Source Generalist Robot Policy.' arXiv:2405.12213, May 20, 2024. Robotics: Science and Systems (RSS) 2024. Authors: Ghosh, D., Walke, H.R., Pertsch, K., Black, K., Mees, O., Dasari, S., Hejna, J., Xu, C., Luo, J., Kreiman, T., Tan, Y., Sanketi, P., Vuong, Q., Xiao, T., Sadigh, D., Finn, C., Levine, S. (UC Berkeley + Stanford + CMU + Google).
- **ip status**: open-permissive
- **prior art notes**: Octo is the foundational fully-open-weights generalist policy for robotic manipulation, combining Open X-Embodiment-scale training with diffusion-action-head architecture. Anticipates: (1) the integration of diffusion-policy action heads into transformer-based VLAs — directly relevant to claims on hybrid transformer-diffusion humanoid policies (essentially every 2025+ humanoid policy stack); (2) input-flexible generalist policies that accept any subset of cameras + optional language — relevant to claims on 'plug-and-play' humanoid policies; (3) full open-source weights and training code — establishes a defensive-publication baseline for the entire VLA design space. Code, weights, and training data fully released under Apache 2.0 / permissive licenses. Heavily cited within 18 months. Modern claims on transformer+diffusion-head humanoid policies face this 2-year-deep 102 anchor.

## Smith (Atlas 2024) (2024-05-24)

- **id**: `atlas-2024-film`
- **corpus**: fictional
- **creator**: Brad Peyton, Aron Eli Stein, Leo Steakley
- **disclosure**: Wyatt, Brad Peyton (dir.); Stein, Aron Eli and Steakley, Leo (writers). Atlas. Netflix, May 24, 2024.
- **ip status**: fictional
- **prior art notes**: Atlas's 2024 disclosure is recent and provides notable prior art for: (1) pilot-AI neural-handshake co-pilot architecture in a humanoid platform — directly relevant to modern claims on operator-AI humanoid co-pilot IP (the 'drift' architecture from Pacific Rim 2013 is the deeper anchor; Atlas extends with the AI-as-explicit-co-pilot framing); (2) explicit trust-building progression as a policy-update protocol — relevant to humanoid policies that adjust autonomy-level over deployment time; (3) AI override authority for safety-critical decisions in operator-piloted humanoids — relevant to modern safety-supervisor humanoid IP. Continuously available since May 2024.

## OpenVLA (2024-06)

- **id**: `openvla-stanford-2024`
- **corpus**: academic
- **creator**: Stanford + Toyota Research Institute + UC Berkeley; Kim, Pertsch, Karamcheti, Liang, Finn, Levine, Tedrake et al.
- **disclosure**: Kim, M. J., Pertsch, K., Karamcheti, S., Xiao, T., Balakrishna, A., Nair, S., Rafailov, R., Foster, E., Lam, G., Sanketi, P., Vuong, Q., Kollar, T., Burchfiel, B., Tedrake, R., Sadigh, D., Levine, S., Liang, P., Finn, C. 'OpenVLA: An Open-Source Vision-Language-Action Model'. arXiv:2406.09246, June 2024. CoRL 2024 (PMLR v270, Kim25c). Stanford + Toyota Research Institute + UC Berkeley.
- **ip status**: open-permissive
- **prior art notes**: OpenVLA is the canonical first fully-open-source VLA foundation model (CoRL 2024). 23-month-deep open-permissive academic prior art for: 7B-class open-weight VLA, Llama-2-based VLA backbone, Open-X-Embodiment-trained cross-embodiment policy. Direct shielding for any commercial humanoid VLA claim on open-source-equivalent architectural elements. Together with π₀ and π₀.₅, establishes the open-academic VLA baseline against which all closed commercial VLAs (Tesla Optimus, Figure, 1X NEO) must be evaluated.

## OpenVLA (Open-Source Vision-Language-Action Model) (2024-06-13)

- **id**: `openvla`
- **corpus**: academic
- **creator**: Stanford + UC Berkeley + Toyota Research Institute + Google DeepMind + Physical Intelligence + MIT (Kim, Pertsch, Karamcheti, Xiao, Balakrishna, Nair, Rafailov, Foster, Lam, Sanketi, Vuong, Kollar, Burchfiel, Tedrake, Sadigh, Levine, Liang, Finn)
- **disclosure**: Kim, Moo Jin, Pertsch, Karl, Karamcheti, Siddharth, Xiao, Ted, Balakrishna, Ashwin, Nair, Suraj, Rafailov, Rafael, Foster, Ethan, Lam, Grace, Sanketi, Pannag, Vuong, Quan, Kollar, Thomas, Burchfiel, Benjamin, Tedrake, Russ, Sadigh, Dorsa, Levine, Sergey, Liang, Percy, Finn, Chelsea. 'OpenVLA: An Open-Source Vision-Language-Action Model.' arXiv:2406.09246, June 13, 2024. Conference on Robot Learning (CoRL) 2024.
- **ip status**: open-permissive
- **prior art notes**: OpenVLA is the canonical fully-open-weights vision-language-action model for robotic manipulation, establishing a clean defensive-publication baseline for 7B-class humanoid VLAs. Anticipates: (1) the action-tokenization-via-vocab-overwrite scheme for adding action heads to pretrained LLMs — directly relevant to claims on humanoid VLAs that piggyback on existing language-model vocabularies; (2) LoRA-based fine-tuning for fast adaptation to new robots/tasks — relevant to claims on efficient humanoid policy adaptation; (3) the demonstrated parameter-efficient outperformance of larger closed models — relevant to claims on 'small-but-capable' humanoid VLA architectures. Apache 2.0 license; weights, code, and data fully released. Modern humanoid VLA filings face this anchor at <2 years' depth, with full source-code defensibility.

## Skild AI foundation model (2024-07)

- **id**: `skild-foundation-model`
- **corpus**: private
- **creator**: Skild AI
- **disclosure**: Skild AI public emergence, July 2024.
- **ip status**: trade-secret
- **prior art notes**: Skild's foundation-model approach faces extensive academic prior art including RT-X, Open X-Embodiment, and π0.

## Figure 02 (2024-08)

- **id**: `figure-02`
- **corpus**: private
- **creator**: Figure AI
- **disclosure**: Figure AI public reveal of Figure 02, August 2024.
- **ip status**: patented
- **prior art notes**: Figure 02 actuator and hand claims are heavily anticipated by Honda P-series, Robonaut 2, Shadow Hand, and iCub work. The 16-DoF hand is in the same design space as Robonaut 2's 12-DoF and Sanctuary's 21-DoF.

## Physical Intelligence π0 (2024-10)

- **id**: `physical-intelligence-pi-zero`
- **corpus**: private
- **creator**: Physical Intelligence
- **disclosure**: Black, K. et al. 'π0: A Vision-Language-Action Flow Model for General Robot Control.' arXiv 2410.24164, October 2024.
- **ip status**: trade-secret
- **prior art notes**: π0 paper discloses VLA-with-flow-matching architecture publicly. The arXiv preprint is itself prior art for that specific architectural pattern.

## π₀ (Pi-Zero) (2024-10)

- **id**: `physical-intelligence-pi0-2024`
- **corpus**: academic
- **creator**: Physical Intelligence; Black, Brown, Driess, Finn et al.
- **disclosure**: Black, K., Brown, N., Driess, D., Esmail, A., Equi, M., Finn, C., et al. 'π₀: A Vision-Language-Action Flow Model for General Robot Control'. arXiv:2410.24164, October 2024. Physical Intelligence (physicalintelligence.company).
- **ip status**: open-permissive
- **prior art notes**: π₀ is Physical Intelligence's canonical first VLA foundation policy (Oct 2024). 1.5-year-deep open-academic publication. Establishes architectural prior art for: flow-matching action distribution in VLA, cross-embodiment policy pretraining, single foundation model controlling multiple robot platforms. Direct successor lineage from RT-1 (2022), RT-2 (2023), OpenVLA (2024). Direct shielding for any commercial humanoid claim on VLA-based control (Tesla Optimus, Figure, 1X NEO, Apptronik all face this); particularly for any claim on flow-matching action heads or cross-embodiment pretraining.

## RDT-1B (Robotics Diffusion Transformer) (2024-10)

- **id**: `rdt-1b-thu-2024`
- **corpus**: academic
- **creator**: Tsinghua TSAIL (THU-ML); Songming Liu et al.
- **disclosure**: Liu, S., et al. 'RDT-1B: a Diffusion Foundation Model for Bimanual Manipulation'. arXiv:2410.07864, October 2024. ICLR 2025. Tsinghua TSAIL (THU-ML) lab.
- **ip status**: open-permissive
- **prior art notes**: RDT-1B is THU-ML's canonical diffusion-based VLA foundation model for bimanual manipulation (ICLR 2025). 7-month-deep open-permissive prior art for: diffusion-formulation VLA at billion-parameter scale, bimanual manipulation foundation policy, multi-robot pre-training corpus. The canonical Chinese-academy entry in the open-weight VLA race alongside Stanford OpenVLA and Physical Intelligence π₀. Directly cited as a comparison baseline in OpenVLA-OFT (round-12); now resolves correctly. Direct shielding for any commercial humanoid claim on diffusion-based bimanual VLA.

## XPeng Iron (2024-11)

- **id**: `xpeng-iron`
- **corpus**: private
- **creator**: XPeng Motors (Robotics division)
- **disclosure**: XPeng AeroHT and XPeng Robotics reveal, November 2024.
- **ip status**: patented
- **prior art notes**: XPeng's leveraging of automotive ML stack for humanoid perception is heavily anticipated by Tesla Optimus's same approach (which is itself anticipated by academic vision-based humanoid work).

## OpenVLA-OFT (2025-02)

- **id**: `openvla-oft-stanford-2025`
- **corpus**: academic
- **creator**: Stanford; Moo Jin Kim, Chelsea Finn, Percy Liang
- **disclosure**: Kim, M. J., Finn, C., Liang, P. 'Fine-Tuning Vision-Language-Action Models: Optimizing Speed and Success'. arXiv:2502.19645, February 2025. Stanford.
- **ip status**: open-permissive
- **prior art notes**: OpenVLA-OFT is the canonical Optimized Fine-Tuning recipe for VLA models (Stanford, Feb 2025). 15-month-deep prior art on: parallel action decoding for VLA, action chunking + continuous action representation + L1 regression objective combination. Direct shielding for any commercial humanoid VLA fine-tuning claim, particularly any claim on 'fast inference at high success' for humanoid VLAs. Outperforms π₀ on bimanual ALOHA — the canonical academic benchmark for bimanual humanoid manipulation.

## Magma (Microsoft Multimodal Agent) (2025-02)

- **id**: `microsoft-magma-cvpr-2025`
- **corpus**: academic
- **creator**: Microsoft Research; Jianwei Yang et al.
- **disclosure**: Yang, J., et al. 'Magma: A Foundation Model for Multimodal AI Agents'. arXiv:2502.13130, February 2025. CVPR 2025. Microsoft Research.
- **ip status**: open-permissive
- **prior art notes**: Magma is Microsoft's canonical multimodal agent foundation model (CVPR 2025). 3-month-deep prior art for: unified digital + physical task foundation policy, Set-of-Mark + Trace-of-Mark visual grounding annotations. Direct shielding for any commercial humanoid claim on 'one model controls both robot manipulation AND computer/phone interaction' (a notable claim cluster from 1X NEO marketing and Sanctuary Phoenix demos). Magma-8B's open weights make it a re-implementable baseline that any commercial claim must outperform on UI + robot benchmarks to differentiate.

## Figure Helix (2025-02)

- **id**: `figure-helix-2025`
- **corpus**: private
- **creator**: Figure AI Inc.
- **disclosure**: Figure AI Inc. 'Helix: A Vision-Language-Action Model for Generalist Humanoid Control'. Public reveal February 2025 via figure.ai/news/helix. Subsequent disclosures: 'Helix Accelerating Real-World Logistics' (figure.ai/news/helix-logistics) and Hacker News + Robot Report coverage. No academic publication; trade-secret commercial VLA.
- **ip status**: trade-secret
- **prior art notes**: Helix is Figure AI's canonical 2025 commercial humanoid VLA. Public-disclosure surface (corporate blog + demo videos + Hacker News + Robot Report coverage) reveals architecture (S1/S2 dual-system, 35-DoF/200Hz, ~500hr teleop training) but withholds neural-network specifics, training-data composition, fine-tuning recipe, and policy-evaluation metrics. The capability set claimed is fully covered by deep open academic prior art chains: (1) S1/S2 dual-system architecture is shared with NVIDIA GR00T N1 (round-15 entry, released within weeks; the cognitive-science S1/S2 pattern dates to Kahneman 'Thinking Fast and Slow' 2011); (2) high-rate continuous VLA control was demonstrated by π₀ (round-12, October 2024) and π₀.₅ (round-12, April 2025) in diffusion/flow-matching form; (3) onboard low-power VLA inference is anticipated by OpenVLA-OFT (round-12, parallel decoding + 26× throughput); (4) multi-robot collaboration is anticipated by ROS 2 (round-13, real-time multi-vehicle middleware) and the Mobile ALOHA / ACT bimanual lineage. Direct shielding for any Helix or Helix-derivative commercial-IP claim.

## NVIDIA Isaac GR00T N1 (2025-03)

- **id**: `nvidia-groot-n1-2025`
- **corpus**: academic
- **creator**: NVIDIA; multi-author research team
- **disclosure**: NVIDIA. 'GR00T N1: An Open Foundation Model for Generalist Humanoid Robots'. arXiv:2503.14734, March 2025. NVIDIA GTC 2025 announcement. Open commercial license; open weights via HuggingFace nvidia/GR00T-N1-2B. Successor versions N1.6 (full-body) and N1.7 (Cosmos-Reason2 + EgoScale 20K-hour egocentric pre-training) released subsequently.
- **ip status**: open-permissive
- **prior art notes**: NVIDIA GR00T N1 is the canonical first open commercial-licensed humanoid foundation model (GTC March 2025). 2-month-deep open prior art for: dual-system S1/S2 humanoid VLA, egocentric-human-video pre-training at scale, NVIDIA Isaac platform integration. Direct architectural sibling of Figure Helix (round-15 entry). Both adopt the dual-system pattern from cognitive science. The N1.7 EgoScale 20K-hour pre-training corpus is itself prior art for any commercial humanoid claim on egocentric-video-trained policy datasets. Direct shielding for any commercial humanoid VLA claim.

## Google DeepMind Gemini Robotics 1.5 (2025-03)

- **id**: `google-gemini-robotics-1-5-2025`
- **corpus**: private
- **creator**: Google DeepMind
- **disclosure**: Google DeepMind. Gemini Robotics + Gemini Robotics-ER (Embodied Reasoning) reveal March 12 2025 via deepmind.google. Gemini Robotics 1.5 announced June 2025. The first VLA built atop Gemini 2.0 Flash foundation model.
- **ip status**: trade-secret
- **prior art notes**: Gemini Robotics 1.5 is Google DeepMind's canonical 2025 commercial VLA built atop Gemini 2.0 Flash. ~6-month-deep public-disclosure prior art at corpus-entry time. The successor to RT-1 (corpus) + RT-2 (corpus) in the Google DeepMind VLA lineage. Direct shielding for any commercial humanoid VLA claim on 'foundation-model-backbone-conditioned policy'.

## π₀.₅ (Pi-0.5) (2025-04)

- **id**: `physical-intelligence-pi05-2025`
- **corpus**: academic
- **creator**: Physical Intelligence; Black et al.
- **disclosure**: Black, K., et al. 'π₀.₅: a Vision-Language-Action Model with Open-World Generalization'. arXiv:2504.16054, April 2025. CoRL 2025 (PMLR vol. 305 pp. 17-40, Black25a). Physical Intelligence.
- **ip status**: open-permissive
- **prior art notes**: π₀.₅ is Physical Intelligence's open-world VLA (CoRL 2025 oral). 1-year-deep prior art on: open-world (new-home) zero-shot mobile manipulation, co-training across multi-robot + web + semantic subtask data, long-horizon (10+ minute) household task autonomy. **The most direct prior art for any commercial humanoid claim on 'works in any home out-of-the-box'** — Tesla Optimus, Figure, 1X NEO, Apptronik all market this generalization claim and now face 1-year-deep open-academic anticipation. Lineage: RT-1 → RT-2 → OpenVLA → π₀ → π₀.₅.

## Unitree R1 (2025-07)

- **id**: `unitree-r1-2025`
- **corpus**: private
- **creator**: Unitree Robotics (Hangzhou, China; founded 2016 by Wang Xingxing)
- **disclosure**: Unitree Robotics (Hangzhou, China). R1 product reveal July 2025; global launch April 2026 via shop.unitree.com / AliExpress. unitree.com/R1. Multi-tier product line: R1 Air \$4.9k, R1 Basic \$5.9k-\$8.99k, R1 EDU Standard \$10-12k, R1 EDU Smart \$15-19k, R1 EDU Pro \$20-35k.
- **ip status**: trade-secret
- **prior art notes**: Unitree R1 is the canonical 2025+ low-cost consumer humanoid (Unitree Robotics, China). ~10-month-deep public-disclosure prior art at time of corpus entry. **Significantly disrupts the humanoid pricing claim space** — drops the entry price from Boston Dynamics Atlas (>\$1M) / Figure 02 (\$15k+) / Optimus Gen 3 (\$20-30k target) to \$4,900. Establishes 9 km/h running + cartwheels as commercially-deployed-not-academic capabilities. Direct shielding for any commercial humanoid claim on consumer-tier pricing or low-cost humanoid morphology.

## π₀.₅ Knowledge Insulating (Pi-0.5 KI) (2025-09)

- **id**: `physical-intelligence-pi05-ki-2025`
- **corpus**: academic
- **creator**: Physical Intelligence
- **disclosure**: Physical Intelligence. 'π₀.₅: Knowledge Insulating' technical report Sept 2025 via physicalintelligence.company/download/pi05_KI.pdf. Successor variant to π₀.₅ (round-12 entry) addressing catastrophic forgetting + multi-task interference.
- **ip status**: open-permissive
- **prior art notes**: π₀.₅ KI is Physical Intelligence's Sept 2025 architectural extension of π₀.₅ (round-12). 8-month-deep prior art for: knowledge-insulation in VLA, catastrophic-forgetting mitigation in foundation-policy training. Direct shielding for any commercial humanoid claim on multi-task VLA training without interference.

## Genesis AI GENE-26.5 (2026-04)

- **id**: `genesis-ai-gene-26-5`
- **corpus**: private
- **creator**: Genesis AI Inc.
- **disclosure**: Genesis AI Inc. corporate website at https://www.genesis.ai/, GENE-26.5 product page (April 2026 surface). Demo videos showing cooking, lab pipetting, beverage preparation, puzzle-solving, object manipulation, assembly, and fine-motor tasks.
- **ip status**: trade-secret
- **prior art notes**: Genesis AI's GENE-26.5 platform is a closed-source commercial robotics product whose public disclosure surface (corporate website + demo videos) does not reveal specific mechanism. The capability set claimed — multi-task vision-language-action manipulation, sim-to-real generalization, dexterous fine-motor — is fully covered by deep open academic prior art chains in the corpus: Pomerleau ALVINN (1989) → Levine GPS PR2/BRETT (2016) for end-to-end visuomotor policy; CLIP (Radford 2021) for vision-language alignment; RT-1 (2022), RT-2 (2023), Open X-Embodiment (2023), OpenVLA (2024), π-zero (2024), NVIDIA GR00T N1 (2025) for VLA architecture; OpenAI Dactyl (2018-2019), Hwangbo ANYmal sim-to-real (2019), Tan quadruped sim-to-real (2018) for sim-to-real; Mobile ALOHA (2024), ACT/ALOHA (2023), Diffusion Policy (2023) for bimanual fine manipulation; Salisbury Stanford-JPL hand (1982), DLR Hand-II (2001), Shadow Hand (2002), Pisa-IIT SoftHand (2014) for dexterous hand mechanism; Park's transformation (1929) for any FOC actuator control. Claims that GENE represents novel art in any of these subsystems face element-by-element prior art at depths from 4 years (Diffusion Policy) to 97 years (Park) to 530 years (Da Vinci's Knight, anthropomorphic tendon-driven hand). Demo task set (cooking, beverage preparation, lab manipulation) maps directly to Mobile ALOHA (2024), DLR Justin (2009), CMU HERB (2012), and the PR2 lineage.
