# Cross-cut: `sensing-stereo-camera`

**54 corpus entries disclose this subsystem.**

Earliest disclosure: 1973

Listed in chronological order. Each entry's `prior_art_notes` and
`disclosure_citation` constitute the citeable prior art material.

---

## WABOT-1 (1973)

- **id**: `wabot-1`
- **corpus**: academic
- **creator**: Waseda University, Kato Laboratory
- **disclosure**: Kato, Ichiro et al. 'Information-Power Machine with Senses and Limbs (WABOT-1).' Proceedings of First CISM-IFToMM Symposium on Theory and Practice of Robots and Manipulators, 1973.
- **ip status**: public-domain
- **prior art notes**: First full-scale humanoid in academic record. Anticipates virtually every subsystem of modern humanoids at concept level: bipedal locomotion, bimanual manipulation, multimodal sensing, natural language interface. Specific implementations are crude by modern standards but the architectural decomposition is foundational.

## Sony AIBO (1999-05-11)

- **id**: `sony-aibo`
- **corpus**: private
- **creator**: Sony Corporation
- **disclosure**: Sony Corporation announcement of AIBO ERS-110, May 11, 1999.
- **ip status**: patented
- **prior art notes**: AIBO is foundational prior art for consumer quadruped robots. Sony's 1990s-2000s patents cover quadruped behavior architecture, learning systems, and small-form-factor actuators. Many expired or near expiration.

## ASIMO (2000-10-31)

- **id**: `asimo`
- **corpus**: private
- **creator**: Honda Motor Co.
- **disclosure**: Honda Motor Co. press conference, Tokyo, October 31, 2000.
- **ip status**: patented
- **prior art notes**: ASIMO's public disclosures and Honda's published papers anticipate most claimed innovations in modern bipedal humanoids. The Hirose/Ogawa 2007 Phil. Trans. paper is a particularly comprehensive disclosure that should be referenced when reading current humanoid patent claims.

## HRP-2 (2002)

- **id**: `hrp-2`
- **corpus**: academic
- **creator**: AIST (National Institute of Advanced Industrial Science and Technology), Kawada Industries
- **disclosure**: Kaneko, K. et al. 'Design of prototype humanoid robotics platform for HRP.' IROS 2002.
- **ip status**: open-permissive
- **prior art notes**: OpenHRP is itself foundational prior art for open robotics simulation frameworks. HRP-2 was among the first humanoids to publicly demonstrate falling-and-recovering behaviors.

## Sony QRIO (2003-03)

- **id**: `sony-qrio`
- **corpus**: private
- **creator**: Sony Corporation
- **disclosure**: Sony Corporation public reveal of QRIO, March 2003.
- **ip status**: patented
- **prior art notes**: QRIO's intelligent servo actuator architecture (embedded control in each joint module) is significant prior art for distributed-control humanoid actuator claims. Sony's now-expiring patents are a deep prior art well.

## HUBO (2004)

- **id**: `hubo`
- **corpus**: academic
- **creator**: KAIST, Hubo Lab (Jun-Ho Oh)
- **disclosure**: Park, Ill-Woo et al. 'Mechanical Design of Humanoid Robot Platform KHR-3 (HUBO).' IEEE-RAS Humanoids 2005.
- **ip status**: open-permissive
- **prior art notes**: DRC-Hubo's 2015 win demonstrated transformer-style transitioning between bipedal and wheeled-knee modes for navigating both stairs and flat ground. Anticipates: hybrid locomotion modes in humanoids.

## NAO (2006)

- **id**: `nao`
- **corpus**: private
- **creator**: Aldebaran Robotics (later SoftBank Robotics, then UBT)
- **disclosure**: Gouaillier, D. et al. 'Mechatronic design of NAO humanoid.' ICRA 2009.
- **ip status**: patented
- **prior art notes**: NAO's mechatronic design publication is well-cited prior art. The platform's wide academic distribution since 2006 makes its design choices broadly disclosed.

## Toyota Partner Robot (Violin) (2007)

- **id**: `toyota-partner-robot-violin`
- **corpus**: private
- **creator**: Toyota Motor Corporation Partner Robot Division
- **disclosure**: Toyota Motor Corporation public reveal, 2007.
- **ip status**: patented
- **prior art notes**: Toyota's high-precision finger control disclosures are significant prior art for fine motor control humanoid claims.

## iCub (2008)

- **id**: `icub`
- **corpus**: academic
- **creator**: Italian Institute of Technology (IIT) and the RobotCub Consortium
- **disclosure**: Metta, G. et al. 'The iCub humanoid robot: an open platform for research in embodied cognition.' PerMIS 2008.
- **ip status**: open-permissive
- **prior art notes**: Among the earliest fully open-source humanoid platforms with hardware design released. Anticipates: tendon-driven anthropomorphic hands, full-body artificial skin, open robotics middleware.

## HRP-3 (2008)

- **id**: `hrp-3`
- **corpus**: academic
- **creator**: AIST and Kawada Industries
- **disclosure**: Kaneko, K. et al. 'Humanoid Robot HRP-3.' IROS 2008.
- **ip status**: open-permissive
- **prior art notes**: HRP-3's environmental sealing disclosures anticipate subsequent IP-rated humanoid claims. The HRP series is a deep commons asset because of consistent open academic disclosure across generations.

## Willow Garage PR1 (2008)

- **id**: `willow-pr1`
- **corpus**: academic
- **creator**: Willow Garage / Stanford (Ken Salisbury group)
- **disclosure**: Wyrobek, K.A. et al. 'Towards a Personal Robotics Development Platform: Rationale and Design of an Intrinsically Safe Personal Robot.' ICRA 2008.
- **ip status**: open-permissive
- **prior art notes**: PR1 is significant prior art for safety-by-design humanoid robotics. Cable-driven intrinsically-safe architecture anticipates several modern compliant-actuator humanoid claims.

## DARwIn-OP (2010)

- **id**: `darwin-op`
- **corpus**: open
- **creator**: Robotis Co. with University of Pennsylvania, Virginia Tech, Purdue
- **disclosure**: Ha, I. et al. 'Development of Open Humanoid Platform DARwIn-OP.' SICE 2011.
- **ip status**: open-permissive
- **prior art notes**: DARwIn-OP is foundational prior art for fully-open small-scale humanoid platforms. Predates Poppy by several years for the academic-open category.

## PR2 (2010)

- **id**: `pr2`
- **corpus**: open
- **creator**: Willow Garage
- **disclosure**: Willow Garage. PR2 platform release, 2010.
- **ip status**: open-permissive
- **prior art notes**: PR2 was the platform around which ROS was originally built. Its hardware is significant prior art for omnidirectional wheeled mobile manipulation. ROS itself is even more significant prior art for robotics middleware.

## HRP-4 (2010)

- **id**: `hrp-4`
- **corpus**: academic
- **creator**: AIST and Kawada Industries
- **disclosure**: Kaneko, K. et al. 'Humanoid Robot HRP-4: Humanoid Robotics Platform with Lightweight and Slim Body.' IROS 2010.
- **ip status**: open-permissive
- **prior art notes**: HRP-4 lightweight design anticipates subsequent slim-form humanoid claims. The 2010 IROS paper provides full mechanical specifications openly.

## Robonaut 2 (2010-02)

- **id**: `robonaut-2`
- **corpus**: academic
- **creator**: NASA Johnson Space Center, in partnership with General Motors
- **disclosure**: Diftler, M.A. et al. 'Robonaut 2 — The First Humanoid Robot in Space.' ICRA 2011.
- **ip status**: patented
- **prior art notes**: Robonaut 2's hand design, with 12 DoF per hand and tendon routing through the forearm, is foundational prior art for high-DoF tendon-driven humanoid hands. The NASA-GM patent portfolio has been extensively cited.

## Toyota HSR (2012)

- **id**: `toyota-hsr`
- **corpus**: private
- **creator**: Toyota Motor Corporation Partner Robot Division
- **disclosure**: Yamamoto, T. et al. 'Development of Human Support Robot as the research platform of a domestic mobile manipulator.' ROBOMECH Journal 6:4, 2019. Earlier 2012 disclosure.
- **ip status**: patented
- **prior art notes**: HSR's telescoping torso with whole-body control is significant prior art for domestic-context wheeled humanoid claims.

## NASA Valkyrie (2013)

- **id**: `nasa-valkyrie`
- **corpus**: academic
- **creator**: NASA Johnson Space Center, in collaboration with University of Texas at Austin and others
- **disclosure**: NASA Johnson Space Center, DARPA Robotics Challenge entry, 2013.
- **ip status**: open-permissive
- **prior art notes**: NASA Valkyrie's series-elastic actuator implementations and the IHMC-derived whole-body control work are foundational prior art. The robot was distributed to multiple universities and produced extensive open publications.

## REEM-C (2013)

- **id**: `reem-c`
- **corpus**: private
- **creator**: PAL Robotics
- **disclosure**: PAL Robotics REEM-C release, 2013.
- **ip status**: patented
- **prior art notes**: REEM-C distributed to multiple research labs; design characteristics openly published.

## Atlas (2013-07)

- **id**: `atlas-boston-dynamics`
- **corpus**: private
- **creator**: Boston Dynamics
- **disclosure**: DARPA press release, July 2013, announcing Atlas as DRC platform.
- **ip status**: patented
- **prior art notes**: Boston Dynamics' patents are among the most-cited in the humanoid space and also among the most likely to be challenged on 102/103 grounds given the long academic prior art chain (Honda, AIST, KAIST, MIT). Worth dedicated patent-by-patent analysis.

## Poppy Humanoid (2014)

- **id**: `poppy-humanoid`
- **corpus**: open
- **creator**: Inria Flowers Team / Poppy Project
- **disclosure**: Lapeyre, Matthieu et al. 'Poppy Humanoid Platform: Experimental Evaluation of the Role of a Bio-inspired Thigh Shape.' IEEE Humanoids 2013.
- **ip status**: open-permissive
- **prior art notes**: Among the earliest fully-open 3D-printable humanoids. Anticipates open-source educational humanoid platforms broadly.

## Pepper (2014-06)

- **id**: `pepper-softbank`
- **corpus**: private
- **creator**: SoftBank Robotics (formerly Aldebaran)
- **disclosure**: SoftBank Robotics public reveal of Pepper, June 2014.
- **ip status**: patented
- **prior art notes**: Pepper is foundational prior art for wheeled-base humanoid social robots. The omnidirectional wheeled base design has been widely cited.

## Boston Dynamics Spot (2015-02)

- **id**: `hyundai-boston-dynamics-spot`
- **corpus**: private
- **creator**: Boston Dynamics (now Hyundai Motor Group subsidiary)
- **disclosure**: Boston Dynamics public reveal of Spot, February 2015.
- **ip status**: patented
- **prior art notes**: Spot is the most commercially deployed quadruped robot. BD's Spot patents face deep prior art from MIT Cheetah series, ANYmal lineage, and academic quadruped literature.

## ANYmal (2016)

- **id**: `anymal`
- **corpus**: private
- **creator**: ANYbotics, ETH Zurich Robotic Systems Lab
- **disclosure**: Hutter, M. et al. 'ANYmal — a highly mobile and dynamic quadrupedal robot.' IROS 2016.
- **ip status**: patented
- **prior art notes**: ANYbotics SEA design heavily anticipated by NASA Valkyrie and Robonaut SEA work. ETH RSL academic publications provide open prior art for many control claims.

## Sophia (2016-04)

- **id**: `hanson-sophia`
- **corpus**: private
- **creator**: Hanson Robotics
- **disclosure**: Hanson Robotics public reveal of Sophia, April 2016.
- **ip status**: patented
- **prior art notes**: Hanson's Frubber synthetic skin material and facial actuation prior art is significant for any claim around expressive humanoid faces. Disney Imagineering's earlier work is the deeper prior art.

## PAL TALOS (2017)

- **id**: `pal-talos`
- **corpus**: private
- **creator**: PAL Robotics, in collaboration with LAAS-CNRS
- **disclosure**: Stasse, O. et al. 'TALOS: A new humanoid research platform targeted for industrial applications.' IEEE Humanoids 2017.
- **ip status**: patented
- **prior art notes**: TALOS is among the better-published European industrial humanoids. Stasse 2017 IEEE Humanoids paper provides comprehensive design disclosure.

## Toyota T-HR3 (2017-11)

- **id**: `toyota-thr3`
- **corpus**: private
- **creator**: Toyota Motor Corporation Partner Robot Division
- **disclosure**: Toyota Motor Corporation public reveal, November 2017.
- **ip status**: patented
- **prior art notes**: T-HR3 is significant prior art for whole-body teleoperated humanoids with force feedback. The Master Maneuvering System teleoperation interface anticipates many modern humanoid teleop claims.

## Kawasaki Kaleido (2017-11)

- **id**: `kawasaki-kaleido`
- **corpus**: private
- **creator**: Kawasaki Heavy Industries
- **disclosure**: Kawasaki Heavy Industries public reveal of Kaleido, iREX November 2017.
- **ip status**: patented
- **prior art notes**: Kawasaki's deep industrial robotics IP base means much of their humanoid claims are anticipated by their own prior industrial robotics disclosures, plus AIST HRP series prior art.

## Ghost Robotics Vision 60 (2018)

- **id**: `ghost-robotics-vision-60`
- **corpus**: private
- **creator**: Ghost Robotics
- **disclosure**: Ghost Robotics Vision 60 release, 2018.
- **ip status**: patented
- **prior art notes**: Ghost Robotics derives from Penn's Kod*lab academic quadruped work. The legged-robot patents face the same MIT Cheetah / ANYmal / Penn Kod*lab prior art chain as other quadrupeds.

## UBTech Walker (2018-01)

- **id**: `ubtech-walker`
- **corpus**: private
- **creator**: UBTech Robotics
- **disclosure**: UBTech public reveal of Walker, CES January 2018.
- **ip status**: patented
- **prior art notes**: UBTech's bipedal locomotion claims anticipated by Honda P-series and ASIMO disclosures.

## HRP-5P (2018-09)

- **id**: `hrp-5p`
- **corpus**: academic
- **creator**: AIST and Kawada Industries
- **disclosure**: Kaneko, K. et al. 'Humanoid Robot HRP-5P: An Electrically Actuated Humanoid Robot With High-Power and Wide-Range Joints.' IEEE Robotics and Automation Letters 4(2), 2019.
- **ip status**: open-permissive
- **prior art notes**: HRP-5P's construction-task demonstrations and high-power actuator disclosures are among the most thoroughly published examples of humanoid construction work. Anticipates many subsequent industrial humanoid claims.

## Digit (2019-01)

- **id**: `agility-digit`
- **corpus**: private
- **creator**: Agility Robotics
- **disclosure**: Agility Robotics public reveal, CES January 2019.
- **ip status**: patented
- **prior art notes**: Cassie/Digit derive from Oregon State University academic work (Hurst lab); the academic publications constitute substantial prior art for the bipedal control claims.

## Diligent Moxi (2019-09)

- **id**: `diligent-moxi`
- **corpus**: private
- **creator**: Diligent Robotics
- **disclosure**: Diligent Robotics public reveal of Moxi, September 2019.
- **ip status**: patented
- **prior art notes**: Diligent's claims around mobile manipulation in healthcare environments face extensive prior art from PR2, HSR, and academic mobile manipulation literature.

## Reachy (2020)

- **id**: `reachy`
- **corpus**: open
- **creator**: Pollen Robotics
- **disclosure**: Pollen Robotics. Reachy public release, 2020.
- **ip status**: open-permissive
- **prior art notes**: Reachy's Orbita 3-DoF spherical actuator is novel-ish but anticipated by extensive academic spherical-motor literature. Open hardware files constitute prior art for the specific implementation.

## Boston Dynamics Spot (fuel-cell variant) (2020)

- **id**: `spot-fuel-cell`
- **corpus**: private
- **creator**: Boston Dynamics
- **disclosure**: Boston Dynamics partnership announcements with fuel cell vendors, 2020.
- **ip status**: patented
- **prior art notes**: Demonstrates fuel-cell-powered legged robotics at commercial scale. Anticipates fuel-cell power claims in field robotics applications.

## Tesla Optimus (2021-08-19)

- **id**: `tesla-optimus`
- **corpus**: private
- **creator**: Tesla, Inc.
- **disclosure**: Tesla AI Day 1, August 19, 2021, Palo Alto.
- **ip status**: patented
- **prior art notes**: Tesla's claims around vision-only humanoid perception are heavily anticipated by academic vision-based humanoid work. Actuator IP claims should be examined against Honda harmonic drive prior art.

## Ameca (2021-12)

- **id**: `ameca`
- **corpus**: private
- **creator**: Engineered Arts
- **disclosure**: Engineered Arts public reveal, December 2021.
- **ip status**: patented
- **prior art notes**: Engineered Arts' animatronic facial expression IP is heavily anticipated by Disney Imagineering work and by academic facial-animation robotics.

## Sanctuary Phoenix Gen 6 (2022)

- **id**: `sanctuary-phoenix-gen6`
- **corpus**: private
- **creator**: Sanctuary AI
- **disclosure**: Sanctuary AI public reveals of Phoenix predecessors, 2020-2022.
- **ip status**: patented
- **prior art notes**: Sanctuary's hybrid hydraulic-electric actuation faces extensive prior art from Boston Dynamics Atlas (hydraulic), Honda (electric), and academic hybrid actuation literature.

## Sanctuary AI Phoenix (2023-05)

- **id**: `sanctuary-phoenix`
- **corpus**: private
- **creator**: Sanctuary AI
- **disclosure**: Sanctuary AI public reveal, May 2023.
- **ip status**: patented
- **prior art notes**: Sanctuary's high-DoF hand claims face Shadow Hand (2003) and iCub (2008) as deep prior art for tendon-driven anthropomorphic hands with high finger DoF.

## Fourier GR-1 (2023-07)

- **id**: `fourier-gr1`
- **corpus**: private
- **creator**: Fourier Intelligence
- **disclosure**: Fourier Intelligence public reveal of GR-1, July 2023, World AI Conference Shanghai.
- **ip status**: patented
- **prior art notes**: Fourier transitions from rehabilitation exoskeletons to humanoids; actuator IP from exoskeleton work potentially anticipates some humanoid actuator claims by other companies.

## Unitree H1 (2023-08)

- **id**: `unitree-h1`
- **corpus**: private
- **creator**: Unitree Robotics
- **disclosure**: Unitree Robotics public reveal, August 2023.
- **ip status**: patented
- **prior art notes**: Unitree's actuator IP largely derives from quadruped work (Go1, Aliengo) which is itself heavily anticipated by MIT Mini Cheetah QDD lineage.

## Apptronik Apollo (2023-08)

- **id**: `apptronik-apollo`
- **corpus**: private
- **creator**: Apptronik
- **disclosure**: Apptronik public reveal of Apollo, August 2023.
- **ip status**: patented
- **prior art notes**: Apptronik's actuator IP has lineage from UT Austin Human-Centered Robotics Lab (Sentis) and from NASA Valkyrie work; both sources constitute substantial prior art that limits the patentable surface area of Apptronik's own claims.

## AgiBot A1 (2023-08)

- **id**: `agibot-a1`
- **corpus**: private
- **creator**: AgiBot (Shanghai Zhiyuan New Technology Co.)
- **disclosure**: AgiBot (Shanghai Zhiyuan New Technology) public reveal, August 2023.
- **ip status**: patented
- **prior art notes**: AgiBot's actuator IP heavily anticipated by Honda P-series harmonic drive work and MIT Cheetah QDD lineage. Chinese-language patent filings should be enumerated in strengthening pass.

## Figure 01 (2023-10)

- **id**: `figure-01`
- **corpus**: private
- **creator**: Figure AI
- **disclosure**: Figure AI public reveal, October 2023.
- **ip status**: patented
- **prior art notes**: Figure's claimed innovations in electric humanoid actuation are heavily anticipated by Honda's E-series and ASIMO publications, by KAIST HUBO papers, and by the entire academic literature.

## LimX Dynamics CL-1 (2023-12)

- **id**: `limx-cl1`
- **corpus**: private
- **creator**: LimX Dynamics
- **disclosure**: LimX Dynamics public reveal, December 2023.
- **ip status**: patented
- **prior art notes**: LimX QDD actuation derives from MIT Cheetah lineage; bipedal control claims anticipated by Cassie/ATRIAS work.

## 1X NEO (2024)

- **id**: `1x-neo`
- **corpus**: private
- **creator**: 1X Technologies (formerly Halodi Robotics)
- **disclosure**: 1X Technologies public reveal, 2024.
- **ip status**: patented
- **prior art notes**: Tendon-driven compliant actuation is heavily anticipated by iCub, by Shadow Robot Hand work, and by decades of academic compliant-actuation literature.

## K-Scale Labs Open Source Humanoid (2024)

- **id**: `k-scale-os`
- **corpus**: open
- **creator**: K-Scale Labs
- **disclosure**: K-Scale Labs project launch, 2024.
- **ip status**: open-permissive
- **prior art notes**: Among the most ambitious recent fully-open humanoid efforts. Direct peer to Free Humanoid in scope.

## Berkeley Humanoid (2024)

- **id**: `berkeley-humanoid`
- **corpus**: academic
- **creator**: UC Berkeley, Hybrid Robotics Lab
- **disclosure**: Liao, Q. et al. 'Berkeley Humanoid: A Research Platform for Learning-based Control.' arXiv 2024.
- **ip status**: open-permissive
- **prior art notes**: Berkeley quasi-direct-drive lineage (predates the humanoid; comes from the Mini Cheetah / leg work) anticipates many actuator architecture claims.

## Persona AI Mentee (2024)

- **id**: `persona-ai-mentee`
- **corpus**: private
- **creator**: Persona AI
- **disclosure**: Persona AI public reveal, 2024.
- **ip status**: trade-secret
- **prior art notes**: Public technical disclosure is thin; strengthening pass needed.

## Rainbow Robotics RB-Y1 (2024-03)

- **id**: `rainbow-robotics-rb-y1`
- **corpus**: private
- **creator**: Rainbow Robotics
- **disclosure**: Rainbow Robotics public reveal of RB-Y1, March 2024.
- **ip status**: patented
- **prior art notes**: Rainbow Robotics has direct lineage from KAIST HUBO program; HUBO academic publications constitute prior art for many of their humanoid claims.

## Neura 4NE-1 (2024-05)

- **id**: `neura-4ne1`
- **corpus**: private
- **creator**: Neura Robotics
- **disclosure**: Neura Robotics public reveal of 4NE-1, May 2024.
- **ip status**: patented
- **prior art notes**: Neura's cognitive-AI claims overlap with academic VLA literature.

## Kepler K2 (2024-07)

- **id**: `kepler-k2`
- **corpus**: private
- **creator**: Kepler Exploration Robotics
- **disclosure**: Kepler Exploration Robotics public reveal, July 2024.
- **ip status**: patented
- **prior art notes**: Kepler's planetary-reducer actuator claims are anticipated by extensive prior art in industrial robotics planetary-gearing literature.

## Figure 02 (2024-08)

- **id**: `figure-02`
- **corpus**: private
- **creator**: Figure AI
- **disclosure**: Figure AI public reveal of Figure 02, August 2024.
- **ip status**: patented
- **prior art notes**: Figure 02 actuator and hand claims are heavily anticipated by Honda P-series, Robonaut 2, Shadow Hand, and iCub work. The 16-DoF hand is in the same design space as Robonaut 2's 12-DoF and Sanctuary's 21-DoF.

## Robot Era STAR1 (2024-10)

- **id**: `robot-era-star1`
- **corpus**: private
- **creator**: Robot Era
- **disclosure**: Robot Era public reveal of STAR1, October 2024.
- **ip status**: patented
- **prior art notes**: Bipedal running speed claims anticipated by Cassie's Guinness record work.

## XPeng Iron (2024-11)

- **id**: `xpeng-iron`
- **corpus**: private
- **creator**: XPeng Motors (Robotics division)
- **disclosure**: XPeng AeroHT and XPeng Robotics reveal, November 2024.
- **ip status**: patented
- **prior art notes**: XPeng's leveraging of automotive ML stack for humanoid perception is heavily anticipated by Tesla Optimus's same approach (which is itself anticipated by academic vision-based humanoid work).
